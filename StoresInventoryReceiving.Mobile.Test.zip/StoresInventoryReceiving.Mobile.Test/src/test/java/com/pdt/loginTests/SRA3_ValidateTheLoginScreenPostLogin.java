package com.pdt.loginTests;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Login & redirect to Main Screen")
@Description("Description:Login & redirect to Main Screen")

public class SRA3_ValidateTheLoginScreenPostLogin extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA3_ValidateTheLoginScreenPostLogin.class);
	SoftAssert softassert = new SoftAssert();

	public void validateTheLoginScreenPostLogin() throws ParseException {

		HomePage homeScreen = new HomePage();
		final LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		login.loginInMRA(getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));

		logger.info("To Validate if the Home icon in the menu bar navigates to homepage");

		String displayedToolBarTitle = homeScreen.captureHeadingInHomePage();
		softassert.assertEquals(displayedToolBarTitle, "HOME");
		logger.info(displayedToolBarTitle + " Heading is Displayed in the Home Page");

		logger.info("To validate if all the major icons are displayed in the Home Page");
		homeScreen.isReceivingInHomeDisplayed();
		homeScreen.isAuditingInHomeDisplayed();
		homeScreen.isItemLookupInHomeDisplayed();

		logger.info("To validate if all the major icons are displayed in the Receiving Home Page");
		homeScreen.clickOnReceiving();
		String displayedReceivingTitle = homeScreen.captureHeadingInReceivingHomePage();
		softassert.assertEquals(displayedReceivingTitle, "RECEIVING HOME");
		logger.info(displayedReceivingTitle + " Heading is Displayed in the Receiving Home Page");

		receivingPage.isDcShpmentDisplayed();
		receivingPage.isPurchaseOrdersDisplayed();
		receivingPage.isStoreToStoreTransferDisplayed();
		softassert.assertAll();
	}

}
