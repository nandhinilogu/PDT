package com.pdt.loginTests;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;


@Listeners(BaseListener.class)
@Test(description = "To verify if correct Store Id and Associate Id is displayed on Sidemenubar,")
@Description("To verify if correct Store Id and Associate Id is displayed on Sidemenubar")
public class SRA326_SideMenuBar_Displays_StoreId_AssociateID extends BaseTest{
	final static Logger logger = Logger.getLogger("SRA326");
	SoftAssert softassert =new SoftAssert();
	
	
	public void SRA326_Displays_StoreId_AssociateID() throws InterruptedException {
		final LoginPage login = new LoginPage();
		HomePage homescreen=new HomePage();
		
		logger.info("Login as a store Associate and validate");	
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"), getProperty("valid_password9792"));
		homescreen.clickOnMenuBar();
		String storeid=homescreen.storeIDValue();
		softassert.assertEquals(storeid, "2");
		String associateId=homescreen.associateIdValue();
		softassert.assertEquals(associateId, "9792");
		logger.info("Logged in as store associate");
		homescreen.logout();
		
		logger.info("Login as a store Manager and validate");	
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username4850"), getProperty("valid_password4850"));
		homescreen.clickOnMenuBar();
		String storesid=homescreen.storeIDValue();
		softassert.assertEquals(storesid, "104");
		String managerId=homescreen.associateIdValue();
		softassert.assertEquals(managerId, "4850");
		logger.info("Logged in as store Manager");
		homescreen.clickOnHomeOnSideMenuBar();
		softassert.assertAll();
	
	}

}
