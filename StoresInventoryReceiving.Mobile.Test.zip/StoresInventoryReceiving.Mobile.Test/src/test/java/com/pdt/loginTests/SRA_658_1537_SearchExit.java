package com.pdt.loginTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;


@Listeners(BaseListener.class)
@Test(description = "Search Exit")
@Description("Validate whether keypad is disabled")

public class SRA_658_1537_SearchExit extends BaseTest{
	final static Logger logger = Logger.getLogger("SRA_658_1537");
	
	public void SRA1537_ValidateSearchExitInAllPage() throws IOException, ParseException, InterruptedException{
		
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		MobileTicketingPage mobileTicketing=new MobileTicketingPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();
	

			Document doc = createDocFromFile("SRA7_DcShipment1.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			logger.info("Date after increment " + ExpectedArrival);
			updateDocToDb(doc);
			
			String storeNumber = doc.getString("DestinationStoreNumber");
			String shipmentNumber = doc.getString("ShipmentNumber");

			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));

			logger.info("Search Exit in DCShipment");
			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipment.validateSearchExitInDCShipmentHomePage(shipmentNumber);
			
			logger.info("Search Exit in PO");
			homescreen.clickOnMenuBar();
			homescreen.clickOnPurchaseOrdersOnSideMenuBar();
			purchaseOrder.validateSearchExitInPOHomePage("20935");
			
			logger.info("Search Exit in SendStore Transfer");
			homescreen.clickOnMenuBar();
			homescreen.clickOnStoreTransferOnSideMenuBar();
			sendnReceivetransfer.clickOnSendStoreTransfer();
			sendStoreTransfer.validateSearchExitInSendTransferHomePage("20935");
			
			logger.info("Search Exit in ReceiveStore Transfer");
			homescreen.clickOnMenuBar();
			homescreen.clickOnStoreTransferOnSideMenuBar();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			receiveStoreTransfer.validateSearchExitInReceiveTransferHomePage("20935");
			
			logger.info("Search Exit in ItemLookUp");
			homescreen.clickOnMenuBar();
			homescreen.clickOnItemLookUpAndTicketingOnSideMenuBar();
			mobileTicketing.validateSearchExitInTicketingHomePage(getProperty("sku5739995"));
			
			logger.info("Search Exit in GlobalSearch");
			globalSearch.clickOnGlobalSearch();
			globalSearch.validateSearchExitInGlobalSearch(getProperty("sku5739995"));
			
		
	}

			
}
