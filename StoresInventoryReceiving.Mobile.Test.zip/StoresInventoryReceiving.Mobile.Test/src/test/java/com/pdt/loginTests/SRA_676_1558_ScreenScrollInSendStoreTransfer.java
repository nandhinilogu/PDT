package com.pdt.loginTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Screen Scroll in SendStore Transfer")
@Description("Validate able to scroll in Send Store Transfer Page")

public class SRA_676_1558_ScreenScrollInSendStoreTransfer extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA_676_1558_ScreenScrollInSendStoreTransfer.class);

	public void SRA1558_ValidateScreenScrollInSendStoreTransfer() throws IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();

		Document doctransfer = createDocFromFile("StoresSRA676.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDatetransfer = getDateIncementDay("yyyy-MM-dd", 7);
		Date ETATransfer = format.parse(EtaDatetransfer);
		doctransfer.put("ETADateTime", ETATransfer);
		updateDocToStoreTransferDb(doctransfer);

		String transferNumber = doctransfer.getString("TransferNumber");
		logger.info("Transfer Number is -------" + transferNumber);

		login.loginInMRA(getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendAndReceiveTransferPage.clickOnSendStoreTransfer();

		sendStoreTransfer.scrollInSendTransferHomePage();
		sendStoreTransfer.scrollInSendTransferDetailPage(transferNumber);
	}

}
