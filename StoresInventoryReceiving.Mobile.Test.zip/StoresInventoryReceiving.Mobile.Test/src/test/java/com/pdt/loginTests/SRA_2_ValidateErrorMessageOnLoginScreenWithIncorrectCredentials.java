package com.pdt.loginTests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To verify if Associate is not able to login with Incorrect Credentials")
@Description("Description:Verify if Associate is  not able to login with Incorrect Credentials")
public class SRA_2_ValidateErrorMessageOnLoginScreenWithIncorrectCredentials extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA2");

	public void SRA_2_validateErrorMessageOnLoginScreenWithIncorrectCredentials() throws InterruptedException {

		LoginPage login = new LoginPage();
		logger.info("Login with invalid username and password and validate  error message");
		login.login_With_Incorrect_Credentials(getProperty("valid_storeno2"), getProperty("invalid_username"),
				getProperty("invalid_password"));
		Thread.sleep(5000);
		String ErrorMessageForIncorrectID = login.captureErrorMessage();
		Assert.assertEquals(ErrorMessageForIncorrectID, "Incorrect User ID and Password. Please try again!");
		logger.info("Displayed Error message is " + ErrorMessageForIncorrectID);
		login.clearForm();

		logger.info("Login with Three digit username and password and validate error message");
		login.login_With_Incorrect_Credentials(getProperty("valid_storeno2"), getProperty("threeDigit_username"),
				getProperty("threeDigit_password"));
		String ErrorMessageForThreeDigitID = login.captureErrorMessage();
		Assert.assertEquals(ErrorMessageForThreeDigitID,
				"UserID or password cannot be less than 4 characters. Please try again!");
		logger.info("Displayed Error message is " + ErrorMessageForThreeDigitID);
		login.clearForm();

		logger.info("Login with Incorrect store ID and validate error message");
		login.login_With_Incorrect_Credentials(getProperty("invalid_storeno"), getProperty("invalid_username"),
				getProperty("invalid_password"));
		String ErrorMessageForIncorrectStoreID = login.captureErrorMessage();
		Assert.assertEquals(ErrorMessageForIncorrectStoreID, "Incorrect User ID and Password. Please try again!");
		logger.info("Displayed Error message is " + ErrorMessageForIncorrectStoreID);
		login.clearForm();

	}

}
