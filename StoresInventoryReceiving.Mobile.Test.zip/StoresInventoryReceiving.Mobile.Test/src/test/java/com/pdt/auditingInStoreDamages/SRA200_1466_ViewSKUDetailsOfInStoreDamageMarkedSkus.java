
package com.pdt.auditingInStoreDamages;

import java.io.IOException;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInStoreDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate the Sku details of Damaged Sku In In-Store Damages Screen")
@Description("To validate the Sku details of Damaged Sku In In-Store Damages Screen")

public class SRA200_1466_ViewSKUDetailsOfInStoreDamageMarkedSkus extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA200_1466");
	
			
	public void SRA1466_ViewSKUDetailsOfInStoreDamageMarkedSkus() throws IOException, ParseException, InterruptedException {
		
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		
			//Method to update all the In-store damaged skus to previous date, so that I can add it today
			validateFromMongoDB.updateSkuMarkedAsInStoreDamages(getProperty("sku5739995"));
			
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			
		homescreen.clickOnAuditing();
		auditingPage.clickInStoreDamages();
		logger.info("To validate Sku details of In-Store Damaged skus");
		InStoreDamagesPage.ValidateSkuDetailsOfDamageMarkedSku(getProperty("sku5739995"));
	
		}
}
