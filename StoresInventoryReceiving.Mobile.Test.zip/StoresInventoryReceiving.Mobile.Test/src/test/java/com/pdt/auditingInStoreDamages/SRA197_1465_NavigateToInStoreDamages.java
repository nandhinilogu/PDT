
package com.pdt.auditingInStoreDamages;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getTodayDate;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingInStoreDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Navigate To In-Store damages Home screen and validate")
@Description("Navigate To In-Store damages Home screen and validate")

public class SRA197_1465_NavigateToInStoreDamages extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA_1465");
	SoftAssert softassert =new SoftAssert();
	
	public void SRA1465_ValidateDefaultMessageInInStoreDamagesHomeScreen() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickInStoreDamages();
			Thread.sleep(2000);
			
			if(InStoreDamagesPage.isDefaultMessageDisplayed()) {
				String DefaultMessage = InStoreDamagesPage.captureDefaultMessage();
				logger.info(DefaultMessage + " message is displayed");
				softassert.assertEquals(DefaultMessage, "Start Scanning to see damaged SKUs");
				softassert.assertAll();
			}
			else {
				InStoreDamagesPage.isDamagedSkuDisplayed();
				logger.info("Skus marked as damaged is Displayed In the place of Default Message");	
			}
	}

	
	public void SRA1465_ValidateTodayDamageMarkedSkus_AredisplayedInStoreDamagesHomeScreenToday()
			throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();
	

			Document doc = createDocFromFile("InStoreDamagesScanned.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
			String TodayDate = getTodayDate("yyyy-MM-dd");
			Date UpdatedTodayDate = format.parse(TodayDate);
			logger.info("updated Today date is " + UpdatedTodayDate);

			// Changed the Created and Modified time of In-store Damaged Sku To today date 
			 doc.put("CreatedTime", UpdatedTodayDate);
			 doc.put("ModifiedTime", UpdatedTodayDate);
			 
			 updateDocInStoreCollection(doc);
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickInStoreDamages();
			Thread.sleep(2000);
			// To validate if the skus marked as damaged today is displayed in In-Store damages home
			// screen today
			InStoreDamagesPage.isDamagedSkuFromJsonIsDisplayed();
			logger.info("Skus marked as Damaged today is displayed in In-store Damages Home screen today");
		} 
	

	
	public void SRA1465_ValidateYesterdayDamageMarkedSkus_AreNotdisplayedInStoreDamagesHomeScreenToday()
			throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();

	    Document doc = createDocFromFile("InStoreDamagesScanned.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
		String YesterdayDate = getDateDecreaseDay("yyyy-MM-dd", 1);
		Date UpdatedYesterdayDate = format.parse(YesterdayDate);
		logger.info("updated Yesterday date is " + UpdatedYesterdayDate);
		

		// Changed the Created and Modified time of In-store Damaged Sku To Yesterday date 
		 doc.put("CreatedTime", UpdatedYesterdayDate);
		 doc.put("ModifiedTime", UpdatedYesterdayDate);
		 
		
		 updateDocInStoreCollection(doc);
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickInStoreDamages();
			Thread.sleep(2000);
			// To validate if the skus marked as damaged yesterday is not displayed in In-Store damages home
			// screen today
			InStoreDamagesPage.isDamagedSkuFromJsonIsNotDisplayed("0010411115896R");
			logger.info("Skus marked as Damaged Yesterday is not displayed in In-store Damages Home screen today");

		} 

	}

