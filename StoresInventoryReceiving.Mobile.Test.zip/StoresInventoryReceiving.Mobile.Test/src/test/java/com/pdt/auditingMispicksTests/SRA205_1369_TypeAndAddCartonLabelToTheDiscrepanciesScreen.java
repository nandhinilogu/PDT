
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate adding a scanned carton to the Mispicks Home Screen")
@Description("To validate adding a scanned carton to the Mispicks Home Screen")

public class SRA205_1369_TypeAndAddCartonLabelToTheDiscrepanciesScreen extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA205_1369");
	
			
	public void SRA1369_VerifyAddingCartonNumberToMispicksHomeScreen_ReceivedToday() throws IOException, ParseException, InterruptedException {
		
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
	
		Document doc = createDocFromFile("Mispicks.json");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);

		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipmentScanPage.addCartonAsScanned("0010411111896R");
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		// // To add a carton number which is scanned, but not submitted  to the Mispicks home screen and to validate the error message
		mispicksScanPage.addScannedCartonNumberToMispicksHomeScreen("0010411111896R");
		homescreen.clickOnMenuBar();
		homescreen.clickOnDCShipmentsOnSideMenuBar();
		receivingShipmentScanPage.submitCartonAsReceived();
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		// To add a invalid carton number to the Mispicks home screen and to validate the error message
		mispicksScanPage.addInvalidCartonNumberToMispicksHomeScreen("987654S");
		
		// // To incorrectly enter last 4 digits of the carton and to validate the error message
		mispicksScanPage.validateErrorMessageForEnteringInvalidFourDigitsForValidCarton("0010411111896R");
		
		// To add a Valid carton number to the Mispicks home screen
		mispicksScanPage.addValidCartonNumberToMispicksHomeScreen("0010411111896R");
		mispicksScanPage.clickOnSubmitMispicksButton();
		
		// To add a Duplicate carton number to the Mispicks home screen and to validate the error message
		mispicksScanPage.addDuplicateCartonNumberToMispicksHomeScreen("0010411111896R");
		
		}
	
	public void SRA1369_VerifyAddingCartonNumberToMispicksHomeScreen_ReceivedBeforeFiveDays() throws IOException, ParseException, InterruptedException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();

		Document doc = createDocFromFile("SRA205_Mispicks.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		
		String DecreasedDate = getDateDecreaseDay("yyyy-MM-dd", 6);
		Date UpdatedScannedDate = format.parse(DecreasedDate);
		logger.info("updated Scanned date is " + UpdatedScannedDate);
		
	//	 Change the scanned Time to three days from today
		((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", UpdatedScannedDate);
		
		
		updateDocToDb(doc);
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnAuditing();
		auditingPage.clickMispicks();
		Thread.sleep(2000);
		logger.info("Cartons scanned before 5 days is not added to the Mispicks home screen");
		mispicksScanPage.addInvalidCartonNumberToMispicksHomeScreen("0010411111123R");
		
		}
	
	public void SRA1369_VerifyAddingCartonNumberToMispicksHomeScreen_ReceivedWithinFiveDays() throws IOException, ParseException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
	
		Document doc = createDocFromFile("SRA205_Mispicks.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 28);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		
//		Document doc1 = createDocFromFile("MispicksScannedTrue");
//		String EtaDate1 = getDateIncementDay("yyyy-MM-dd", 29);
//		Date ExpectedArrival1 = format.parse(EtaDate1);
//		doc.put("EtaDateTime", ExpectedArrival1);
		
		String DecreasedDate = getDateDecreaseDay("yyyy-MM-dd", 3);
		Date UpdatedScannedDate = format.parse(DecreasedDate);
		logger.info("updated Scanned date is " + UpdatedScannedDate);
		
	//	 Change the scanned Time to three days from today
		((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", UpdatedScannedDate);
		
		
		updateDocToDb(doc);
	//	updateDocToDb(doc1);
		
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnAuditing();
		auditingPage.clickMispicks();
		
		logger.info("Cartons scanned within 5 days is added to the Mispicks home screen");
		mispicksScanPage.addMispickedCarton("0010411111123R");

//		 To add a Carton which is already marked as mispicks and to validate the error message  
		mispicksScanPage.addAlreadyMispickedMarkedCartonNumberToMispicksHomeScreen("0010411111123R");
		
		}	
}
