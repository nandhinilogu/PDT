
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateIncementDay;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;

import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To validate edit received sku qty for carton marked as discrepancies")
@Description("To validate edit received sku qty for carton marked as discrepancies")

public class SRA207_1310_EditSkuQtyReceivedInCaseOfDiscrepanices extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA207_1310");
	
	@SuppressWarnings("unchecked")
	public void SRA1310_EditSkuQtyReceivedInCaseOfDiscrepanices() throws IOException, ParseException, InterruptedException {

		HomePage homescreen = new HomePage();
		ValidateFromMongoDB mongoDB=new ValidateFromMongoDB();
		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage= new AuditingPage();
		MispicksScanPage mispicksScanPage= new MispicksScanPage();

			Document doc = createDocFromFile("Mispicks.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);

			
			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);
			
			
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			
			receivingShipmentScanPage.addCartonAsReceived(cartonNumber);
			homescreen.clickOnMenuBar();
			homescreen.clickOnAuditingOnSideMenuBar();
			auditingPage.clickMispicks();
			mispicksScanPage.addMispickedCarton(cartonNumber);
			
			// To validate edit sku qty to less than expected for discrepancy carton 
			mispicksScanPage.editAndSaveReceivedSkuQty("3");
			
			// To validate edit sku qty to more than expected for discrepancy carton 
			mispicksScanPage.editAndSaveReceivedSkuQty("7");
			
			// To validate click on cancel doesnot save the edited sku qty
			mispicksScanPage.editAndCancelReceivedSkuQty("4");
			
			// To validate edit sku qty to zero for discrepancy carton 
	        mispicksScanPage.editAndSaveReceivedSkuQty("0");
	        
			// To validate edit sku qty to 99 for discrepancy carton 
	        mispicksScanPage.editAndSaveReceivedSkuQty("99");
	        
	        // To validate associates is not able to edit the received SKU Qty above 99
	        mispicksScanPage.editAndCancelReceivedSkuQtyAbove99("101");
	       
	        // To validate if the saved sku qty is updated in DB
	        mispicksScanPage.clickOnSubmitMispicksButton();
	        
	        String submitTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
			logger.info("Current SubmitTime is "+submitTime);
			
	        Thread.sleep(5000);
	        
	        int receivedSkuQtyInDB = mongoDB.getReceivedSkuQuantityForMispickedCarton(cartonNumber,getProperty("valid_storeno104"));
	        Assert.assertEquals(99, receivedSkuQtyInDB);
	        
	        mongoDB.validateMispickTimefromDB(cartonNumber, submitTime,getProperty("valid_storeno104"));
		
		} 
}
