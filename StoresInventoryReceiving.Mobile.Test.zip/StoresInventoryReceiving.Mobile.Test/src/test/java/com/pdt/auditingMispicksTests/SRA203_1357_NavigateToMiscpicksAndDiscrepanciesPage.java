
package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;
import static com.util.BaseUtil.getTodayDate;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Navigate To Mispicks screen and validate the default message")
@Description("Navigate To Mispicks screen and validate the default message")

public class SRA203_1357_NavigateToMiscpicksAndDiscrepanciesPage extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA_1357");

	public void SRA1357_ValidateDefaultMessageInDiscrepanciesHomeScreen() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
	
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickMispicks();
			Thread.sleep(2000);
			
			if(mispicksScanPage.isDefaultMessageDisplayed()) {
			//if(mispicksScanPage.isCartonDisplayed()){
				String DefaultMessage = mispicksScanPage.captureDefaultMessage();
				logger.info(DefaultMessage + " message is displayed");
				Assert.assertEquals(DefaultMessage, "Start scanning to add cartons for Mispicks and Discrepancies");
			}
			else {
				mispicksScanPage.isCartonDisplayed();
				logger.info("cartons marked as Mispicks is Displayed In the place of Default Message");	
			}
		} 

	public void SRA1357_ValidateTodayScannedCartons_AredisplayedInDiscrepanciesHomeScreenToday()
			throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();

			Document doc = createDocFromFile("MispicksScannedTrue.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			String TodayDate = getTodayDate("yyyy-MM-dd");
			Date UpdatedTodayDate = format.parse(TodayDate);
			logger.info("updated Today date is " + UpdatedTodayDate);

			// Change the scanned Time and Mispicked scanned Time To today
			((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", UpdatedTodayDate);
			((List<Document>) doc.get("Cartons")).get(0).put("MispickScannedTime", UpdatedTodayDate);
			updateDocToDb(doc);
			
			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);
			
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnAuditing();
			auditingPage.clickMispicks();
			// To validate if the cartons scanned today is displayed in Discrepancies home
			// screen today
			mispicksScanPage.isMispickedCartonDisplayed(cartonNumber);
			logger.info("Cartons scanned today is displayed in Discrepancies Home screen today");
		} 
	public void SRA1357_ValidateYesterdayScannedCartons_AreNotdisplayedInDiscrepanciesHomeScreenToday()
			throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
	
		Document doc = createDocFromFile("MispicksScannedTrue.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 9);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		
		String YesterdayDate = getDateDecreaseDay("yyyy-MM-dd", 1);
		Date UpdatedYesterdayDate = format.parse(YesterdayDate);
		logger.info("updated Yesterday date is " + UpdatedYesterdayDate);
		
		// Change the scanned Time and Mispicked scanned Time To yesterday
		((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", UpdatedYesterdayDate);
		((List<Document>) doc.get("Cartons")).get(0).put("MispickScannedTime", UpdatedYesterdayDate);
		updateDocToDb(doc);
		
		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);
		
		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnAuditing();
		auditingPage.clickMispicks();
		Thread.sleep(2000);
		// To validate if the cartons scanned yesterday is not displayed in Discrepancies home screen today
		mispicksScanPage.isMispickedCartonNotDisplayed(cartonNumber);
		logger.info("Yesterday scanned Cartons are not displayed in Discrepancies Home screen today");

		} 
}
