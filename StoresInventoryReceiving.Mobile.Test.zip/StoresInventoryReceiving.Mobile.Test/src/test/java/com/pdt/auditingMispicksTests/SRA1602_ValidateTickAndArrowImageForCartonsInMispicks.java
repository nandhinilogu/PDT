package com.pdt.auditingMispicksTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate Arrow image and tick Image  is visible to received cartons in Mispicks")
@Description("Validate Arrow image and tick Image  is visible to received cartons in Mispicks")
public class SRA1602_ValidateTickAndArrowImageForCartonsInMispicks extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA1602_ValidateTickAndArrowImageForCartonsInMispicks");

	public void SRA1602_validateTickAndArrowImageForCartonsInMispicks() throws ParseException, IOException, InterruptedException {

		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		AuditingPage auditingPage = new AuditingPage();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		
		Document doc = createDocFromFile("Mispicks.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		String storeNumber = doc.getString("DestinationStoreNumber");

		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton marked as mispicks is " + cartonNumber);
		
		login.loginInMRA(storeNumber, getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();

		receivingShipmentScanPage.addCartonAsReceived(cartonNumber);
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		mispicksScanPage.addMispickedCarton(cartonNumber);
		
		Screen s = new Screen();
		Pattern pattern = new Pattern("arrow_image.PNG");
		boolean found = false;
		if (s.exists(pattern) != null) {
			found = true;
			logger.info("Arrow image found");
		}
		Assert.assertTrue(found);
		
		mispicksScanPage.clickOnSubmitMispicksButton();
		androidDriverConfig.clearData();
		login.loginInMRA(storeNumber, getProperty("valid_username9792"), getProperty("valid_password9792"));
		
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickMispicks();
		Thread.sleep(2000);
		
		Pattern tickimagepattern = new Pattern("tick_image.PNG");
		boolean foundtick = false;
		if (s.exists(tickimagepattern) != null) {
			foundtick = true;
			logger.info("Tick image found");
		}
		Assert.assertTrue(foundtick);

	}

}
