package com.pdt.AuditingInTransitDamages;

import static com.util.BaseUtil.getDateDecreaseDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description ="To validate adding an yesterday Scanned Orphan carton to the In-Transit Damages Home Screen")
@Description("To validate adding an Yesterday Scanned Orphan carton to the In-Transit Damages Home Screen")


public class SRA1631_1588_ValidateNotAbleAddYesterdayScannedOrphanCartons extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA1631_1588_ValidateNotAbleAddYesterdayScannedOrphanCartons.class.getName());
	HomePage home=new HomePage();
	
	public void SRA1631_VerifyNotAbleAddYesterdayScannedOrphanCartons() throws IOException, ParseException{
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();

			Document doc = createDocFromFile("OrphanCarton_withoutSkus.json");
			updateDocInOrphanCartonCollection(doc);

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String yesterdayDate = getDateDecreaseDay("yyyy-MM-dd", 1);
			Date UpdatedYesterdayDate = format.parse(yesterdayDate);
			logger.info("updated Yesterday date is " + UpdatedYesterdayDate);

			logger.info("Change the scanned Time To yesterday"); 
		    doc.put("ScannedTime", UpdatedYesterdayDate);
			doc.put("IsScanned", true);
			doc.put("ScannedBy", "9792");
			updateDocInOrphanCartonCollection(doc);
			
			String orphanCartonNumber = doc.getString("CartonNumber");
			logger.info("orphanCartonNumber is " + orphanCartonNumber);


			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			
			homescreen.clickOnAuditing();
			auditingPage.clickInTransitDamages();
			inTransitDamagePage.addInvalidCartonNumberToInTransitDamages(orphanCartonNumber);
			logger.info("Cartons scanned yesterday is not added to In-Transit Damages");
			}

}
