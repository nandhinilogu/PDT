package com.pdt.AuditingInTransitDamages;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To Validate if Today Damaged Carton is Displayed in In-Transit home Page")
@Description("To Validate if Today Damaged Carton is Displayed in In-Transit home Page")

public class SRA189_1479_ValidateTodayDamagedCarton_DisplayedIn_InTansitHomeScreen extends BaseTest {

	final static Logger logger = Logger
			.getLogger(SRA189_1479_ValidateTodayDamagedCarton_DisplayedIn_InTansitHomeScreen.class.getName());

	public void SRA1479_ValidateTodayDamagedCarton_DisplayedIn_InTansitHomeScreen() throws IOException, ParseException {
		SoftAssert assertion = new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();

		Document doc = createDocFromFile("SRA16_MarkCartonAsDamaged.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipmentscan.markCartonAsDamaged("0010411114716R", "1", assertion);
		receivingShipmentscan.submitDamagedCarton();
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickInTransitDamages();

		boolean damagedCartonNumber = inTransitDamagePage.isDamagedCartonDisplayed("0010411114716R");
		Assert.assertTrue(damagedCartonNumber);
		logger.info("Cartons marked Damaged today is displayed in In-Transit Home screen");

		// inTransitDamagePage.getCssvalue("0010411114716R");
		inTransitDamagePage.verifyDamagedQuantity("0010411114716R", "1");

	}

}
