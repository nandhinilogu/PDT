package com.pdt.AuditingInTransitDamages;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate Arrow image and tick Image  is visible to received cartons in In-Transit Damages")
@Description("Validate Arrow image and tick Image  is visible to received cartons in In-Transit damages")
public class SRA1602_ValidateTickAndArrowImageForCartonsInInTransitDamages extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA1602_ValidateTickAndArrowImageForCartonsInInTransitDamages");

	public void SRA1602_validateTickAndArrowImageForCartonsInInTransitDamages() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();

		Document doc = createDocFromFile("SRA16_MarkCartonAsDamaged.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);

		String storeNumber = doc.getString("DestinationStoreNumber");

		login.loginInMRA(storeNumber, getProperty("valid_username9792"), getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();

		receivingShipmentscan.addCartonAsReceived(cartonNumber);
		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickInTransitDamages();

		inTransitDamagePage.addCartonToInTransitDamages(cartonNumber);

		Screen s = new Screen();
		Pattern pattern = new Pattern("arrow_image.PNG");
		boolean found = false;
		if (s.exists(pattern) != null) {
			found = true;
			logger.info("Arrow image found");
		}
		Assert.assertTrue(found);

		inTransitDamagePage.clickOnSubmitDamagesButton();
		androidDriverConfig.clearData();
		login.loginInMRA(storeNumber, getProperty("valid_username9792"), getProperty("valid_password9792"));

		homescreen.clickOnMenuBar();
		homescreen.clickOnAuditingOnSideMenuBar();
		auditingPage.clickInTransitDamages();
		Thread.sleep(2000);

		Pattern tickimagepattern = new Pattern("tick_image.PNG");
		boolean foundtick = false;
		if (s.exists(tickimagepattern) != null) {
			foundtick = true;
			logger.info("Tick image found");
		}
		Assert.assertTrue(foundtick);
		
		Pattern Damagepattern = new Pattern("DamagedCarton.png");
		boolean DamagedCartonImage = false;
		if (s.exists(Damagepattern) != null) {
			DamagedCartonImage = true;
			logger.info("Damaged Carton image found");
		}
		Assert.assertTrue(DamagedCartonImage);

	}

}
