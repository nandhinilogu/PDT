package com.pdt.purchaseOrderTest;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;

import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating SKU Detail in PO#")
@Description("Validating SKU Detail in Receive PO#")

public class SRA897_1305_ValidateSkuDetailsInPurchaseOrder extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA897_1305_ValidateSkuDetailsInPurchaseOrder.class.getName());

	String storeNumber = null;
	String purchaseOrderNumber = null;
	String skuNumber = null;
	int shippedQuantity=0;

	@SuppressWarnings("unchecked")
	public void SRA1305_ValidateSkuDetailInPO() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		SoftAssert softassert = new SoftAssert();

		
			Document doc = createDocFromFile("PO135.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 6);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			storeNumber = doc.getString("DestinationStoreNumber");
			purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			skuNumber = ((List<Document>) doc.get("SKUs")).get(0).getString("SkuNumber");
			logger.info("skuNumber " + skuNumber);

			shippedQuantity = ((List<Document>) doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
			logger.info("shippedQuantity " + shippedQuantity);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + storeNumber);
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validatingSkuDetailInPurchaseOrder(purchaseOrderNumber, skuNumber,softassert,storeNumber);
			purchaseOrderPage.editQuantityInPO(String.valueOf(shippedQuantity));
			softassert.assertAll();

		
	}

	@Test(dependsOnMethods="SRA1305_ValidateSkuDetailInPO")
	public void SRA1305_ValidateSkuDetailInPOForCompletelyReceived() throws ParseException, IOException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		SoftAssert softassert = new SoftAssert();

		

			logger.info("PO is Number " + purchaseOrderNumber);
			logger.info("skuNumber " + skuNumber);
			logger.info("shippedQuantity " + shippedQuantity);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + storeNumber);
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validatingSkuDetailInPOForCompletelyReceived(purchaseOrderNumber, skuNumber,String.valueOf(shippedQuantity),softassert,storeNumber);
			softassert.assertAll();
	}

}
