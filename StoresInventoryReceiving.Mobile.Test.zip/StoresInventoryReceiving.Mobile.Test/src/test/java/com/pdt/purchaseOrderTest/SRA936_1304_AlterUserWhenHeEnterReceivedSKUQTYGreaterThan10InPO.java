package com.pdt.purchaseOrderTest;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating Alert message when received sku qty is greater than 10 in PO")
@Description("Validating Alert message when received sku qty is greater than 10 in PO")
public class SRA936_1304_AlterUserWhenHeEnterReceivedSKUQTYGreaterThan10InPO extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA_1304");

	public void SRA_1304_validateAlertMessageForSkuQtyGreaterThan10() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();

		try {

			Document doc = createDocFromFile("PO313.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + this.getProperty("valid_storeno2"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();

			// To validate alert message when associate receives qty more than 10
			purchaseOrderPage.validateAlertMessageWhenReceivingSkuQtyGreaterThan10("11");

			// To validate if click on No button does not save the edited sku qty
			purchaseOrderPage.validateSkuQtyNotChangedWhenClickingOnNoButtonInAlertMessage("12");

			// To validate if associate is able to edit the received SKU qty upto 99
			purchaseOrderPage.validateAbleToEditReceivedQtyUpTo99("99");

			// Verify the associate is not able to see the alert pop-up when the received
			// qty is 10
			purchaseOrderPage.validateAlterMessageNotDisplayedWhenReceivedQtyIs10("10");

			// Validate associates is not able to edit the received SKU Qty above 99
			purchaseOrderPage.validateNotAbletoEditReceivedQtyAbove99("110");
		} catch (Exception rx) {
			rx.printStackTrace();
		}

		
	}

}
