package com.pdt.purchaseOrderTest;



import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Listeners(BaseListener.class)
@Test(description = "Purchase Order DetailPage")
@Stories("Validate total pending Quantity in PO Detail Page after Quantity Edit")
@Description("Purchase Order DetailPage")
@Features("regression")
public class SRA131_1362_ValidateCounterOfPendingQtyAfterEditInPO extends BaseTest{
	
	final static Logger logger = Logger.getLogger("SRA131_1362");
	
	public void SRA1362_ValidateCountOfPendingQtyDecrementAfterEditInPO() throws ParseException, IOException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		
		
			Document doc = createDocFromFile("PO135.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 6);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			String skuNumber = ((List<Document>) doc.get("SKUs")).get(0).getString("SkuNumber");
			logger.info("skuNumber " + skuNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validateTotalPendingQTYInPOAfterQuantityEdit(purchaseOrderNumber,skuNumber,"3",storeNumber);
			
		
		
      
		
	}
	
	public void SRA1362_ValidateCountOfPendingQtyAfterLogout(){
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		
		try{
			Document doc = createDocFromFile("PO135.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 6);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			String skuNumber = ((List<Document>) doc.get("SKUs")).get(1).getString("SkuNumber");
			logger.info("skuNumber " + skuNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			
			String receviedQtyBeforeLogout=purchaseOrderPage.editCountOfPendingQuantitywithoutsubmit(purchaseOrderNumber, skuNumber, "4");
			String totalPendingQtyBeforeLogout = purchaseOrderPage.getTotalPendingQtyPODetailPage();
			
			logger.info("Pending QTY Before Logout is "+totalPendingQtyBeforeLogout);
			logger.info("Received QTY Before Logout is "+receviedQtyBeforeLogout);
	        
	        homescreen.clickOnMenuBar();
			homescreen.logout();
			login.loginWithRegisteredStore(this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validateCountOfPendingQuantityAfterLogout(purchaseOrderNumber, totalPendingQtyBeforeLogout, receviedQtyBeforeLogout, skuNumber);
		}
		
		 catch (IOException | ParseException e) {
				
				e.printStackTrace();
			}
			
		
	}

}
