package com.pdt.purchaseOrderTest;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Purchase Order HomePage")
@Description("Serach for  new and partially Received Purchase Orders")

public class SRA139_1477_ValidatePrintTicketPageInPurchaseOrder extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA139_1477");

	@SuppressWarnings("unchecked")
	public void SRA1477_ValidateSkuQuantityInPrintTicketPage() {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SoftAssert softassert= new SoftAssert();
		
		try {
			Document doc = createDocFromFile("PO313.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			((List<Document>)doc.get("SKUs")).get(0).put("ShippedQuantity", 8);
			((List<Document>)doc.get("SKUs")).get(0).put("ReceivedQuantity", 5);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrder.validateSkuQuantityInPrintTicketPage(purchaseOrderNumber,softassert,storeNumber);
			softassert.assertAll();
		}

		catch (IOException | ParseException | ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
		

	}
	
	@SuppressWarnings("unchecked")
	public void SRA1477_ValidateAbleToEditPrintQuantity(){
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SoftAssert softassert= new SoftAssert();
		
		try {
			Document doc = createDocFromFile("PO313.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			((List<Document>)doc.get("SKUs")).get(0).put("ShippedQuantity", 8);
			((List<Document>)doc.get("SKUs")).get(0).put("ReceivedQuantity", 5);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrder.validateSkuQuantityEditInPrintTicketPage(purchaseOrderNumber, "2",softassert);
			purchaseOrder.validateNotAbletoPrintQtyAbove99("101",softassert);
			purchaseOrder.validateNotAbleToPrintZeroQuantity("0", softassert);
			softassert.assertAll();
		}

		catch (IOException | ParseException | InterruptedException e) {
			
			e.printStackTrace();
		}
		
		
	}
	
	
	@SuppressWarnings("unchecked")
	public void SRA1477_ValidatePrintButtonInPOPrintPage(){
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SoftAssert softassert = new SoftAssert();
		
		try {
			Document doc = createDocFromFile("PO313.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			((List<Document>)doc.get("SKUs")).get(0).put("ShippedQuantity", 8);
			((List<Document>)doc.get("SKUs")).get(0).put("ReceivedQuantity", 1);
			
			((List<Document>)doc.get("SKUs")).get(1).put("ShippedQuantity", 8);
			((List<Document>)doc.get("SKUs")).get(1).put("ReceivedQuantity", 3);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrder.validatePrintButtonInPOPrintPage(purchaseOrderNumber,softassert);
			
		}

		catch (IOException | ParseException | InterruptedException e) {
			
			e.printStackTrace();
		}
		
		
		
	}

}
