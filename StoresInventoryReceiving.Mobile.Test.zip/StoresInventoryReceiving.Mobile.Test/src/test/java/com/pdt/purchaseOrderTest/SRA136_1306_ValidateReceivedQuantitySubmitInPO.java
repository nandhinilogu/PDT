package com.pdt.purchaseOrderTest;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating the summary of Purchase Order After Submit")
@Description("Validating the summary of Purchase Order After Submit")

public class SRA136_1306_ValidateReceivedQuantitySubmitInPO extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA_1306");

	
	public void SRA1306_ValidateSummaryOfPurchaseOrderAfterSubmit() throws IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();

		
			Document doc = createDocFromFile("PO135.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + storeNumber);
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validateSummaryOfPurchaseOrderAfterSubmit(purchaseOrderNumber, "1",storeNumber);
		
	}

	
	public void SRA1306_ValidateSummaryOfPurchaseOrderAfterSubmitReceivedMoreThanExpected()
			throws IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();

			Document doc = createDocFromFile("PO313.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			logger.info("PO is Number " + purchaseOrderNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + storeNumber);
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validateSummaryOfPurchaseOrderAfterSubmit(purchaseOrderNumber, "6",storeNumber);
		
	}
	
	
	
	public void SRA1306_ValidateSummaryOfPurchaseOrderAfterSubmitCompletelyReceived() throws IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();

		
			Document doc = createDocFromFile("POwithSingleSku.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			String storeNumber = doc.getString("DestinationStoreNumber");
			String purchaseOrderNumber = doc.getString("PurchaseOrderNumber");
			
			logger.info("PO is Number " + purchaseOrderNumber);
			
			int shippedQty= ((List<Document>)doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
			logger.info("shippedQty "+shippedQty);
			
			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + storeNumber);
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.editQuantityOfPOForCompletelyReceived(purchaseOrderNumber, String.valueOf(shippedQty));
			homescreen.clickOnMenuBar();
			homescreen.logout();
			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			logger.info("Logged in Store is " + storeNumber);
			homescreen.clickOnReceiving();
			receivingPage.clickOnPurchaseOrder();
			purchaseOrderPage.validateSummaryOfPurchaseOrderAfterSubmitCompletelyReceived(purchaseOrderNumber);
			
		}

}
