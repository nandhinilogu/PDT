package com.pdt.MobileTicketing;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;
@Listeners(BaseListener.class)
@Test(description = "Validates Invalid SKU Error message in ItemLookUp and Ticketing Screen")
@Description("Validates Invalid SKU Error message in ItemLookUp and Ticketing Screen ")

public class SRA1689_1712_ValidateInvalidSKUInItemLookupAndTicketing extends BaseTest {
	
	final static Logger logger = Logger.getLogger(SRA1689_1712_ValidateInvalidSKUInItemLookupAndTicketing.class.getName());
	
  public void SRA1712_ValidateErrorMsgForInvalidSKUInItemLookUpAndTicketing() {
		
		LoginPage login = new LoginPage();
		HomePage home=new HomePage();
		MobileTicketingPage mobileTicketing=new MobileTicketingPage();
		
	

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		home.clickOnItemLookUp();
		mobileTicketing.IsItemLookUpHeadingDisplayed();
		
		mobileTicketing.validateErrorMsgForInvalidSku(getProperty("sku111123"));
		
}

}
