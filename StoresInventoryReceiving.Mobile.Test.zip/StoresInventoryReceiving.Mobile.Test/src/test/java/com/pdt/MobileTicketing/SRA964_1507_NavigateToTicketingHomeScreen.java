package com.pdt.MobileTicketing;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates the navigation to ticketing screen")
@Description("Validates the navigation to ticketing screen")

public class SRA964_1507_NavigateToTicketingHomeScreen extends BaseTest{
	final static Logger logger = Logger.getLogger(SRA964_1507_NavigateToTicketingHomeScreen.class.getName());
	
	public void navigationToHomeScreen() {
		LoginPage login = new LoginPage();
		HomePage home=new HomePage();
		MobileTicketingPage mobileTicketing=new MobileTicketingPage();
		SoftAssert softAssert= new SoftAssert();

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		
		home.clickOnItemLookUp();
		mobileTicketing.validateLookUpSkuTestBarDisplayed(softAssert);
		mobileTicketing.IsItemLookUpHeadingDisplayed();
		mobileTicketing.IsTicketingHeadingDisplayed(softAssert);
		mobileTicketing.validateGoBackBtnInLookUpHomeScreen(softAssert);
		
		
		home.clickOnMenuBar();
		home.clickOnItemLookUpAndTicketingOnSideMenuBar();
		mobileTicketing.validateLookUpSkuTestBarDisplayed(softAssert);
		mobileTicketing.IsItemLookUpHeadingDisplayed();
		mobileTicketing.IsTicketingHeadingDisplayed(softAssert);
		mobileTicketing.validateGoBackBtnInLookUpHomeScreen(softAssert);
		
		softAssert.assertAll();
	}

}
