package com.pdt.MobileTicketing;

import java.sql.SQLException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.util.DataBase.OracleDBConnection;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates sku Details in ItemLookUp")
@Description("Validates sku Details in ItemLookUp")

public class SRA966_1496_ValidateSkuDetailsWhenSkuAdded extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA966_1496_ValidateSkuDetailsWhenSkuAdded.class.getName());
	
	
	public void SRA1496_ValidateSkuDetailInItemLookUp() throws ClassNotFoundException, SQLException {
				
		LoginPage login = new LoginPage();
		HomePage home=new HomePage();
		MobileTicketingPage mobileTicketing=new MobileTicketingPage();
		OracleDBConnection oracleDB= new OracleDBConnection();
		SoftAssert softAssert= new SoftAssert();

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		home.clickOnItemLookUp();
		mobileTicketing.IsItemLookUpHeadingDisplayed();
		
		HashMap<String, String>  skuValueMap=oracleDB.getSkuPriceFromOracleDB(getProperty("sku3301702"), this.getProperty("valid_storeno104"));
		String skuPrice=skuValueMap.get("skuprice");
		String skudescription=skuValueMap.get("skuDescShort");
		logger.info("Sku Price from OracleDB "+skuPrice);
		logger.info("Sku shortDescription from OracleDB "+skudescription);
		
		mobileTicketing.validateSkuPriceAndDesc(getProperty("sku3301702"),softAssert,skuPrice,skudescription);
		mobileTicketing.validateErrorMsgForInvalidSku(getProperty("sku111123"));
		
		softAssert.assertAll();
	}

}
