package com.pdt.MobileTicketing;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates Carton Details in ItemLookUp and Ticketing Screen")
@Description("Validates Carton Details in ItemLookUp and Ticketing Screen ")

public class SRA1725_1706_ValidateCartonDetailsInItemLookupAndTicketing extends BaseTest {

	final static Logger logger = Logger
			.getLogger(SRA1725_1706_ValidateCartonDetailsInItemLookupAndTicketing.class.getName());

	@SuppressWarnings("unchecked")
	public void SRA1725_ValidateCartonDetailInItemLookUpAndTicketing() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		MobileTicketingPage mobileTicketing = new MobileTicketingPage();
		ValidateFromMongoDB mongoDB = new ValidateFromMongoDB();

		Document doc = createDocFromFile("ScannedCarton.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 10);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		String yesterdayDate = getDateDecreaseDay("yyyy-MM-dd", 1);
		Date UpdatedYesterdayDate = format.parse(yesterdayDate);
		logger.info("updated Yesterday date is " + UpdatedYesterdayDate);
		// Change the scanned Time and submitted Time To yesterday
		((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", UpdatedYesterdayDate);
		((List<Document>) doc.get("Cartons")).get(0).put("SubmittedDateTime", UpdatedYesterdayDate);
		updateDocToDb(doc);
		String shipmentNumber = doc.getString("ShipmentNumber");
		logger.info("ShipmentNumber inserted is " + shipmentNumber);

		
		
		HashMap<String, String> map = mongoDB.getReceivedCartonNumber(getProperty("valid_storeno2"));
		logger.info("Carton Number is -------" + map.get("dbCartonNumber"));

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		home.clickOnItemLookUp();
		mobileTicketing.IsItemLookUpHeadingDisplayed();

		mobileTicketing.validateCartonDetailsInTicketingPage(map.get("dbCartonNumber"), map.get("numberOfSku"),
				map.get("totalShippedQuantity"));

	}

}
