package com.pdt.MobileTicketing;

import org.apache.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MobileTicketingPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates skDescription in ItemLookUp")
@Description("Validates skDescription in ItemLookUp")

public class SRA1367_1521_ValidateSkuDescInItemLookUp extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA1367_1521_ValidateSkuDescInItemLookUp.class.getName());

	public void SRA1521_validateSkuDescOnEditScreen() {

		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		MobileTicketingPage mobileTicketing = new MobileTicketingPage();

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			home.clickOnItemLookUp();
			mobileTicketing.validateSkuDescInEditSkuScreen(getProperty("sku3301702"));
			logger.info("Sku description is displayed as Bl Chr Frt Blkrry");
	}

}
