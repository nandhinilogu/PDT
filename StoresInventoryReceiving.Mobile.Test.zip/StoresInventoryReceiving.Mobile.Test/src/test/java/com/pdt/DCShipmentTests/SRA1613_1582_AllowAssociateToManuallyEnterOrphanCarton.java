package com.pdt.DCShipmentTests;

import java.io.IOException;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To verify if associate is able to add a orphan carton")
@Description("To verify if associate is able to add a orphan carton")

public class SRA1613_1582_AllowAssociateToManuallyEnterOrphanCarton extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA1613_1582_AllowAssociateToManuallyEnterOrphanCarton.class.getName());



	public void SRA1613_SubmitOrphanCartonWithoutSkus() throws ParseException, IOException {

			LoginPage login = new LoginPage();
			HomePage homeScreen = new HomePage();
			ReceivingPage receivingPage = new ReceivingPage();
			ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
			String orphanCartonNumber = null;
			try{
				Document doc = createDocFromFile("OrphanCarton_withoutSKus.json");
				
				//updateDocInOrphanCartonCollection(doc);
				orphanCartonNumber = doc.getString("CartonNumber");
				logger.info("orphanCartonNumber is " + orphanCartonNumber);
				
				String destinationStoreNumber = doc.getString("DestinationStoreNumber");
				logger.info("DestinationStoreNumber is " + destinationStoreNumber);
				
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			homeScreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipmentScanPage.scanAndSubmitOrphanCartonWithoutSkus(orphanCartonNumber);
	}
			finally {
				
				deleteOrphanCarton(orphanCartonNumber);
		 }

}
	public void SRA1613_SubmitOrphanCartonByAddingSkus() throws ParseException, IOException {
		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		
		String orphanCartonNumber=null;
		try {
		Document doc = createDocFromFile("OrphanCarton_withSkus.json");
		//	updateDocInOrphanCartonCollection(doc);
		//	logger.info("Added  a record in orphan carton collection");
		
			
			 orphanCartonNumber = doc.getString("CartonNumber");
			logger.info("orphanCartonNumber is " + orphanCartonNumber);
			
			String destinationStoreNumber = doc.getString("DestinationStoreNumber");
			logger.info("DestinationStoreNumber is " + destinationStoreNumber);
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			homeScreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipmentScanPage.scanAndSubmitOrphanCartonWithSkus(orphanCartonNumber,"6999788");
			
			
		}
		finally {
			
			deleteOrphanCarton(orphanCartonNumber);
	 }
	}
	// Still pending is validation of the created orphan carton in Db has to be done
	

}
