
package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates Submitted Shipment  closes/Received in Global Search")
@Description("Validates Submitted Shipment  closes/Received in Global Search")

public class SRA22_1129_ValidateTheShipmentSubmittedCompletely extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA1129");
	
	public void SRA1129_ValidatesSubmittedShipmentCloses_ValidatesInGlobalSearch() throws IOException, ParseException {

		SoftAssert assertion = new SoftAssert();
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		GlobalSearchPage globalSearchPage = new GlobalSearchPage();

			Document doc = createDocFromFile("SRA22.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			updateDocToDb(doc);

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			ReceivingPage receivingPage = new ReceivingPage();
			receivingPage.clickOnDcShipment();
			receivingShipment.clickOnScanButton();
			receivingShipmentScanPage.initiateShipment("0010411114251S");
			receivingShipmentScanPage.initiateShipment("0010411113471S");
			receivingShipmentScanPage.initiateShipment("0010411113239S");
			receivingShipmentScanPage.clickOnShipmentSummery();
			receivingShipmentScanPage.clickOnSubmitShipmentSummery();
			boolean SubmittedMessageDisplayed = receivingShipmentScanPage.isSubmittedMessageDisplayed();
			assertion.assertTrue(SubmittedMessageDisplayed);
			receivingShipmentScanPage.clickOnOKButtonOnCartonSubmittedSuccessfully();

			
			globalSearchPage.searchDCShipmentCartonNumberInGlobalSearch("0010411114251S", assertion);
		}
	
	
	public void SRA1129_ValidateSubmittedCartonScannedTimeInDB() throws IOException, ParseException, InterruptedException {

		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();
		SoftAssert assertion = new SoftAssert();

			Document doc = createDocFromFile("SRA22.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipment.clickOnScanButton();
			
		
		    receivingShipmentScanPage.initiateShipment("0010411113471S");

			Thread.sleep(3000);
			//Validate scanned time is null Before submitting carton
			mongoDB.validateScannedTimeBeforeSubmit("0010411113471S", assertion,getProperty("valid_storeno104"));
			
			receivingShipmentScanPage.clickOnShipmentSummery();
			receivingShipmentScanPage.clickOnSubmitShipmentSummery();
			receivingShipmentScanPage.clickOnOKButtonOnCartonSubmittedSuccessfully();

			String scannedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
			logger.info("Current Scanned Time is "+scannedTime);
			
			Thread.sleep(3000);
			mongoDB.validateScannedTimeAndReceivedQtyFromDB("0010411113471S", scannedTime, getProperty("valid_username9792"), assertion,getProperty("valid_storeno104"));
			
			assertion.assertAll();
			
		} 
}
