package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Verify unsaved data is in cache ")
@Description("Verify unsaved data is in cache ")

public class SRA4_Verify_UnsavedData extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA4_Verify_UnsavedData.class.getName());

	public void SRA4_verify_UnsavedData_InStoreToStoreTransfer()
			throws ParseException, FileNotFoundException, IOException {
		LoginPage loginScreen = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendTransfer = new SendStoreTransferPage();
		HomePage homeScreen = new HomePage();
	
		loginScreen.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		
		homeScreen.clickOnReceiving();

		receivingPage.clickOnStoreToStoreTransfer();

		sendnReceivetransfer.clickOnSendStoreTransfer();

		sendTransfer.initiateTransfer(this.getProperty("valid_storeno2"));
		
		homeScreen.clickOnMenuBar();
		homeScreen.logout();

		loginScreen.loginWithRegisteredStore(this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));

		homeScreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendnReceivetransfer.clickOnSendStoreTransfer();
		
		boolean transferInProgress = sendTransfer.transferOrderisDisplayed();
		Assert.assertTrue(transferInProgress);
		}
		

	@SuppressWarnings("unchecked")
	public void SRA4_verify_UnsavedData_InShipment() throws ParseException, IOException {

		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();

	
		Document doc = createDocFromFile("SRA4_UnsavedData.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);

		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);
		
		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();		
		receivingShipmentScanPage.initiateShipmentToValidateUnsavedScenario(cartonNumber);
		homescreen.clickOnMenuBar();
		homescreen.logout();

		login.loginWithRegisteredStore(this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipment.clickOnScanButton();

		boolean scannedCartonDisplayed = receivingShipmentScanPage.IsScannedCartonDisplayed();
		Assert.assertTrue(scannedCartonDisplayed);
		
		}
		
	@SuppressWarnings("unchecked")
	public void SRA4_verify_UnsavedData_InTransitDamages() throws ParseException, FileNotFoundException, IOException {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage auditingscanpage = new AuditingInTransitDamagesScanPage();

		Document doc = createDocFromFile("SRA4.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 0);
		Date today = format.parse(todayDate);
		((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", today);
		updateDocToDb(doc);
		
		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnAuditing();
		auditingPage.clickInTransitDamages();
		auditingscanpage.initiateInTransitDamages(cartonNumber);

		homescreen.clickOnMenuBar();
		homescreen.logout();

		login.loginWithRegisteredStore(this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
		homescreen.clickOnAuditing();
		auditingPage.clickInTransitDamages();

		boolean isDisplayed = auditingscanpage.inTransitDamagedCartonDisplayed();
		Assert.assertTrue(isDisplayed);
		}
	

	@SuppressWarnings("unchecked")
	public void SRA4_verify_unsaveData_inMispicks() throws ParseException, IOException {

		LoginPage login = new LoginPage();
		HomePage homepage = new HomePage();
		AuditingPage auditingpage = new AuditingPage();
		MispicksScanPage mispickpage = new MispicksScanPage();

		Document doc = createDocFromFile("SRA4.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String fewDaysOld = getDateDecreaseDay("yyyy-MM-dd", 4);
		Date fiveDaysOld = format.parse(fewDaysOld);
		((List<Document>) doc.get("Cartons")).get(0).put("ScannedTime", fiveDaysOld);
		updateDocToDb(doc);

		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homepage.clickOnAuditing();
		auditingpage.clickMispicks();
		mispickpage.initiate_MisPickForUnsavedData(cartonNumber);
		homepage.clickOnMenuBar();
		homepage.logout();

		login.loginWithRegisteredStore(this.getProperty("valid_username9792"), this.getProperty("valid_password9792"));
		homepage.clickOnAuditing();
		auditingpage.clickMispicks();

		boolean cartonDisplayed = mispickpage.isCartonDisplayed();
		Assert.assertTrue(cartonDisplayed);
		
		}

}
