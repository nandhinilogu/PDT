package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Alert for duplicate carton in Shipment ")
@Description("Alert for duplicate carton in Shipment ")

public class SRA13_1098_1094_AlertForDuplicateScans extends BaseTest {

	final static Logger logger = Logger.getLogger("SRA13_1098_1094");

	public void SRA_1098_AlertForDuplicateCartonScan() throws IOException, ParseException {
		LoginPage loginScreen = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		
			Document doc = createDocFromFile("SRA26.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);
			
			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);
			
			
			loginScreen.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipmentScanPage.addCartonAsReceived(cartonNumber);
			receivingShipmentScanPage.clickOnContinueScanning();
			receivingShipmentScanPage.validatingDuplicateCartonNumber(cartonNumber);
			
	}

}
