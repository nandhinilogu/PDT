package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Scan carton before submission")
@Description("Scan carton before submission")

public class SRA15_1100_ValidateTheValidCartonReceiving extends BaseTest {

	public void SRA_15_AddCartonNumberAsReceived() throws ParseException, FileNotFoundException, IOException {
		SoftAssert assertion = new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
	
			Document doc = createDocFromFile("SRA15_ReceiveCarton.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			updateDocToDb(doc);

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();

			receivingShipmentScanPage.initiateShipmentToAddCartonAsReceived("0010411119265S");
			home.clickOnMenuBar();
			home.logout();
			login.loginWithRegisteredStore(getProperty("valid_username9792"), getProperty("valid_password9792"));
			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipment.clickOnScanButton();

			boolean isCartonDisplayed = receivingShipmentScanPage.IsScannedCartonDisplayed();
			assertion.assertTrue(isCartonDisplayed);
		} 
	public void SRA_15_AddCartonNumberAsReceivedWithIncorrectLast4Digits() throws ParseException, IOException {

		LoginPage login = new LoginPage();
		HomePage home = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();


			Document doc = createDocFromFile("SRA15_ReceiveCartonForIncorrectDigit.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			updateDocToDb(doc);

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipment.clickOnScanButton();

			receivingShipmentScanPage.initiateShipmentWithINCorrectDigits("0010411114699R");
		} 
}

