package com.pdt.DCShipmentTests;


import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates Last carton appears on top in the carton scanned list")
@Description("Validates Last carton appears on top in the carton scanned list")

public class SRA827_1181_ValidateLastInFirstOutOrderCartonNumber extends BaseTest {

	public void SRA1181_validateCartonArrangedInLifo() throws IOException, ParseException {

		HomePage homescreen = new HomePage();

		Document doc = createDocFromFile("SRA827_1181.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);

		updateDocToDb(doc);

		LoginPage login = new LoginPage();

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		ReceivingPage receivingPage = new ReceivingPage();
		receivingPage.clickOnDcShipment();

		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();

		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		receivingShipment.clickOnScanButton();
		receivingShipmentScanPage.initiateShipment("0010411116976R");
		receivingShipmentScanPage.initiateShipment("0010411114836R");
		String firstscannedCartonValue = receivingShipmentScanPage.firstscannedCartonValue();
		Assert.assertEquals(firstscannedCartonValue, "Carton #0010411114836R");

	}

}
