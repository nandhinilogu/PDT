package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates Submitted Shipment Closes In ShipmentSummery")
@Description("Validates Submitted Shipment Closes In Shipment Summery")

public class SRA26_1167_ValidateScannedNSubmittedShipmentIsClosed extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA26_1167_ValidateScannedNSubmittedShipmentIsClosed.class.getName());
	

	@SuppressWarnings("unchecked")
	public void SRA1167_validatesSubmittedShipmentClosesInShipmentSummery() throws IOException, ParseException {

		SoftAssert assertion = new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();

			Document doc = createDocFromFile("SRA26_ScannedFalse.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);
			
			String firstCartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + firstCartonNumber);
			
			String secondCartonNumber = ((List<Document>) doc.get("Cartons")).get(1).getString("CartonNumber");
			logger.info("carton number is " + firstCartonNumber);
			
			String thirdCartonNumber = ((List<Document>) doc.get("Cartons")).get(2).getString("CartonNumber");
			logger.info("carton number is " + firstCartonNumber);

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();

			receivingPage.clickOnDcShipment();
			receivingShipment.clickOnScanButton();
			receivingShipmentScanPage.initiateShipment(firstCartonNumber);
			receivingShipmentScanPage.initiateShipment(secondCartonNumber);
			receivingShipmentScanPage.initiateShipment(thirdCartonNumber);
			receivingShipmentScanPage.validateShipmentNotVisibleInShipmentSummery(assertion);
		} 

	public void SRA1167_validatesTheShipmentExistsIfCartonPartiallySubmitted() throws IOException, ParseException {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
	
			Document doc = createDocFromFile("SRA26.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);
			
			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);
			
			String shipmentNumber = doc.getString("ShipmentNumber");

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();

			receivingPage.clickOnDcShipment();

			// receivingShipment.validateCartonValueBeforeScanning();
			receivingShipment.clickOnScanButton();

			receivingShipmentScanPage.initiateShipment(cartonNumber);

			receivingShipmentScanPage.validatePartialShipmentExistInShipmentSummery(shipmentNumber);
		} 
}
