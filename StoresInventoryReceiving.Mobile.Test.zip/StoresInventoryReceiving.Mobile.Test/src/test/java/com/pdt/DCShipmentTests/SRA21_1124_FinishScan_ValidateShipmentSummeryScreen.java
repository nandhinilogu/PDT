package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.DataBase.MongoDBManager;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Finish scan and validate the summery")
@Description("Finish scan and validate the summery")


public class SRA21_1124_FinishScan_ValidateShipmentSummeryScreen extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA21_1124_FinishScan_ValidateShipmentSummeryScreen.class.getName());

	public void SRA1124_validateExpectedCartonQty() throws IOException, ParseException {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();

			/*Document doc = createDocFromFile("SRA21_1124_2.json");
			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(new Date());
			calendar1.set(Calendar.HOUR_OF_DAY, 0);
			calendar1.set(Calendar.MINUTE, 0);
			calendar1.set(Calendar.SECOND, 0);
			calendar1.set(Calendar.MILLISECOND, 0);
			Date cartonExpectedToday1 = calendar1.getTime();
			doc.put("EtaDateTime", cartonExpectedToday1);
			updateDocToDb(doc);*/
            
            
            Document doc = createDocFromFile("SRA21_1124_2.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 0);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);
			logger.info("Date is "+ExpectedArrival);

			
			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipment.clickOnScanButton();
			
			int qty = new ValidateFromMongoDB().getExpectedCartonQuantity(MongoDBManager.getCollection(),this.getProperty("valid_storeno104"));
			logger.info("Expected quantity from DB is "+qty);
			
			receivingShipmentScanPage.validateExpectedCartonQuantity(qty);
			
			receivingShipmentScanPage.validateExpectedCartonDetails("Carton #0010411113680S", "3823312", qty);
			
			receivingShipmentScanPage.validateCartonDetailsInShipmentSummaryPage(qty, "1","0");
			
			
			

		} 
}
