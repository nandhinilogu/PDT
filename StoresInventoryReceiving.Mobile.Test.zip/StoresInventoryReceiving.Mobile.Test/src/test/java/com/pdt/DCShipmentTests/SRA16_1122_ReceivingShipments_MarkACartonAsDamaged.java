package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.AuditingPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Mark a carton as damaged")
@Description("Mark a carton as damaged")

public class SRA16_1122_ReceivingShipments_MarkACartonAsDamaged extends BaseTest {

	public void SRA16_MarkACartonAsDamaged() throws IOException, ParseException {
		SoftAssert assertion = new SoftAssert();
		HomePage home = new HomePage();
		ReceivingShipmentScanPage receivingShipmentscan = new ReceivingShipmentScanPage();
		LoginPage login = new LoginPage();
		ReceivingPage receivingPage = new ReceivingPage();
		AuditingPage auditingPage = new AuditingPage();
		AuditingInTransitDamagesScanPage transitScanPage = new AuditingInTransitDamagesScanPage();

			Document doc = createDocFromFile("SRA16_MarkCartonAsDamaged.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			home.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			receivingShipmentscan.markCartonAsDamaged("0010411114716R", "1", assertion);
			
			receivingShipmentscan.clickSkuNumber();
			String damagedQtyOnReceivingScreen = receivingShipmentscan.damagedSkuQtyOnDetailPage();
			assertion.assertEquals(damagedQtyOnReceivingScreen, "1");

			receivingShipmentscan.clickOnGoBackButton();
			receivingShipmentscan.clickOnGoBackButtonOnCarton();
			receivingShipmentscan.clickOnShipmentSummery();
			receivingShipmentscan.clickOnSubmitShipmentSummery();
			receivingShipmentscan.clickOnOkButtonOnCartonSucceefullySubmitted();

			home.clickOnMenuBar();
			home.clickOnAuditingOnSideMenuBar();
			auditingPage.clickInTransitDamages();
			String damagedCartonNumber = transitScanPage.validatingCartonNumberOnInTransitDamage();
			assertion.assertEquals(damagedCartonNumber, "Carton #0010411114716R");

			transitScanPage.clickOnDamagedCarton();
			transitScanPage.clickSkuNumber();
			String damagedSKUQty = transitScanPage.getDamagedSKUQty();
			assertion.assertEquals(damagedSKUQty, "1");
			assertion.assertAll();
		} 

}
