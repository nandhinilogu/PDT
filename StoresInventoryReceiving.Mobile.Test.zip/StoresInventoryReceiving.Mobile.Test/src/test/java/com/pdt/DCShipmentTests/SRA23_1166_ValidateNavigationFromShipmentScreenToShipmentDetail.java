package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates the Navigation and scanned carton Value in Shipment Summery ")
@Description("Validates the Navigation and scanned carton Value in Shipment Summery ")

public class SRA23_1166_ValidateNavigationFromShipmentScreenToShipmentDetail extends BaseTest {

	public void SRA1166_validateTheScannedCartonValueAndTheCartons() throws ParseException, IOException {

		HomePage homescreen = new HomePage();

		Document doc = createDocFromFile("SRA23.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);

		updateDocToDb(doc);

		LoginPage login = new LoginPage();

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		ReceivingPage receivingPage = new ReceivingPage();
		receivingPage.clickOnDcShipment();

		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		receivingShipmentScanPage.initiateShipmentToViewScannedCartonsInShipmentSummery("0010411112116R");
		

	}

}
