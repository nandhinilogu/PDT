package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.mongodb.client.MongoCollection;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.util.DataBase.MongoDBManager;
import com.util.DataBase.MongoDBQueryStore;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Search For A Shipment  ")
@Description("Search For A Shipment  ")

public class SRA8_1096_Search_For_A_Shipment extends BaseTest {

	@Test(description = "To verify if Associate is able to search for a shipment")
	@Description("Description:To verify if Associate is able to search for a shipment")



	public void SRA8_1096_searchForAShipment() throws ParseException, IOException {

	
			Document doc = createDocFromFile("SRA7_DcShipment1.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);

			updateDocToDb(doc);

			MongoDBQueryStore mongoDB = new MongoDBQueryStore();
			MongoCollection<Document> collection = MongoDBManager.getCollection();
			ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();

			LoginPage login = new LoginPage();
			HomePage homeScreen = new HomePage();
			ReceivingPage receivingPage = new ReceivingPage();
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			homeScreen.clickOnReceiving();
			receivingPage.clickOnDcShipment();
			validateFromMongoDB.validateShipmentInfo(collection, "104");
	}

}
