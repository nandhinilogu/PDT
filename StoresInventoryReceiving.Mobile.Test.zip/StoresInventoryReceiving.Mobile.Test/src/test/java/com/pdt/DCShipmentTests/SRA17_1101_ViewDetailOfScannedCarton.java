package com.pdt.DCShipmentTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "View Detail of Scanned Carton")
@Description("View Detail of Scanned Carton")

public class SRA17_1101_ViewDetailOfScannedCarton extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA17_1101");

	public void SRA1101_viewDetailOfScannedCarton_SingleSku() throws IOException, ParseException {
		SoftAssert assertion =new SoftAssert();
		
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		ReceivingPage receivingPage = new ReceivingPage();
		ValidateFromMongoDB mongoDB= new ValidateFromMongoDB();

		Document doc = createDocFromFile("SRA17_ViewDetailOfScannedCarton.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(doc);
		
		
		String storeNumber = doc.getString("DestinationStoreNumber");
		String cartonNumber=mongoDB.getInTransitCartonNumberWithSingleSku(storeNumber);
		logger.info("Carton Number is -------"+cartonNumber);

		login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();
		receivingPage.clickOnDcShipment();
		receivingShipment.clickOnScanButton();
		
		receivingShipmentScanPage.recivingCartonToValidateCartonDetail(cartonNumber);
		
		receivingShipmentScanPage.validateSkuDetailsOfScannedCarton(cartonNumber, assertion ,this.getProperty("valid_storeno104"));
		assertion.assertAll();
		} 
	
//	public void SRA1101_viewDetailOfScannedCarton_MultipleSku() throws IOException, ParseException {
//		SoftAssert assertion =new SoftAssert();
//		HomePage homescreen = new HomePage();
//		LoginPage login = new LoginPage();
//		ReceivingPage receivingPage = new ReceivingPage();
//		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
//		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
//		
//		Document doc = createDocFromFile("Mispicks_MultipleSku.json");
//		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
//		Date ExpectedArrival = format.parse(EtaDate);
//		doc.put("EtaDateTime", ExpectedArrival);
//		updateDocToDb(doc);
//		
//		String cartonNumber = ((List<Document>) doc.get("Cartons")).get(1).getString("CartonNumber");
//		logger.info("carton number is " + cartonNumber);
//
//		
//		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
//				this.getProperty("valid_password9792"));
//		homescreen.clickOnReceiving();
//		receivingPage.clickOnDcShipment();
//		receivingShipment.clickOnScanButton();
//		receivingShipmentScanPage.recivingCartonToValidateCartonDetail(cartonNumber);
//		logger.info("Validate the sku details for scanned carton with multiple sku --> DB validation");
//		receivingShipmentScanPage.validateSkuDetailsOfScannedCartonWithMultipleSku(cartonNumber,assertion,this.getProperty("valid_storeno104"));
//		assertion.assertAll();
//	}
	}
	

