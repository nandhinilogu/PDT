package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "View sku details of a PO, edit and save special handling of a PO sku")
@Description("View sku details of a PO, edit and save special handling of a PO sku")

public class SRA312_1303_ValidateSkuDetailsForPOInSearch extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA312_1303_ValidateSkuDetailsForPOInSearch.class.getName());

	public void SRA1303_viewSkuOfPOInGlobalSearch() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document PO = createDocFromFile("PO312.json");
		SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");

		// String EtaDateForPO = getDateDecreaseDay("yyyy-MM-dd", 364);

		String EtaDateForPO = getDateIncementDay("yyyy-MM-dd", 30);
		Date ExpectedArrivalForPO = format2.parse(EtaDateForPO);
		PO.put("ETADateTime", ExpectedArrivalForPO);
		updateDocInPOCollection(PO);

		logger.info("Added record for PO");

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.editAndSaveSpecialHandlingForPOSku(getProperty("sku2374722"));
		

	}

	
	public void SRA1303_viewSkuOfPOInGlobalSearchETAMoreThan30Days() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document PO = createDocFromFile("PO312_2.json");
		SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");

		// String EtaDateForPO = getDateDecreaseDay("yyyy-MM-dd", 364);

		String EtaDateForPO = getDateIncementDay("yyyy-MM-dd", 32);
		Date ExpectedArrivalForPO = format2.parse(EtaDateForPO);
		PO.put("ETADateTime", ExpectedArrivalForPO);
		updateDocInPOCollection(PO);

		logger.info("Added record for PO");

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateTheErrorMsgNoSkuFound(getProperty("sku1111711"));


	}
	public void SRA1302_validateSpecialHandlingForPOLessThan30Days() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		

		GlobalSearchPage globalSearch = new GlobalSearchPage();
		
			Document doc = createDocFromFile("PO313.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 31);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);

			updateDocInPOCollection(doc);

			login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			globalSearch.receivingPOMoreThan30DaysInGlobalSearch(getProperty("poNumber11116700"));
			logger.info("No sku found error msg displayed");
		

	}
}
