package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "validate sku details of a store Transfer in Global Search and mark and validate the special handling")
@Description("Validate sku details of a store Transfer in Global Search")

public class SRA320_1301_ViewStoreTransferDetailsInSearchForASku extends BaseTest {
	
	final static Logger logger = Logger.getLogger(SRA320_1301_ViewStoreTransferDetailsInSearchForASku.class.getName());
	public void SRA1301_validateMarkSpecialHandlingForTheTransferSKuInSearch() throws IOException, ParseException {
		LoginPage login = new LoginPage();
		
		
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		ReceivingTransferPage receivingTransferPage = new ReceivingTransferPage();

		

		Document storeTransfer = createDocFromFile("StoreSRA578.json");
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		
		String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd", 30);
		Date ExpectedArrivalForStoreTransfer = format1.parse(EtaDateForStoreTransfer);
		storeTransfer.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(storeTransfer);
		
		

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		globalSearch.validateSkuDetailsForStoreTransfer(getProperty("sku5739995"));
		globalSearch.setSpecialHandlingForAStoreTransferSku(getProperty("sku5739995"));
		receivingTransferPage.validateSpecialHandlingInReceivingTransfer(getProperty("transferNo200450"),
				getProperty("sku5739995"));
		
		
		

		// logger.info("Added record for sendStoreTransfer");

	}

	public void SRA1301_validateETAMoreThan31DaysForReceivedSkuInGlobalSearch() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		

		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document storeTransfer1 = createDocFromFile("StoresSRA320_2.json");
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		
		
		// String EtaDateForStoreTransfer =getDateDecreaseDay("yyyy-MM-dd", 363);
		String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd", 32);
		Date ExpectedArrivalForStoreTransfer = format1.parse(EtaDateForStoreTransfer);
		storeTransfer1.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(storeTransfer1);

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateReceivedTransferETA30DaysLessOrMoreInGlobalSearch(getProperty("sku1111291"));
		logger.info("No sku found message displayed");
		

	}
	
	public void SRA1301_validateETALessThan31DaysForReceivedSkuInGlobalSearch() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();

		GlobalSearchPage globalSearch = new GlobalSearchPage();
		
		Document storeTransfer1 = createDocFromFile("StoresSRA320_2.json");
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		
		
		String EtaDateForStoreTransfer = getDateDecreaseDay("yyyy-MM-dd", 32);
		//String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd", 32);
		Date ExpectedArrivalForStoreTransfer = format1.parse(EtaDateForStoreTransfer);
		storeTransfer1.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(storeTransfer1);

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateReceivedTransferETA30DaysLessOrMoreInGlobalSearch(getProperty("sku1111291"));
		logger.info("No sku found message displayed");
		

	}
}
