package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "View the transfer summery with global seacrh")
@Description("View the transfer summery with global seacrh")

// By Harmeet

public class SRA785_1251_ViewTransferDetailsWithGlobalSearch extends BaseTest {

	public void SRA1251_validateTheTransferDetailsInGlobalSearch() throws InterruptedException, IOException, ParseException {

		Document doc = createDocFromFile("StoreSRA785.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);

		updateDocToStoreTransferDb(doc);

		LoginPage login = new LoginPage();

		GlobalSearchPage globalSearchPage = new GlobalSearchPage();

		// login as storeNo: 2
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		globalSearchPage.clickOnGlobalSearch();
		globalSearchPage.searchForTransferID(getProperty("transferNumber200449"));
		globalSearchPage.validateSkuDetailsInGlobalSearch();

	}

}
