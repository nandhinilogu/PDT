package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate tick and Dot Image is visible for transfer in Global Search")
@Description("Validate tick and Dot Image is visible for transfer in Global Search")

public class SRA1602_ValidateTickAndDotImageForTransferInGlobalSearch extends BaseTest{
	
	final static Logger logger = Logger.getLogger("SRA1602_ValidateTickAndDotImageForTransferInGlobalSearch");
	
	public void SRA1602_validateTickAndDotImageForTransferInGlobalSearch() throws IOException, ParseException{
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		
		Document doc = createDocFromFile("SRA582Transfer.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 7);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);
		updateDocToStoreTransferDb(doc);

		String transferNumber = doc.getString("TransferNumber");
		String storeNumber = doc.getString("DestinationStoreNumber");
		logger.info("Transfer Number is -------"+transferNumber);
		
		int ShippedQuantity  = ((List<Document>) doc.get("SKUs")).get(0).getInteger("ShippedQuantity");
		logger.info("ShippedQuantity " + ShippedQuantity);
		String shippedQty=String.valueOf(ShippedQuantity);
		
         login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		
		globalSearch.enterTransferNumberInGlobalSearch(transferNumber);

		Screen s = new Screen();
		Pattern pattern = new Pattern("dot_image.PNG");

		boolean found = false;
		if (s.exists(pattern) != null) {
			found = true;
			logger.info("Dot image found");
		}
		Assert.assertTrue(found);

		homescreen.clickOnMenuBar();
		homescreen.clickOnStoreTransferOnSideMenuBar();
		sendnReceivetransfer.clickOnReceiveStoreTransfer();
		receiveStoreTransfer.editQuantityOfTransferForCompletelyReceived(transferNumber, shippedQty);
		
		globalSearch.enterTransferNumberInGlobalSearch(transferNumber);
		Pattern tickimagepattern = new Pattern("tick_image.PNG");

		boolean foundtick = false;
		if (s.exists(tickimagepattern) != null) {
			foundtick = true;
			logger.info("Tick image found");
		}
		Assert.assertTrue(foundtick);


		
	}

}
