package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating the Transfer number search in Global search")
@Description("Validating the Transfer number search in Global search")

public class SRA783_1253_validateTheGlobalSearchForCompletelyReceivedTransfer extends BaseTest {
	final static Logger logger = Logger
			.getLogger(SRA783_1253_validateTheGlobalSearchForCompletelyReceivedTransfer.class.getName());
	final String QtyRecdSku = "4";

	public void SRA1253_validateTheGlobalSearchForCompletelyReceivedTransfer() throws Exception {

		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();

		Document storeTransfer = createDocFromFile("StoreSRA578.json");
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");

		String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrivalForStoreTransfer = format1.parse(EtaDateForStoreTransfer);
		storeTransfer.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(storeTransfer);
		logger.info("Added record for sendStoreTransfer");

		login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homeScreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendnReceivetransfer.clickOnReceiveStoreTransfer();

		receiveStoreTransfer.validatecompletelyReceivingSkuInGlobalSearch(getProperty("transferNo200450"), QtyRecdSku,getProperty("valid_storeno2"));
		logger.info("SKU received completely");

	}

}
