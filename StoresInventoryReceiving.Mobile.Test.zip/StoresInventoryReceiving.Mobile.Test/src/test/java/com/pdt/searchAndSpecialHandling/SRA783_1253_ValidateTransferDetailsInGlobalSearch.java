package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating the Transfer number search in Global search")
@Description("Validating the Transfer number search in Global search")

// By Harmeet

public class SRA783_1253_ValidateTransferDetailsInGlobalSearch extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA783_1253_ValidateTransferDetailsInGlobalSearch.class.getName());

	final String shippedQty = "5";
	final String QtyRecdSku = "5";

	public void SRA1253_validateTheGlobalSearchForPartiallyReceivedTransfer()
			throws InterruptedException, ParseException, IOException {

		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();

		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		Document storeTransfer = createDocFromFile("StoreSRA578.json");
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm");

		String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd hh:mm", 10);
		Date ExpectedArrivalForStoreTransfer = format1.parse(EtaDateForStoreTransfer);
		storeTransfer.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(storeTransfer);
		logger.info("Added record for sendStoreTransfer");

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));

		globalSearch.clickOnGlobalSearch();
		boolean transferNumberNotFoundMsg = globalSearch
				.validateTransferIDNotFoundInSendStore(getProperty("transferNo200450"));
		Assert.assertTrue(transferNumberNotFoundMsg);
		logger.info("Transfer number not found in SendStore");
		homeScreen.clickOnMenuBar();
		homeScreen.logout();

		login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homeScreen.clickOnReceiving();
		receivingPage.clickOnStoreToStoreTransfer();
		sendnReceivetransfer.clickOnReceiveStoreTransfer();

		// **validate the Transfer number and the ETA date in global Search for
		// non
		// received transfer

		globalSearch.validateTheUNReceivedTransferScenario(getProperty("transferNo200450"),getProperty("valid_storeno2"));

		// Partially submitting the transfer
		homeScreen.clickOnMenuBar();
		homeScreen.clickOnStoreTransferOnSideMenuBar();
		sendnReceivetransfer.clickOnReceiveStoreTransfer();

		// **Here we are validating that in case of partial sku recd , in the
		// global
		// search only for non received sku the edit option for special handling
		// will be
		// possible

		receiveStoreTransfer.partiallySubmittingTheTransfer(getProperty("transferNo200450"), shippedQty);
		logger.info("SKU is received only partially");

	}

}
