package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validates the GoBack Button in Global Search ")
@Description("Validates the GoBack Button in Global Search")

// By Harmeet
public class SRA784_1252_ValidateGoBackButtonOnGlobalSearch extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA784_1252_ValidateGoBackButtonOnGlobalSearch.class.getName());

	public void SRA1252_validatingGoBackButtonOnGlobalSearchForCarton() throws IOException, ParseException {

		SoftAssert assertion = new SoftAssert();
		HomePage homescreen = new HomePage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		LoginPage login = new LoginPage();
		GlobalSearchPage globalSearchPage = new GlobalSearchPage();
		ReceivingPage receivingPage = new ReceivingPage();

		Document doc = createDocFromFile("SRA784.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("EtaDateTime", ExpectedArrival);

		updateDocToDb(doc);

		login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
				this.getProperty("valid_password9792"));
		homescreen.clickOnReceiving();

		receivingPage.clickOnDcShipment();
		receivingShipment.clickOnScanButton();
		receivingShipmentScanPage.initiateShipment("0010411114252S");
		receivingShipmentScanPage.initiateShipment("0010411113472S");
		receivingShipmentScanPage.initiateShipment("0010411113232S");
		receivingShipmentScanPage.clickOnShipmentSummery();
		receivingShipmentScanPage.clickOnSubmitShipmentSummery();
		boolean SubmittedMessageDisplayed = receivingShipmentScanPage.isSubmittedMessageDisplayed();
		assertion.assertTrue(SubmittedMessageDisplayed);
		receivingShipmentScanPage.clickOnOKButtonOnCartonSubmittedSuccessfully();

		globalSearchPage.searchCartonNumberInGlobalSearch("0010411114252S", assertion);
		logger.info("Carton is received");
		globalSearchPage.validateTheGoBackResult("0010411114252S");

	}

	public void SRA1252_validateTheGoBackButton_InGlobalSearchForSku()
			throws InterruptedException, IOException, ParseException {

		SoftAssert assertion = new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		GlobalSearchPage globalSearchPage = new GlobalSearchPage();

		Document doc = createDocFromFile("StoreSRA706.json");

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = format.parse(EtaDate);
		doc.put("ETADateTime", ExpectedArrival);

		updateDocToStoreTransferDb(doc);

		// login as received store
		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		homescreen.clickOnReceiving();

		receivingPage.clickOnStoreToStoreTransfer();

		sendnReceivetransfer.clickOnSendStoreTransfer();

		globalSearchPage.validateGoBackSearchInGlobalSearch(getProperty("sku5739995"), assertion);

	}

}
