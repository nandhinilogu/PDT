package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate tick and Dot Image is visible to  cartons in Global Search")
@Description("Validate tick and Dot Image is visible to  cartons in Global Search")

public class SRA1602_ValidateTickAndDotImageForCartonInGlobalSearch extends BaseTest {
	
	final static Logger logger = Logger.getLogger("SRA1602_ValidateTickAndDotImageForCartonInGlobalSearch");
	
public void SRA1602_validateTickAndDotImageForCartonInGlobalSearch() throws IOException, ParseException, FindFailed{
		

		HomePage homescreen = new HomePage();
		LoginPage login = new LoginPage();
		ReceivingShipmentPage receivingShipment = new ReceivingShipmentPage();
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

			Document doc = createDocFromFile("SRA22.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("EtaDateTime", ExpectedArrival);
			updateDocToDb(doc);
			
			String cartonNumber = ((List<Document>) doc.get("Cartons")).get(0).getString("CartonNumber");
			logger.info("carton number is " + cartonNumber);

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			globalSearch.enterCartonNumberInGlobalSearch(cartonNumber.substring(0, 13));
			
			Screen s= new Screen();
			Pattern pattern = new Pattern("dot_image.PNG"); 
			
			boolean found=false;
			if (s.exists(pattern) != null){
				found=true;
				logger.info("Dot image found");
			}
			
			Assert.assertTrue(found);
			
			homescreen.clickOnMenuBar();
			homescreen.clickOnDCShipmentsOnSideMenuBar();
			
			receivingShipment.clickOnScanButton();
			receivingShipmentScanPage.initiateShipment(cartonNumber);
			receivingShipmentScanPage.clickOnShipmentSummery();
			receivingShipmentScanPage.clickOnSubmitShipmentSummery();
			receivingShipmentScanPage.clickOnOKButtonOnCartonSubmittedSuccessfully();
			receivingShipmentScanPage.clickOnContinueScanning();
			
			globalSearch.enterCartonNumberInGlobalSearch(cartonNumber.substring(0, 13));
			
			Pattern tickimagepattern = new Pattern("tick_image.PNG"); 
			
			boolean foundtick=false;
			if (s.exists(tickimagepattern) != null){
				foundtick=true;
				logger.info("Tick image found");
			}
			
			Assert.assertTrue(foundtick);
			
	}


}
