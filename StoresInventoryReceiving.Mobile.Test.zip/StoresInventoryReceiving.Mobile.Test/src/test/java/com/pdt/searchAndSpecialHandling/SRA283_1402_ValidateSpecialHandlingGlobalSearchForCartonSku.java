package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "View sku details of a Carton Sku, edit and save special handling of a carton sku")
@Description("View sku details of a Carton Sku, edit and save special handling of a carton sku")

public class SRA283_1402_ValidateSpecialHandlingGlobalSearchForCartonSku extends BaseTest {
	final static Logger logger = Logger
			.getLogger(SRA283_1402_ValidateSpecialHandlingGlobalSearchForCartonSku.class.getName());

	public void SRA1402_MarkSpecialHandlingForCartonSKUInSearch() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homePage= new HomePage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();
				
		Document firstCarton = createDocFromFile("SRA283.json");
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(firstCarton);

		logger.info("Added  a record in DC Shipment");
		
		String cartonNumber = ((List<Document>) firstCarton.get("Cartons")).get(0).getString("CartonNumber");
		logger.info("carton number is " + cartonNumber);

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateSKUDetailsForCartonSku(getProperty("sku1023998"), cartonNumber,getProperty("valid_storeno104"));
		
		globalSearch.markSpecialHandlingInCartonSku(cartonNumber, getProperty("valid_storeno104"));
		
		homePage.clickOnMenuBar();
		homePage.clickOnDCShipmentsOnSideMenuBar();
		globalSearch.validateSpecialHandlingInDcShipment(cartonNumber.substring(0, 14));
		
		
	}

	public void SRA1402_ValidateCartonSkuNotVisibleForETAMoreThan32Days() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		
			Document firstCarton = createDocFromFile("SRA283_1.json");

			SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 32);
			Date ExpectedArrival = formatDate.parse(EtaDate);
			firstCarton.put("EtaDateTime", ExpectedArrival);

			updateDocToDb(firstCarton);

			logger.info("Added  a record in DC Shipment");

			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			globalSearch.validateCartonETAMoreThan31Days(getProperty("sku1111980"));
			logger.info("No sku found error message displayed");

	}

	public void SRA1402_MarkSpecialHandlingForCartonSKUInSearchETAPast365Days() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		
		

		Document firstCarton = createDocFromFile("SRA283_1.json");

		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");

		String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 367);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);

		updateDocToDb(firstCarton);

		logger.info("Added  a record in DC Shipment");

		login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));
		globalSearch.validateCartonETAMoreThan31Days(getProperty("sku1111980"));
		logger.info("No sku found error message displayed");
		
	}
}
