package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.LoginPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating the Sku for each DCShipment, StoreTransfer and PO")
@Description("Validating the Sku for each DCShipment, StoreTransfer and PO")

public class SRA578_1299_ValidateThreeResultsInGlobalSearch extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA578_1299_ValidateThreeResultsInGlobalSearch.class.getName());

	public void SRA1299_validateTheThreeResultsInGlobalSearch() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		// Added record for Carton
		Document firstCarton = createDocFromFile("SRA578_2.json");
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateIncementDay("yyyy-MM-dd", 1);
		Date ExpectedArrival = formatDate.parse(EtaDate);
		firstCarton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(firstCarton);
		logger.info("Added  first record in DC Shipment");

		Document secondCarton = createDocFromFile("SRA578.json");
		String EtaDateSecondCarton = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrivalSecondCarton = formatDate.parse(EtaDateSecondCarton);
		secondCarton.put("EtaDateTime", ExpectedArrivalSecondCarton);
		updateDocToDb(secondCarton);
		logger.info("Added second record in DC Shipment");

		Document thirdCarton = createDocFromFile("SRA578_3.json");
		String EtaDateThirdCarton = getDateIncementDay("yyyy-MM-dd", 30);
		Date ExpectedArrivalThirdCarton = formatDate.parse(EtaDateThirdCarton);
		thirdCarton.put("EtaDateTime", ExpectedArrivalThirdCarton);
		updateDocToDb(thirdCarton);
		logger.info("Added third record in DC Shipment");

		// Added record for storetransfer
		Document firstStoreTransfer = createDocFromFile("StoreSRA578.json");
		String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd", 23);
		Date ExpectedArrivalForStoreTransfer = formatDate.parse(EtaDateForStoreTransfer);
		firstStoreTransfer.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(firstStoreTransfer);
		logger.info("Added first record for sendStoreTransfer");

		Document secondStoreTransfer = createDocFromFile("StoresSRA578_2.json");
		String EtaDateForSecondStoreTransfer = getDateIncementDay("yyyy-MM-dd", 29);
		Date ExpectedArrivalForSecondStoreTransfer = formatDate.parse(EtaDateForSecondStoreTransfer);
		secondStoreTransfer.put("ETADateTime", ExpectedArrivalForSecondStoreTransfer);
		updateDocToStoreTransferDb(secondStoreTransfer);
		logger.info("Added second record for sendStoreTransfer");

		Document thirdStoreTransfer = createDocFromFile("StoresSRA578_3.json");
		String EtaDateForThirdStoreTransfer = getDateIncementDay("yyyy-MM-dd", 15);
		Date ExpectedArrivalForThirdStoreTransfer = formatDate.parse(EtaDateForThirdStoreTransfer);
		thirdStoreTransfer.put("ETADateTime", ExpectedArrivalForThirdStoreTransfer);
		updateDocToStoreTransferDb(thirdStoreTransfer);
		logger.info("Added third record for sendStoreTransfer");

		// Added record for PO
		Document PO = createDocFromFile("PO578.json");
		String EtaDateForPO = getDateIncementDay("yyyy-MM-dd", 30);
		Date ExpectedArrivalForPO = formatDate.parse(EtaDateForPO);
		PO.put("ETADateTime", ExpectedArrivalForPO);
		updateDocInPOCollection(PO);
		logger.info("Added first record for PO");

		Document POSecond = createDocFromFile("PO578_2.json");
		String EtaDateForSecondPO = getDateIncementDay("yyyy-MM-dd", 30);
		Date ExpectedArrivalForSecondPO = formatDate.parse(EtaDateForSecondPO);
		POSecond.put("ETADateTime", ExpectedArrivalForSecondPO);
		updateDocInPOCollection(POSecond);
		logger.info("Added Second record for PO");

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		globalSearch.validateThreeSKUDisplayedInGlobalSearch(getProperty("sku1111722"));

	}

	public void SRa1299_validateTheThreeResultsInGlobalSearchChangeOfETA() throws IOException, ParseException, InterruptedException {

		LoginPage login = new LoginPage();

		GlobalSearchPage globalSearch = new GlobalSearchPage();

		// Added record for Carton

		Document carton = createDocFromFile("SRA578.json");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 200);
		Date ExpectedArrival = format.parse(EtaDate);
		carton.put("EtaDateTime", ExpectedArrival);
		updateDocToDb(carton);
		logger.info("Added record in DC Shipment");

		// Added record for storetransfer
		Document storeTransfer = createDocFromFile("StoreSRA578.json");
		String EtaDateForStoreTransfer = getDateIncementDay("yyyy-MM-dd", 34);
		Date ExpectedArrivalForStoreTransfer = format.parse(EtaDateForStoreTransfer);
		storeTransfer.put("ETADateTime", ExpectedArrivalForStoreTransfer);
		updateDocToStoreTransferDb(storeTransfer);
		logger.info("Added record for sendStoreTransfer");

		// Add record for PO
		Document PO = createDocFromFile("PO578.json");
		String EtaDateForPO = getDateIncementDay("yyyy-MM-dd", 30);
		Date ExpectedArrivalForPO = format.parse(EtaDateForPO);
		PO.put("ETADateTime", ExpectedArrivalForPO);
		updateDocInPOCollection(PO);
		logger.info("Added record for PO");

		login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
				getProperty("valid_password9792"));

		globalSearch.validateThreeSKUDisplayedInGlobalSearch(getProperty("sku1111722"));
	}

}
