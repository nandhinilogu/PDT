package com.pdt.searchAndSpecialHandling;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Validating the special Handling in Global search for a PO")
@Description("Validating the special Handling in Global search for a PO")
public class SRA313_1302_ValidateEditSpecialHandlingOfSkuInPO extends BaseTest {

	final static Logger logger = Logger.getLogger(SRA313_1302_ValidateEditSpecialHandlingOfSkuInPO.class.getName());

	public void SRA1302_ValidateSpecialHandlingForPO() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SoftAssert assertion = new SoftAssert();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		
			Document doc = createDocFromFile("PO313.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 28);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocInPOCollection(doc);

			login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			globalSearch.receivingPOwithSpecialHandling(getProperty("poNumber11116700"), assertion,getProperty("valid_storeno2"));
			logger.info("Succeessfully saved the Special Handling for a PO");

			homeScreen.clickOnMenuBar();
			homeScreen.clickOnPurchaseOrdersOnSideMenuBar();

			purchaseOrder.validateSpecialHandlingInReceivingPO(getProperty("poNumber11116700"),"Backorder", assertion);
			
			assertion.assertAll();
	}

	public void SRA1302_validateSpecialHandlingForPOWhenCancelled() throws IOException, ParseException {

		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		PurchaseOrderPage purchaseOrder = new PurchaseOrderPage();
		SoftAssert assertion = new SoftAssert();
		GlobalSearchPage globalSearch = new GlobalSearchPage();

		
			Document doc = createDocFromFile("PO313.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);

			updateDocInPOCollection(doc);

			login.loginInMRA(this.getProperty("valid_storeno2"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			globalSearch.receivingPOwithSpecialHandlingWhenCancelled(getProperty("poNumber11116700"));
			homeScreen.clickOnMenuBar();
			homeScreen.logout();
			login.loginWithRegisteredStore(getProperty("valid_username9792"), getProperty("valid_password9792"));
			homeScreen.clickOnMenuBar();
			homeScreen.clickOnPurchaseOrdersOnSideMenuBar();

			purchaseOrder.validateSpecialHandlingNotVisible(getProperty("poNumber11116700"),"None",assertion);
		

	}

	
	

}
