package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validate the Send store transfer created in last 30 days ")
@Description("Validate the Send store transfer created in last 30 days")

//By Harmeet
public class SRA769_1209_ValidateTransferSummeryOfLast30Days extends BaseTest {

	public void SRA1209_ValidateTheSendTransferSummery() throws ParseException, IOException {
		SoftAssert softassert =new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();

		

			Document doc = createDocFromFile("StoreSRA769.json");
			//Transfer No 212343
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 10);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);
			
			//Transfer Number 200450
			Document doc578 = createDocFromFile("StoreSRA578.json");
			SimpleDateFormat format578 = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate578 = getDateIncementDay("yyyy-MM-dd", 2);
			Date ExpectedArrival578 = format578.parse(EtaDate578);
			doc.put("ETADateTime", ExpectedArrival578);
			updateDocToStoreTransferDb(doc578);

			// SendStoreTransferPage sendStoreTransferPage=new SendStoreTransferPage();

			login.loginInMRA(this.getProperty("valid_storeno104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homeScreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			validateFromMongoDB.validate30DaysTransferSummery(getProperty("valid_storeno104"),softassert);
			softassert.assertAll();
		
	}
}
