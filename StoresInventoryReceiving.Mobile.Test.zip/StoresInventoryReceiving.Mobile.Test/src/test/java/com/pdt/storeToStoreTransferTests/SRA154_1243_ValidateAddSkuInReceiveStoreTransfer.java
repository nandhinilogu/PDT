package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Adding Sku to Transfer which is not present in Transfer#")
@Description("Adding Sku to Transfer which is not present in Transfer#")

// By Ruthra
public class SRA154_1243_ValidateAddSkuInReceiveStoreTransfer extends BaseTest {
	final static Logger logger = Logger.getLogger(SRA154_1243_ValidateAddSkuInReceiveStoreTransfer.class.getName());

	String transferNumber = null;
	String storeNumber = null;

	
	public void SRA1243_ValidateAddSkuforReceiveTransfer() throws Exception {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();

	

			Document doc = createDocFromFile("TransferwithSku5739995.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 7);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);

			transferNumber = doc.getString("TransferNumber");
			storeNumber = doc.getString("DestinationStoreNumber");

			logger.info("Transfer Number is  ------------ " + transferNumber);
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();

			logger.info("Adding Valid Sku in receive transfer");
			receiveStoreTransfer.validatationInReceiveStoreTransferforValidSkuNumber(transferNumber, "1023998",storeNumber);
			
			logger.info("Adding Invalid Sku in receive transfer");
			receiveStoreTransfer.validatationInReceiveStoreTransferforInvalidSkuNumber("2222");
			
			logger.info("Adding Duplicate Sku in receive transfer");
			receiveStoreTransfer.validatationInReceiveStoreTransferforDuplicateSkuNumber("5739995");
		
	}

}