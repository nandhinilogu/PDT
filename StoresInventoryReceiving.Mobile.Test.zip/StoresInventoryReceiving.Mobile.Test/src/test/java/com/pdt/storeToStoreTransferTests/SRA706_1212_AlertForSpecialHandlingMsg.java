package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "To Validate the special handling message while receiving a transfer")
@Description("To Validate the special handling message while receiving a transfer")

public class SRA706_1212_AlertForSpecialHandlingMsg extends BaseTest {

	public void SRA1212_validateSpecialHandlingMsgInReceiving() throws InterruptedException, IOException, ParseException {
		
		LoginPage login = new LoginPage();
		HomePage homeScreen = new HomePage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receivingTransferPage = new ReceivingTransferPage();
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		

			Document doc = createDocFromFile("StoreSRA706.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 1);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);

			// login as receiving storeNo: 2

			login.loginInMRA(getProperty("valid_storeno2"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));

			// setting the special Handling in Global search

			globalSearch.setSkuInSpecialHandling(getProperty("transferNumber200452"),getProperty("valid_storeno2"));

			homeScreen.clickOnMenuBar();

			homeScreen.clickOnStoreTransferOnSideMenuBar();

			sendnReceivetransfer.clickOnReceiveStoreTransfer();

			receivingTransferPage.validateSpecialHandlingMsgOnSKu(getProperty("transferNumber200452"));
		

	}
}
