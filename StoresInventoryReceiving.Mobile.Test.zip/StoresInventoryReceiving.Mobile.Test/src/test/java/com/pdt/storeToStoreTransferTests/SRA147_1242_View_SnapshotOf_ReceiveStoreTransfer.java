package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "View Sanpshot of all expected Store Transfer in Receiving")
@Description("View Sanpshot of all expected Store Transfer in Receiving")
public class SRA147_1242_View_SnapshotOf_ReceiveStoreTransfer extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA147_1242");
	
	public void SRA1242_View_SnapshotOf_Expected_StoreTransfer()  {
		SoftAssert softassert =new SoftAssert();
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();

		try {
			
			Document doc = createDocFromFile("TransferwithSku5739995.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 30);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after increment is" + doc.get("ETADateTime"));
			
			updateDocToStoreTransferDb(doc);
			
			String storeNumber = doc.getString("DestinationStoreNumber");
			String transferNumber = doc.getString("TransferNumber");
			logger.info("Transfer  Number is " + transferNumber);
			
			Document doc578 = createDocFromFile("SRA147_StoreTransfer.json");
            SimpleDateFormat format578 = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate578 = getDateDecreaseDay("yyyy-MM-dd", 30);
			Date ExpectedArrival578 = format578.parse(EtaDate578);
			doc578.put("ETADateTime", ExpectedArrival578);
			logger.info("date after decrement is" + doc578.get("ETADateTime"));
			logger.info("Transfer  Number is " + doc578.getString("TransferNumber"));
			
			updateDocToStoreTransferDb(doc578);
			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			validateFromMongoDB.validateExpectedTransfer(storeNumber,softassert);
			softassert.assertAll();
		} 
         catch (IOException | ParseException e) {
			
			e.printStackTrace();
		}
		
	}

	
	public void SRA1242_ValidateTransferETALessThan30Days()  {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		try {

			Document doc = createDocFromFile("SRA147_StoreTransfer.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateDecreaseDay("yyyy-MM-dd", 31);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after decrement is" + doc.get("ETADateTime"));
			updateDocToStoreTransferDb(doc);
			
			String storeNumber = doc.getString("DestinationStoreNumber");
			String transferNumber = doc.getString("TransferNumber");
			logger.info("Transfer  Number is " + transferNumber);
			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			receiveStoreTransfer.validateDateForTransferNumber(transferNumber);
			validateFromMongoDB.validateOldTransferForETALessThan30(storeNumber);
		}
       catch (IOException | ParseException e) {
			
			e.printStackTrace();
		}

		
	}

	
	public void SRA1242_ValidateTransferETAGreaterThan30Days()  {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();

		try {

			Document doc = createDocFromFile("SRA147_StoreTransfer.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 31);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after increment is " + doc.get("ETADateTime"));
			updateDocToStoreTransferDb(doc);
			
			String storeNumber = doc.getString("DestinationStoreNumber");
			String transferNumber = doc.getString("TransferNumber");
			logger.info("Transfer  Number is " + transferNumber);

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			receiveStoreTransfer.validateDateForTransferNumber(transferNumber);
			validateFromMongoDB.validateFutureTransferForETAGreaterThan30(storeNumber);
		} 
		catch (ParseException | IOException e) {
			
			e.printStackTrace();
		}

		

	}

	
	@SuppressWarnings("unchecked")
	public void SRA1242_ValidationForPendingQtyZeroNotDisplayed()  {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();

		try {
			
			Document doc = createDocFromFile("SRA147_StoreTransfer.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			logger.info("date after increment is" + doc.get("ETADateTime"));
			((List<Document>) doc.get("SKUs")).get(0).put("ReceivedQuantity", 5);
			updateDocToStoreTransferDb(doc);
			
			String storeNumber = doc.getString("DestinationStoreNumber");
			String transferNumber = doc.getString("TransferNumber");
			logger.info("Transfer  Number is " + transferNumber);
			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			receiveStoreTransfer.validateDateForTransferNumber(transferNumber);
			validateFromMongoDB.validateForPendingQtyZeroInReceiveTransfer(storeNumber);
		} 
		
		catch (ParseException | IOException e) {
			
			e.printStackTrace();
		} 
	}

}
