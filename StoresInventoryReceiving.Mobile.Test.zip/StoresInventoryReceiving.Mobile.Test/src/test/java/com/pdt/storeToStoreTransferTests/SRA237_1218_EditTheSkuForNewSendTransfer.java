package com.pdt.storeToStoreTransferTests;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating SKU Qty edit for newly created transfer orders")
@Description("Validating SKU Qty edit for newly created transfer orders")

//By Oviya
public class SRA237_1218_EditTheSkuForNewSendTransfer extends BaseTest {

	public void SRA_1218_ValidateSkuQtyEdit_NewTransferOrder() throws Exception {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		String transferNumberCreated = null;
		try {

			login.loginInMRA(getProperty("valid_storeno3"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			// To Validate if associate is able to edit and save the sku qty
			sendStoreTransfer.editSkuQtyForNewTransfer(getProperty("valid_storeno104"), "3");
			
			// To validate if associate is able to edit the received SKU qty upto 99
			sendStoreTransfer.validateAbleToEditReceivedQtyUpTo99("99");
			
			// To validate if associate is able to edit the  SKU qty to 0
			sendStoreTransfer.validateErrorMessageForReceivedQty0("0");
			
			
			// Validate associates is not able to edit the received SKU Qty above 99
			sendStoreTransfer.validateNotAbletoEditReceivedQtyAbove99("110");
			
			transferNumberCreated = sendStoreTransfer.cancelEditSkuQtyForNewTransfer("4");
		} finally {
			deleteStoreTransfer(transferNumberCreated);
			

		}
	}

}
