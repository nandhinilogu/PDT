package com.pdt.storeToStoreTransferTests;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating search for a Transfer order with Transfer Number")
@Description("Validating search for a Transfer order with Transfer Number")

//By Oviya

public class SRA148_1219_SearchForStoreTransferWithTransferNumber extends BaseTest {

	public void SRA_1219_SearchForCreatedTransferorderInDestinationStore()  {
		String transferNumberCreated = null;

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		SoftAssert softassert=new SoftAssert();
		try {
			login.loginInMRA(this.getProperty("valid_storeno3"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			// created a new transfer order
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();

			// Method to create Transfer
			transferNumberCreated = sendStoreTransfer.createTransferforSingleSku(getProperty("destinationStore104"),
					getProperty("sku5739995"));
			System.out.println(transferNumberCreated);
			homescreen.clickOnMenuBar();
			homescreen.logout();

			// Searching for that transfer in Receive Transfer Home page
			login.loginInMRA(this.getProperty("destinationStore104"), this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnReceiveStoreTransfer();
			boolean isTransferDisplayed = receiveStoreTransfer.searchForReceiveTransfer(transferNumberCreated);
			Assert.assertTrue(isTransferDisplayed);
			
			receiveStoreTransfer.validateLabelsInReceiveStoreTransfersHomePage(softassert);

			// Cross checking in DB and asserting Transfer Number ETA And source store number and SKU QTY  displayed in Transfer Home page
			validateFromMongoDB.validateCreatedInTransitTransferNumberInDB(transferNumberCreated,softassert,this.getProperty("destinationStore104"));

		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			deleteStoreTransfer(transferNumberCreated);
			
		}
	}
}
