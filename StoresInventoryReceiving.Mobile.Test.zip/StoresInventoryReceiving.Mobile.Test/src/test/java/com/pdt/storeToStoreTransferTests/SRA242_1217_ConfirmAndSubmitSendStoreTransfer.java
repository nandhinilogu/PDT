package com.pdt.storeToStoreTransferTests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating transfer order created and submitted successfully")
@Description("Validating transfer order created and submitted successfully")

//Created By Oviya
//Reviewed By Harmeet
public class SRA242_1217_ConfirmAndSubmitSendStoreTransfer extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA242_1217");
	SoftAssert softassert =new SoftAssert();
	
	public void SRA_1217_validateConfirmAndSubmitNewTransferOrder() throws Exception {
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		String transferNumberCreated = null;

		
			login.loginInMRA(getProperty("valid_storeno3"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			logger.info("To validate creating a new transfer order and submitting the transfer order");
		   String SkuDescription=sendStoreTransfer.createTransfer(getProperty("destinationStore104"), getProperty("sku5739995"), softassert);
			
		   String transferCreatedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
			logger.info("Current CreatedTime is "+transferCreatedTime);
			
			String SubmittedMessage = sendStoreTransfer.SubmittedMessage();
			softassert.assertEquals(SubmittedMessage, "Transfer Order Submitted Successfully");
			logger.info("Displayed Message after submitting is ---> " +SubmittedMessage);
			
			logger.info("To validate if continue scanning and Submit button are not displayed after submitting transfers");
			sendStoreTransfer.validateButtonsInTransferSummaryPage(softassert);
			
		     transferNumberCreated = sendStoreTransfer.getTransferNumberOnTransferSummaryPage().substring(10);
		     logger.info("Created Transfer Number is "+transferNumberCreated);
		     sendStoreTransfer.clickOnTransferHome();
			logger.info("To validate if the created Transfer order is displayed in the SendtransfersHomePage");
			sendStoreTransfer.searchForTransferNumber(transferNumberCreated);
			
			logger.info("To validate if the created Transfer order is updated in the DB");
			validateFromMongoDB.validateCreatedTransferNumberInDB(transferNumberCreated,softassert, getProperty("sku5739995"), SkuDescription,transferCreatedTime, getProperty("valid_username9792"),getProperty("destinationStore104"));
			softassert.assertAll();
			
			deleteStoreTransfer(transferNumberCreated);
		

	}
}

	

