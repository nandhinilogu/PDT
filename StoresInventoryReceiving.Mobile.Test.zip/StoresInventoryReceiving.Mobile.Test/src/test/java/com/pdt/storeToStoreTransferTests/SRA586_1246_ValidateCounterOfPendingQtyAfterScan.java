package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Counter of Pending QTY decrements and received QTY increments as you scan SKU labels")
@Description("Counter of Pending QTY decrements and received QTY increments as you scan SKU labels")

public class SRA586_1246_ValidateCounterOfPendingQtyAfterScan extends BaseTest{
	final static Logger logger = Logger.getLogger(SRA586_1246_ValidateCounterOfPendingQtyAfterScan.class.getName());
	 
	 
	public void SRA1246_ValidateCountOfPendingQtyDecrementAfterScan() throws InterruptedException, IOException, ParseException{
		
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
	
			
			Document doc = createDocFromFile("SRA582Transfer.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 7);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);

			String transferNumberCreated = doc.getString("TransferNumber");
			String storeNumber = doc.getString("DestinationStoreNumber");
			logger.info("Transfer Number is -------"+transferNumberCreated);
			
			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
		    homescreen.clickOnReceiving();
	        receivingPage.clickOnStoreToStoreTransfer();
	        sendnReceivetransfer.clickOnReceiveStoreTransfer();
	        receiveStoreTransfer.validateCountOfPendingQuantityAfterScanning(transferNumberCreated, "1",storeNumber);
		
		
	}
	 
	 
	

}
