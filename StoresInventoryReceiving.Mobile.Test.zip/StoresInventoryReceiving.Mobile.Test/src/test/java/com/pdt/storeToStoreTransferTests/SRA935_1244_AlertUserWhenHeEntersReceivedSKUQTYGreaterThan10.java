package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating Alert message when received sku qty is greater than 10")
@Description("Validating Alert message when received sku qty is greater than 10")
//By Oviya
public class SRA935_1244_AlertUserWhenHeEntersReceivedSKUQTYGreaterThan10 extends BaseTest {

	public void SRA_1244_validateAlertMessageForSkuQtyGreaterThan10() throws Exception {

		String transferNumber = null;
		String storeNumber = null;
		Date updatedETA = null;
		
		
		LoginPage login = new LoginPage();

		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			Document doc = createDocFromFile("ReceiveTransferswithSingleSku.json");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			String EtaDate = getDateIncementDay("yyyy-MM-dd", 6);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			updateDocToStoreTransferDb(doc);
			
			

			transferNumber = doc.getString("TransferNumber");
			storeNumber = doc.getString("DestinationStoreNumber");
			updatedETA = doc.getDate("ETADateTime");
			System.out.println("Transfer Number is "+transferNumber);
			System.out.println("Updated ETADateTime is "+updatedETA);
			
			
			// Navigate to receive Transfers screen and search for the Inserted transfer

			login.loginInMRA(storeNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendnReceivetransfer.clickOnReceiveStoreTransfer();
			Thread.sleep(2000);
			
			// To validate alert message when associate receives qty more than 10
			receiveStoreTransfer.validateAlertMessageWhenReceivingSkuQtyGreaterThan10(transferNumber, "11");

			// To validate if click on No button does not save the edited sku qty
			receiveStoreTransfer.validateSkuQtyNotChangedWhenClickingOnNoButtonInAlertMessage("12");

			// To validate No alert message when associate receives qty less than 10
			receiveStoreTransfer.validateNoAlertMessageWhenReceivingSkuQtyLesserThan10("9");


	}
}
