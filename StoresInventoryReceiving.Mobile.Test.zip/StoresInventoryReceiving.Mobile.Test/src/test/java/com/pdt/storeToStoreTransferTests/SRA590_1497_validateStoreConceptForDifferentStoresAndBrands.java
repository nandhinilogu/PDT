package com.pdt.storeToStoreTransferTests;

import static com.util.BaseUtil.getDateIncementDay;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

import ru.yandex.qatools.allure.annotations.Description;

@Listeners(BaseListener.class)
@Test(description = "Validating store concepts for different stores and brands")
@Description("Validating store concepts for different stores and brands")

//By Oviya
public class SRA590_1497_validateStoreConceptForDifferentStoresAndBrands extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA590_1497");
	

	public void SRA_1497_validateStoreConceptForSameBrandStores() throws Exception {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			Document doc = createDocFromFile("TransferwithSku5739995.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			doc.put("CreatedDateTime", ExpectedArrival);
			logger.info("date after increment is" +ExpectedArrival );
			String TranferNumber= doc.getString("TransferNumber");
			String sourceStoreNumber = doc.getString("SourceStoreNumber");
			String destinationStoreNumber = doc.getString("DestinationStoreNumber");
			updateDocToStoreTransferDb(doc);


			login.loginInMRA(sourceStoreNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			logger.info("To Validate WS store concept in Send Store Transfers screen" );
			sendStoreTransfer.validateStoreConceptForSameBrandInSendStoreTransfersScreen(TranferNumber,"WS");
			homescreen.clickOnMenuBar();
			homescreen.logout();
			
			login.loginInMRA(destinationStoreNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnReceiveStoreTransfer();
			logger.info("To Validate WS store concept in Receive Store Transfers screen" );
			receiveStoreTransfer.validateStoreConceptForSameBrandInReceiveStoreTransfersScreen(TranferNumber,"WS");
			
		}
	public void SRA_1497_validateStoreConceptForDifferentBrandStores() throws Exception {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			Document doc = createDocFromFile("ReceiveTransferswithSingleSku.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			doc.put("CreatedDateTime", ExpectedArrival);
			logger.info("date after increment is" +ExpectedArrival );
			String TranferNumber= doc.getString("TransferNumber");
			String sourceStoreNumber = doc.getString("SourceStoreNumber");
			String destinationStoreNumber = doc.getString("DestinationStoreNumber");
			updateDocToStoreTransferDb(doc);


			login.loginInMRA(sourceStoreNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			logger.info("To Validate PK store concept in Send Store Transfers screen" );
			sendStoreTransfer.validateStoreConceptForCrossBrandInSendStoreTransfersScreen(TranferNumber,"PK");
			homescreen.clickOnMenuBar();
			homescreen.logout();
			
			login.loginInMRA(destinationStoreNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnReceiveStoreTransfer();
			logger.info("To Validate WS store concept in Receive Store Transfers screen" );
			receiveStoreTransfer.validateStoreConceptForCrossBrandInReceiveStoreTransfersScreen(TranferNumber,"PB");
			

		}
	public void SRA_1497_validateStoreConceptForCrossBrandStores() throws Exception {
		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendAndReceiveTransferPage = new SendAndReceiveTransferPage();
		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		
			Document doc = createDocFromFile("ReceiveTransferswithMultipleSku.json");

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String EtaDate = getDateIncementDay("yyyy-MM-dd", 29);
			Date ExpectedArrival = format.parse(EtaDate);
			doc.put("ETADateTime", ExpectedArrival);
			doc.put("CreatedDateTime", ExpectedArrival);
			logger.info("date after increment is" +ExpectedArrival );
			String TranferNumber= doc.getString("TransferNumber");
			String sourceStoreNumber = doc.getString("SourceStoreNumber");
			String destinationStoreNumber = doc.getString("DestinationStoreNumber");
			updateDocToStoreTransferDb(doc);


			login.loginInMRA(sourceStoreNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnSendStoreTransfer();
			logger.info("To Validate WE store concept in Send Store Transfers screen" );
			sendStoreTransfer.validateStoreConceptForCrossBrandInSendStoreTransfersScreen(TranferNumber,"WE");
			homescreen.clickOnMenuBar();
			homescreen.logout();
			
			login.loginInMRA(destinationStoreNumber, this.getProperty("valid_username9792"),
					this.getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			sendAndReceiveTransferPage.clickOnReceiveStoreTransfer();
			logger.info("To Validate WH store concept in Receive Store Transfers screen" );
			receiveStoreTransfer.validateStoreConceptForCrossBrandInReceiveStoreTransfersScreen(TranferNumber,"PB");
			

		}
	}


