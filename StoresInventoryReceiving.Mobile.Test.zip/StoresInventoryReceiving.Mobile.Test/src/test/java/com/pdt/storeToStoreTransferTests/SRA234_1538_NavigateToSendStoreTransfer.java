package com.pdt.storeToStoreTransferTests;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pdt.Pom.HomePage;
import com.pdt.Pom.LoginPage;
import com.pdt.Pom.ReceivingPage;
import com.pdt.Pom.SendAndReceiveTransferPage;
import com.web.template.BaseListener;
import com.web.template.BaseTest;

@Listeners(BaseListener.class)
@Test(description = "Navigate to Transfers Screen and validate the headers displayed")
@Description("Navigate to Transfers Screen and validate the headers displayed")

public class SRA234_1538_NavigateToSendStoreTransfer extends BaseTest {
	final static Logger logger = Logger.getLogger("SRA234_1538");
	SoftAssert softassert =new SoftAssert();
	
	public void SRA1538_NavigateToSendStoreTransfer()  {

		LoginPage login = new LoginPage();
		HomePage homescreen = new HomePage();
		ReceivingPage receivingPage = new ReceivingPage();
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		
			login.loginInMRA(getProperty("valid_storeno104"), getProperty("valid_username9792"),
					getProperty("valid_password9792"));
			homescreen.clickOnReceiving();
			receivingPage.clickOnStoreToStoreTransfer();
			String StoreTransfersHeading=sendnReceivetransfer.captureStoreTransfersHeader();
			softassert.assertEquals(StoreTransfersHeading, "STORE TRANSFER");
			logger.info(StoreTransfersHeading +" Heading is Displayed");
			
			logger.info("To validate Send Store Transfers button and to validate the home page header");
			sendnReceivetransfer.navigateToSendTransfersPage(softassert);
			
			logger.info("To validate Receive Store Transfers button and to validate the home page header");
			sendnReceivetransfer.navigateToReceiveTransfersPage(softassert);
			softassert.assertAll();
		
	}

}
