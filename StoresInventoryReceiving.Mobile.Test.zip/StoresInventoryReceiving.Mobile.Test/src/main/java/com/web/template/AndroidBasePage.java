package com.web.template;

import static com.util.AndroidDriverConfig.getAndroidDriver;
import static com.util.AndroidDriverConfig.getProperty;

import java.io.File;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.mobile.NetworkConnection;
import org.openqa.selenium.mobile.NetworkConnection.ConnectionType;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.util.AndroidDriverConfig;

import io.appium.java_client.AppiumFluentWait;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class AndroidBasePage {

	protected AndroidDriver<MobileElement> driver = null;
	private static final Logger logger = Logger.getLogger(AndroidBasePage.class.getName());
	

	public AndroidBasePage() {
		driver = getAndroidDriver();
	}

	@Step("Click on the Elemet")
	protected void elementClick(By element) {
		driver.findElement(element).click();
		logger.info("Element in the field ["+element.toString() +" ] is clicked");

	}

	@Step("Click on the Elemet with index")
	protected void multipleElementClick(By element, int index) {
		driver.findElements(element).get(index).click();
	}

	@Step("Get Elements in List")
	public List<MobileElement> getListText(final By locator) {
		List<MobileElement> list = driver.findElements(locator);
		return list;
	}

	@Step("Wait until the element is displayed")
	public void fluentWait(final By locator, int timeOutSeconds, int pollingSeconds) {

		FluentWait<AndroidDriver<MobileElement>> wait = new AppiumFluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(timeOutSeconds)).pollingEvery(Duration.ofSeconds(pollingSeconds))
				.ignoring(NoSuchElementException.class).ignoring(ElementNotVisibleException.class)
				.ignoring(TimeoutException.class);

		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	@Step("Wait until the element is Enabled")
	public void fluentWaitForElementToBeEnabled(final By locator, int timeOutSeconds, int pollingSeconds) {

		FluentWait<AndroidDriver<MobileElement>> wait = new AppiumFluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(timeOutSeconds)).pollingEvery(Duration.ofSeconds(pollingSeconds))
				.ignoring(NoSuchElementException.class).ignoring(ElementNotVisibleException.class)
				.ignoring(TimeoutException.class);

		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	@Step("Wait until the element is displayed")
	public void fluentWait(final By locator) {
		fluentWait(locator, Integer.parseInt(getProperty("wait_timeout")),
				Integer.parseInt(getProperty("polling_time")));
	}

	@Step("Wait for 10 seconds")
	public void globalWait() {
		logger.info("Wait for 10 second");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
	}

	public boolean isEnabled(final By locator) {
		return driver.findElement(locator).isEnabled();
	}

	@Step("Send text[{1}] to field: [{0}]")
	protected void setText(final By locator, final String text) {
		driver.findElement(locator).sendKeys(text);
	   logger.info("Value [" + text + "] is entered in field [ "+locator.toString()+" ]");
	}

	@Step("Grab value of an element")
	public String getText(final By locator) {
		String value = driver.findElement(locator).getText();
		// String value =
		// driver.findElement(locator).getAttribute("textContent");
		logger.info("Actual Value in UI is [" + value + "]");
		return value;
	}

	@Step("validates given element is visible in web page")
	public boolean isDisplayed(final By locator) {
		 boolean value=driver.findElement(locator).isDisplayed();
		 logger.info(driver.findElement(locator).getText() + " is displayed");
		 return value;
	}

	@Step("Refresh Page")
	public void refreshData() {
		driver.getPageSource();
	}

	@Step("validates given element is visible in web page")
	public boolean isDisplayedWithoutWait(final By locator) {
		boolean found = false;
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		try {
			if (driver.findElement(locator) != null)
				found = true;
		} catch (Exception e) {
			found = false;
		} finally {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}

		return found;
	}

	@Step("Clear text from the given field")
	public void clearTextField(By locator) {
		MobileElement element = driver.findElement(locator);
		element.click();
		element.clear();
	}

	@Step("Clear text from the given text box")
	public void clearTextBox(By locator) {
		MobileElement element = driver.findElement(locator);
		element.clear();
	}

	@Step("Press Enter from Keyboard")
	public void pressEnter() {

		driver.pressKeyCode(AndroidKeyCode.ENTER);
	}

	@Step("Press Backbutton from android keyboard")
	public void pressBackButton() {

		driver.pressKey(new KeyEvent(AndroidKey.BACK));
	}

	@Step("ON/OFF wifi")
	public void toggleWifi() {
		driver.toggleWifi();

	}

	@Step("Get Wifi Status")
	public boolean wifiStatus() {
		return driver.getConnection().isWiFiEnabled();

	}

	@Step("Enable Airplane mode on device")
	public void wifiOff() throws InterruptedException {

		NetworkConnection mobileDriver = (NetworkConnection) driver;
		if (mobileDriver.getNetworkConnection() != ConnectionType.AIRPLANE_MODE) {
			// enabling Airplane mode
			mobileDriver.setNetworkConnection(ConnectionType.AIRPLANE_MODE);
		}
	}

	@Step("Scroll Down to the Page Using Bottom Element")
	public boolean scrollDownByElement(List<MobileElement> list) {
		logger.info("Scrolling Down to click on element");
		boolean scroll = false;
		if (list != null && !list.isEmpty()) {
			WebElement bottomElement = list.get(list.size() - 1);
			WebElement topElement = list.get(0);
			Point p1 = getPoint(bottomElement);
			Point p2 = getPoint(topElement);

			try {
				new TouchAction((PerformsTouchActions) AndroidDriverConfig.getAndroidDriver())
						.press(PointOption.point(400, p1.y))
						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(5000)))
						.moveTo(PointOption.point(400, p2.y - 10)).release().perform();
				scroll = true;
			} catch (Exception e) {
				scroll = false;
			} finally {
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
		}
		return scroll;
	}

	@Step("Get X-axis and Y-axis point from Elemet")
	private Point getPoint(WebElement element) {
		return element.getRect().getPoint();
	}

	@Step("Scroll Down/Up using visible text in list")
	public void scrollElementByContentDesc(String scrollableList, String uiSelector, String textToSearchInList) {
		driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector().resourceId(\"" + scrollableList + "\")).getChildByDescription("
						+ "new UiSelector().className(\"" + uiSelector + "\"), \"" + textToSearchInList + "\")"));

	}
	// scrollElementByContentDesc("com.si:id/recyclerViewGS_Home_DCShip",
	// "android.support.v7.widget.RecyclerView",
	// skuNumberOnGlobalSearch.get(0).getText());

	@Step("Scroll Down/UP using visible text")
	public void scroll(String text) {
		String uiSelector = "new UiSelector().textMatches(\"" + text + "\")";
		String command = "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(" + uiSelector
				+ ");";
		driver.findElementByAndroidUIAutomator(command);
		System.out.println("completed Scroll");
	}

	@Step("Scroll Down with javaScript")
	public void scrolljavaScript(String text, String locator) {
		System.out.println("Starting Scroll");
		AndroidDriver drivers = driver;
		MobileElement elemet = (MobileElement) drivers.findElementById(locator);
		JavascriptExecutor js = (JavascriptExecutor) drivers;
		HashMap<String, String> scrollobject = new HashMap<String, String>();
		scrollobject.put("direction", "down");
		scrollobject.put("element", ((RemoteWebElement) elemet).getId());
		scrollobject.put("text", text);
		js.executeScript("mobile: scrollTo", scrollobject);

		drivers.findElement(By.name(text));
		System.out.println("completed Scroll");

	}

	@Step("Scroll Down/UP using visible text")
	public void scrollToAnElementByText(String text) {
		System.out.println("Scroll start" + text);
		driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector())" + ".scrollIntoView(new UiSelector().text(\"" + text + "\"));"));

	}

	@Step("Scroll Down with points")
	public void scrollDown() {
		Dimension dimension = AndroidDriverConfig.getAndroidDriver().manage().window().getSize();
		Double scrollHeightStart = dimension.getHeight() * 0.5;
		int scrollstart = scrollHeightStart.intValue();
		System.out.println("scrollstart" + scrollstart);
		Double scrollHeightEnd = dimension.getHeight() * 0.2;
		int scrollEnd = scrollHeightEnd.intValue();
		System.out.println("scrollEnd" + scrollEnd);
		new TouchAction((PerformsTouchActions) AndroidDriverConfig.getAndroidDriver())
				.press(PointOption.point(400, 550)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
				.moveTo(PointOption.point(400, 10)).release().perform();
	}

	@Step("Scroll  till the text is visible")
	public MobileElement scrollTillWebView(String text, By locator) throws InterruptedException {
		MobileElement skuNumber = null;
		while (getItemWebView(text).size() == 0) {
			System.out.println("Scroll start" + text);
			scrollDown();
			skuNumber = driver.findElement(locator);
		}
		if (getItemWebView(text).size() > 0) {
			System.out.println(getText(locator));
		}

		Thread.sleep(4000);
		return skuNumber;
	}

	public List<MobileElement> getItemWebView(String text) {
		return driver.findElements(By.xpath("//android.widget.TextView[@text='" + text + "']"));
	}
	
	public boolean checkAppStatus(String packageName){
		
		boolean appStatus= driver.isAppInstalled(packageName);
		
		if(appStatus)
		{
		logger.info("Receiving APP is installed already in PDT ");
		}
		else{
			logger.info("Receiving APP is not installed in PDT ");
		}
		
		return appStatus;
	}
	
	public boolean uninstallApp(String packageName){
		
		boolean appStatus= driver.removeApp(packageName);
		
		if(appStatus)
		{
		logger.info("Receiving APP is Uninstalled from PDT");
		}
		else{
			logger.info("Receiving APP is not uninstalled from PDT");
		}
		
		return appStatus;
	}
	
	public void deleteAPKFile(String filePath){
		
		File f = new File(filePath);
		 if( f.exists()){
		 f.delete();
		 logger.info("APK file is deleted from folder");
		 }
		 else{
		 logger.info("No file found to delete");
		 }
		
	}
	
	@Step("Launch URL")
  public void lauchURL(String url, WebDriver webDriver){
		webDriver.navigate().to(url);
		webDriver.get(url.toString());
		logger.info("TID [" + Thread.currentThread().getId() + "] " + "Navigate URL [" + url + "]");
	}
	
	@Step("Send text[{1}] to field: [{0}]")
	protected void setText(final By locator, final CharSequence text,WebDriver webDriver) {
		webDriver.findElement(locator).clear();
		waitPresenseofElement(locator,webDriver);
		webDriver.findElement(locator).sendKeys(text);
		logger.info("Value [" + text + "] is entered");
	}
	
	@Step("Wait to the element will be clickable, selector [{0}]")
	protected void click(final By locator,WebDriver webDriver) {
		webDriver.findElement(locator).click();
		logger.info(locator.toString() + " Element is clicked");

	}
	
	@Step("Wait until the element is visible")
	public void waitPresenseofElement(final By locator,WebDriver webDriver) {
		WebDriverWait wait2 = new WebDriverWait(webDriver, 10);
		wait2.until(ExpectedConditions.presenceOfElementLocated(locator));
	}
	
	
	
}
