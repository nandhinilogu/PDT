package com.web.template;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

/**
 * @author Yurii Chukhrai [Aug 2016]
 * @version - [1.0]
 */

//import static com.util.WebDriverFactory.*;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.util.AndroidDriverConfig;



/**
 * @author Yurii Chukhrai on [Aug 2016]
 * @version - [1.0]
 * @file - [BaseListener.java]
 */
/*
 * This Class provide Actions if something happened in Test Classes
 * (PASS-FAIL-Broken)
 */
public class BaseListener implements ITestListener, IInvokedMethodListener {
	final static Logger logger = Logger.getLogger(BaseListener.class.getName());

	/* Methods of Interface 'ITestListener' */
	@Override
	public void onTestStart(ITestResult result) {
		logger.info("Starting TestCase : " + result.getName());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		logger.info("Success TestCase : " + result.getName());

//		makeScreenCapture(
//				"Test_PASS_" + getFileNameSysPart() + "_" + getDateTimeFormat("MM-dd-yyyy_HH-mm-ss"), getWebDriver());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		logger.info("Failed TestCase : " + result.getName());
		
		
		try {
		File scrFile = ((TakesScreenshot)AndroidDriverConfig.getAndroidDriver()).getScreenshotAs(OutputType.FILE);
		 String imagesLocation = "target/surefire-reports/screenshot/"+result.getName()+".png";
		 
			FileUtils.copyFile(scrFile, new File(imagesLocation));
            Reporter.log("<a href='"+ imagesLocation + "'> <img src='"+ imagesLocation + "' height='100' width='100'/> </a>");

			logger.info("Please refer the screenshot in target/surefire");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
			

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		logger.info("Skipped TestCase : " + result.getName());
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	@Override
	public void onStart(ITestContext context) {
	}

	@Override
	public void onFinish(ITestContext context) {
	}

	@Override
	public void afterInvocation(IInvokedMethod arg0, ITestResult arg1) {
	}

	@Override
	public void beforeInvocation(IInvokedMethod arg0, ITestResult arg1) {
	
	}
}
