package com.util;

import static com.util.AndroidDriverConfig.getProperty;

import java.io.File;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.web.template.AndroidBasePage;

public class APKFileDownloader extends AndroidBasePage {
	private static final Logger logger = Logger.getLogger(APKFileDownloader.class.getName());
	public static final String url= getProperty("hockeyAppURL");
	public static final String downloadFilepath = getProperty("hockeyAppDownloadPath");
	public static final String apk_file_location=getProperty("apk_file_location");
	public  WebDriver webDriver;
	
	public By emailId= By.xpath("//input[@id='user_email']");
	public By passwordField=By.xpath("//input[@id='user_password']");
	public By signInButton=By.xpath("//input[@name='commit']");
	public By receivingAppIcon=By.xpath("//img[contains(@class,'app_icon_no_border')]");
	public By downloadButton=By.xpath("//a[@class='btn btn-ha-primary button']");
	public By dropDownBtn= By.xpath("//a[@class='dropdown-toggle avatar']");
	public By signOutBtn = By.xpath("//a[@class='signout']");
	
	
	public void deleteAppFromPDT(String packageName){
		boolean appStatus =checkAppStatus(packageName);
		
		if (appStatus){
			uninstallApp(packageName);
		}
		
	}
	
	public void deleteAPKFileFromFolder(String filePath){
		deleteAPKFile(filePath);
	}
	
	
	
	public void lauchWebBrowser(){
		WebDriverConfig webDriverConfig = new WebDriverConfig();
		webDriver=webDriverConfig.getWebDriver();
		
		lauchURL(url, webDriver);
		
	}
	
	public void loginToHockeyApp(String email, String password){
		logger.info("Login to Hockey App URL");
		logger.info("Enter Username and Password");
		setText(emailId, email, webDriver);
		setText(passwordField, password, webDriver);
		logger.info("Click on SignIn Button");
		click(signInButton, webDriver);
		waitPresenseofElement(receivingAppIcon, webDriver);
	}
	
	public void downloadAPKFileFromChrome(){
		logger.info("Click on Receiving Icon");
		click(receivingAppIcon, webDriver);
		waitPresenseofElement(downloadButton, webDriver);
		logger.info("Click on Download Button");
		click(downloadButton, webDriver);
		
	}
	
	public void signOutFromHockeyApp(){
		logger.info("Click on DropDown Button");
		click(dropDownBtn, webDriver);
		waitPresenseofElement(signOutBtn, webDriver);
		logger.info("Click on SignOut Button");
		click(signOutBtn, webDriver);
	}
	
	public void quitDriver() throws InterruptedException{
		
		outerloop:
		for(int i=0;i<50 ;i++){
		File f = new File(apk_file_location);
		 if( f.exists()){
			logger.info("Apk file is downloaded closing the browser");
			 webDriver.close();
			 webDriver.quit();
			 break outerloop;
			 
		 }
		 logger.info("Waiting to complete the download");
		 Thread.sleep(4000);
			 
		}
	}

}
