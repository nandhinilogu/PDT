package com.util;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import net.sf.uadetector.ReadableUserAgent;
import net.sf.uadetector.UserAgentStringParser;
import net.sf.uadetector.service.UADetectorServiceFactory;
import ru.yandex.qatools.allure.annotations.Attachment;

public class BaseUtil {

	private final static Logger LOG = Logger.getLogger(BaseUtil.class.getName());

	/*
	 * This Method generate String Time Stamp -> someTest_Win7_FF24_
	 * [2014-12-03_09-40-35]
	 */
	 public static synchronized String getTimeStamp() {
	 return new SimpleDateFormat("MM-dd-yyyy_HH:mm:ss").format(new Date());
	 }

	/**
	 * Patterns: 1) "MM-dd-yyyy_HH:mm:ss" 2) "MMddyy"
	 */
	public static synchronized String getDateTimeFormat(final String pattern) {

		LocalDateTime ldtNow = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		return ldtNow.format(formatter);
	}

	/**
	 * 
	 * Patterns: 1) "HH:mm:ss"
	 */
	public static synchronized String getTimeFormat(final String pattern) {

		LocalTime ltNow = LocalTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		return ltNow.format(formatter);
	}

	public static synchronized boolean isDatePast(final String pattern, final String date) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		LocalDate ldtdate = LocalDate.parse(date, formatter);
		LocalDate ldtNow = LocalDate.now();

		return (ldtNow.isAfter(ldtdate) ? true : false);
	}

	
	public static synchronized String getDateIncementDay(final String pattern, long daysToIncement) {

		LocalDateTime ldtNow = LocalDateTime.now();
		ldtNow = ldtNow.plusDays(daysToIncement);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		return ldtNow.format(formatter);
	}

	public static synchronized String getDateDecreaseDay(final String pattern, long daysToDecrease) {

		LocalDateTime ldtNow = LocalDateTime.now();
		ldtNow = ldtNow.minusDays(daysToDecrease);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		return ldtNow.format(formatter);
	}

	/* This method make Text attachment for Allure report */
	@Attachment(value = "{0}", type = "text/plain")
	public static synchronized String attachText(final String nameOfAttachment, final String bodyOfMassege) {

		LOG.info("Attached to allure file [" + nameOfAttachment + "].");

		return (bodyOfMassege != null && !bodyOfMassege.isEmpty() ? bodyOfMassege : "Empty Content");
	}

	public static synchronized void attachTextCsv(final String nameOfAttachment, final String bodyOfMessage) {

		if(bodyOfMessage != null) {
			attacheFile(nameOfAttachment, bodyOfMessage);
		}
		else {
			LOG.error("Attached input Empty for [" + nameOfAttachment + "]");
		}
	}

	@Attachment(value = "{0}", type = "text/html")
	public static synchronized byte[] attachTextHtml(final String nameOfAttachment, final String bodyOfMassege) {

		return (bodyOfMassege != null && !bodyOfMassege.isEmpty() ? bodyOfMassege.getBytes(StandardCharsets.UTF_8) : "Empty Content".getBytes(StandardCharsets.UTF_8));
	}

	@Attachment(value = "{0}", type = "text/csv")
	private static synchronized byte[] attacheFile(final String nameOfAttachment, final String bodyOfMassege) {
		return (bodyOfMassege != null && !bodyOfMassege.isEmpty() ? bodyOfMassege.getBytes(StandardCharsets.UTF_8)
				: "Empty Content".getBytes(StandardCharsets.UTF_8));
	}
	
	/*
	 * This Method generate String System info for file name ->
	 * someTest_[Win7_FF24_] 2014-12-03_09-40-35
	 */
	public static synchronized String getSysInfo(WebDriver wd) {

		String uAgent = getUAinfo(wd);
		UserAgentStringParser parser = UADetectorServiceFactory.getResourceModuleParser();


		ReadableUserAgent a1 = parser.parse(uAgent);

		return a1.getName().toString() + a1.getVersionNumber().toVersionString().replace(".", "") + "_"
				+ a1.getOperatingSystem().getName().replace(" ", "");
	}

	/* This method generate User Agent info for attachment */
	public static synchronized String getUAinfo(WebDriver wd) {

		return (wd != null ? (String) ((JavascriptExecutor) wd).executeScript("return navigator.userAgent;")
				: "WebDriver [null]");
	}

	public static synchronized String getTodayDate(final String pattern) {
		LocalDateTime ldtToday = LocalDateTime.now();
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
		return ldtToday.format(dateTimeFormatter);
	}




	public boolean isOsExpected(final String osNameExpected) {
		final String osNameActual = System.getProperty("os.name").trim().toUpperCase();
		return (osNameExpected != null && osNameActual.contains(osNameExpected.toUpperCase()) ? true : false);
	}

}// END of CLASS
