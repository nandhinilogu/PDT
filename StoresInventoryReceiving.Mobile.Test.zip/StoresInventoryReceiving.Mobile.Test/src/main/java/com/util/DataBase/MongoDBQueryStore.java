package com.util.DataBase;

import static com.util.AndroidDriverConfig.getProperty;
import static com.util.BaseUtil.getDateDecreaseDay;
import static com.util.BaseUtil.getDateIncementDay;
import static com.util.BaseUtil.getTodayDate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.util.BaseUtil;

import ru.yandex.qatools.allure.annotations.Step;

public class MongoDBQueryStore {
	final static Logger logger = Logger.getLogger(MongoDBQueryStore.class.getName());
	
	@Step("To get the count of records in fs files where driver signature id is stored")
	public long noOfDriverSignatureExistedInFsFiles(MongoCollection<Document> collection2) {

		
		long noOfRecordsInfsFiles = collection2.count();
		logger.info(noOfRecordsInfsFiles);

		return noOfRecordsInfsFiles;

	}
	
	@Step("To get the count and list of Transfer Summery for last 30 days")
	public BasicDBObject queryForValidatingTheTransferSummery(MongoCollection<Document> storeToStoreTransfer, String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String oneMonthOldDate = getDateDecreaseDay("yyyy-MM-dd", 30);
		String currentDate = BaseUtil.getTodayDate("yyyy-MM-dd");
		Date oneMonthdate = format.parse(oneMonthOldDate);
		Date todayDate = format.parse(currentDate);
		addQuery.add(new BasicDBObject("SourceStoreNumber", storeNumber));
		addQuery.add(
				new BasicDBObject("CreatedDateTime", new BasicDBObject("$gte", oneMonthdate).append("$lte", todayDate)));
		originalQuery.put("$and", addQuery);
		
		return originalQuery;
	}

	@Step("To get list of Intransit shipments specific to store - 1 year back date")
	public BasicDBObject queryForOldInTransitShipment(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String oneYearDate = getDateDecreaseDay("yyyy-MM-dd", 365);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 500);
		Date oneYearday = format.parse(oneYearDate);
		Date previousDay = format.parse(prevDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", getProperty(storeNumber)));
		addQuery.add(
				new BasicDBObject("EtaDateTime", new BasicDBObject("$gte", previousDay).append("$lte", oneYearday)));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", false));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get list of Intransit shipments specific to store - T+30")
	public BasicDBObject queryForFutureInTransitShipment(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dateRangeMinimum = getDateIncementDay("yyyy-MM-dd", 31);
		String dateRangeMaximum = getDateIncementDay("yyyy-MM-dd", 150);
		Date minimumRange = format.parse(dateRangeMinimum);
		Date maximumRange = format.parse(dateRangeMaximum);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", getProperty(storeNumber)));
		addQuery.add(
				new BasicDBObject("EtaDateTime", new BasicDBObject("$gte", minimumRange).append("$lte", maximumRange)));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", false));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get list of Intransit shipments specific to store")
	public BasicDBObject queryInTransitShipment(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 30);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 365);
		Date today = format.parse(todayDate);
		Date previousDay = format.parse(prevDate);

		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("EtaDateTime", new BasicDBObject("$gte", previousDay).append("$lte", today)));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", false));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get list of Received shipments specific to store")
	public BasicDBObject queryReceivedShipment(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 30);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 365);
		Date today = format.parse(todayDate);
		Date previousDay = format.parse(prevDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("EtaDateTime", new BasicDBObject("$gte", previousDay).append("$lte", today)));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", true));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("Get carton number and sku number from intransit shipment")
	public BasicDBObject queryForCartonNumberforInTransitShipment(MongoCollection<Document> collection,
			String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", false));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	@Step("Get carton number marked as mispicks")
	public BasicDBObject queryForMispickedCartonNumber(MongoCollection<Document> collection,
			String CartonNumber,String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("Cartons.CartonNumber", CartonNumber));
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	@Step("Get carton number marked as Scanned")
	public BasicDBObject queryForScannedCartonNumber(MongoCollection<Document> collection,
			String CartonNumber,String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("Cartons.CartonNumber", CartonNumber));
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	@Step("Get carton number specific to Store")
	public BasicDBObject queryToGetCartonNumberForSpecificStore(MongoCollection<Document> collection,
			String CartonNumber,String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("Cartons.CartonNumber", CartonNumber));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	public BasicDBObject queryToGetSkuNumberMarkedAsDamagedToday(MongoCollection<Document> collection,
			String skuNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		
		addQuery.add(new BasicDBObject("SkuNumber", skuNumber));
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getTodayDate("yyyy-MM-dd");
		Date today = format.parse(todayDate);
		
		addQuery.add(new BasicDBObject("CreatedTime", new BasicDBObject("$gte", today)));
		addQuery.add(new BasicDBObject("ModifiedTime", new BasicDBObject("$gte", today)));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("Get  sku number from StoreToStoreTransfer")
	public BasicDBObject queryForSkuNumberforSendTransfer(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();

		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", true));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get SKU level details usig carton number and SKU number")
	public BasicDBObject queryInTransitSKuLevel(MongoCollection<Document> collection, String storeNumber,
			String skuNumber, String cartonNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("DestinationStoreNumber", getProperty(storeNumber)));
		addQuery.add(new BasicDBObject("Cartons.CartonNumber", cartonNumber));
		addQuery.add(new BasicDBObject("Cartons.Skus.SkuNumber", skuNumber));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get list of damaged cartons reported on current business day")
	public BasicDBObject queryInTransitDamagedCartons(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getTodayDate("yyyy-MM-dd");
		String nextDate = getDateIncementDay("yyyy-MM-dd", 1);
		Date today = format.parse(todayDate);
		Date nextDay = format.parse(nextDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", getProperty(storeNumber)));
		addQuery.add(new BasicDBObject("Cartons.IsDamaged", true));
		addQuery.add(
				new BasicDBObject("Cartons.Skus.DamagedTime", new BasicDBObject("$gte", today).append("$lt", nextDay)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get list of instore damaged SKUs reported on current business day")
	public BasicDBObject queryInstoreSKUDamages(MongoCollection<Document> collection, int storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = BaseUtil.getTodayDate("yyyy-MM-dd");
		String nextDate = getDateIncementDay("yyyy-MM-dd", 1);
		Date today = format.parse(todayDate);
		Date nextDay = format.parse(nextDate);
		addQuery.add(new BasicDBObject("StoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("CreatedTime", new BasicDBObject("$gte", today).append("$lt", nextDay)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("Get number of shipments for given ETA")
	public BasicDBObject getShipmentByETA(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 0);
		String nextDate = getDateIncementDay("yyyy-MM-dd", 1);
		logger.info("todayDate "+todayDate+" nextDate "+nextDate);
		Date todayDay = format.parse(todayDate);
		Date nextDay = format.parse(nextDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		//addQuery.add(new BasicDBObject("Cartons.IsScanned", false));
		addQuery.add(new BasicDBObject("EtaDateTime", new BasicDBObject("$gte", todayDay).append("$lt", nextDay)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;

	}

	@Step("Get number of shipments using scanned Time")
	public BasicDBObject getReceivedShipmentsByCartons(MongoCollection<Document> collection, String storeNumber,
			String eta) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
		Date toDateRange = format.parse(eta);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", getProperty(storeNumber)));
		addQuery.add(new BasicDBObject("Cartons.ScannedTime", new BasicDBObject("$eq", toDateRange)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;

	}

	@Step("Get number of shipments received in last 5 days using scanned Time")
	public BasicDBObject getReceivedShipmentsByCartonsForMisPick(MongoCollection<Document> collection,
			String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 0);
		String fiveDaysPrev = getDateDecreaseDay("yyyy-MM-dd", 4);
		Date today = format.parse(todayDate);
		Date fiveDaysAgo = format.parse(fiveDaysPrev);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(
				new BasicDBObject("Cartons.ScannedTime", new BasicDBObject("$gte", fiveDaysAgo).append("$lte", today)));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", true));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;

	}

	@Step("Get number of shipments received in last 5 days using scanned Time")
	public BasicDBObject getReceivedShipmentsByCartonsForInTransitDamages(MongoCollection<Document> collection,
			String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 0);

		Date today = format.parse(todayDate);

		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("Cartons.ScannedTime", new BasicDBObject("$eq", today)));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", true));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;

	}

	@Step("Duplicate Carton")
	public BasicDBObject queryForDuplicateCartonNumberFromTransitShipment(MongoCollection<Document> collection,
			String storeNumber) {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("Cartons.IsScanned", true));

		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;

	}
	
	//***************StoreTransfer*****************
	
	@Step("To get list of Intransit store transfer numbers specific to store")
	public BasicDBObject queryStoreTransfers(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 29);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 29);
		Date today = format.parse(todayDate);
		Date previousDay = format.parse(prevDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$gte", previousDay).append("$lte", today)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	@Step("To Validate the submitted Transfer Order")
	public BasicDBObject queryForValidatingTheCreatedTransferNumber(MongoCollection<Document> storeToStoreTransfer, String  newTransferID,String storeNumber ) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();	
		addQuery.add(new BasicDBObject("TransferNumber", newTransferID));
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		originalQuery.put("$and", addQuery);	
		return originalQuery;
	}
	
	@Step("To get all the expected Store Transfer specific to store")
	public  BasicDBObject queryForExpectedStoreTransfer(MongoCollection<Document> storeToStoreTransfer, String storeNumber) throws ParseException
	{
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String incrementDate = getDateIncementDay("yyyy-MM-dd", 31);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 30);
		logger.info("incrementDate "+incrementDate+" prevDate "+prevDate);
		Date incrementDay = format.parse(incrementDate);
		Date previousDay = format.parse(prevDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber",storeNumber ));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$gte", previousDay).append("$lt", incrementDay)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	@Step("To get list of  transfer specific to store for T-30 back date")
	public  BasicDBObject queryForOldTransferForETALessThan30(MongoCollection<Document> storeToStoreTransfer, String storeNumber) throws ParseException{
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String oneYearDate = getDateDecreaseDay("yyyy-MM-dd", 30);
		Date oneYearday = format.parse(oneYearDate);
		
		logger.info("oneYearBeforeDate-->T-30--------- "+oneYearDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$lt", oneYearday)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
		
	}
	
	@Step("To get list of Intransit shipments specific to store > T+30")
	public BasicDBObject queryForFutureTransferForETAGreaterThan30days(MongoCollection<Document> storeToStoreTransfer, String storeNumber) throws ParseException{
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dateRangeMinimum = getDateIncementDay("yyyy-MM-dd", 31);
		Date minimumRange = format.parse(dateRangeMinimum);
		
		logger.info("oneMonthAfterDate-->T+31--------- "+dateRangeMinimum);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(
				new BasicDBObject("ETADateTime", new BasicDBObject("$gte", minimumRange)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	public BasicDBObject validatingUnReceivedTransferInGlobalSearch(MongoCollection<Document> collection,
			String transferNumber) {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(
				new BasicDBObject("TransferNumber", transferNumber));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
		
	}
	
	@Step("To get list of Intransit Purchase order numbers specific to store")
	public BasicDBObject queryPurchaseOrder(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = getDateIncementDay("yyyy-MM-dd", 29);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 29);
		Date today = format.parse(todayDate);
		Date previousDay = format.parse(prevDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$gte", previousDay).append("$lte", today)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	@Step("To get Purchase Order")
	public BasicDBObject queryToGetPurchaseOrder(MongoCollection<Document> POCollection, String  purchaseOrder,String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();	
		addQuery.add(new BasicDBObject("PurchaseOrderNumber", purchaseOrder));
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	@Step("To get all the expected PurchaseOrder specific to store")
	public  BasicDBObject queryForExpectedPurchaseOrder(MongoCollection<Document> purchaseOrderCollection, String storeNumber) throws ParseException
	{
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String incrementDate = getDateIncementDay("yyyy-MM-dd", 31);
		String prevDate = getDateDecreaseDay("yyyy-MM-dd", 30);
		logger.info("incrementDate "+incrementDate+" prevDate "+prevDate);
		Date incrementDay = format.parse(incrementDate);
		Date previousDay = format.parse(prevDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber",storeNumber ));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$gte", previousDay).append("$lt", incrementDay)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	@Step("To get list of  PurchaseOrder specific to store for T-30 back date")
	public  BasicDBObject queryForOldPurchaseOrderForETALessThan30(MongoCollection<Document> purchaseOrderCollection, String storeNumber) throws ParseException{
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String oneYearDate = getDateDecreaseDay("yyyy-MM-dd", 30);
		Date oneYearday = format.parse(oneYearDate);
		
		logger.info("oneYearBeforeDate-->T-30--------- "+oneYearDate);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$lt", oneYearday)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
		
	}
	
	@Step("To get list of PurchaseOrder specific to store > T+30")
	public BasicDBObject queryForFuturePurchaseOrderForETAGreaterThan30days(MongoCollection<Document> purchaseOrderCollection, String storeNumber) throws ParseException{
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dateRangeMinimum = getDateIncementDay("yyyy-MM-dd", 31);
		Date minimumRange = format.parse(dateRangeMinimum);
		
		logger.info("oneMonthAfterDate-->T+31--------- "+dateRangeMinimum);
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
		addQuery.add(new BasicDBObject("ETADateTime", new BasicDBObject("$gte", minimumRange)));
		originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
	
	@Step("Get shipment marked as Damage")
	public BasicDBObject queryForDamagedCartonNumber(MongoCollection<Document> collection,
			String CartonNumber,String storeNumber) throws ParseException {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		addQuery.add(new BasicDBObject("Cartons.CartonNumber", CartonNumber));
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}
//	public BasicDBObject queryFsFilesForDriverSignature(MongoCollection<Document> collection2, String storeNumber) {
//		
//		List 
//		
//		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
//		BasicDBObject originalQuery = new BasicDBObject();
//		addQuery.add(new BasicObject(""))
//		
//		// TODO Auto-generated method stub
//		return null;
//	}

	public BasicDBObject queryForOrphanCartonNumber(MongoCollection<Document> collection, String cartonNumber) {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		
		addQuery.add(new BasicDBObject("CartonNumber", cartonNumber));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

	// FOr in TransitDamage SRA-4 i need one cartonNumber recd in last ? days to
	// search and validate if the offline option is working.
	// For MisPick SRA-4 agin i need one cartonnumber recd in last 5 days to
	// validate in offline mode
	
	
	public BasicDBObject queryForOrphanCartonNumberForStoreNumber(MongoCollection<Document> collection, String storeNumber) {
		List<BasicDBObject> addQuery = new ArrayList<BasicDBObject>();
		BasicDBObject originalQuery = new BasicDBObject();
		
		addQuery.add(new BasicDBObject("DestinationStoreNumber", storeNumber));
        originalQuery.put("$and", addQuery);
		logger.info(originalQuery);
		return originalQuery;
	}

}