package com.util.DataBase;

import static com.util.BaseUtil.getDateDecreaseDay;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.pdt.Pom.AuditingInStoreDamagesScanPage;
import com.pdt.Pom.AuditingInTransitDamagesScanPage;
import com.pdt.Pom.GlobalSearchPage;
import com.pdt.Pom.MispicksScanPage;
import com.pdt.Pom.PurchaseOrderPage;
import com.pdt.Pom.ReceivingShipmentPage;
import com.pdt.Pom.ReceivingShipmentScanPage;
import com.pdt.Pom.ReceivingTransferPage;
import com.pdt.Pom.SendStoreTransferPage;
import com.web.template.BaseTest;

import io.appium.java_client.MobileElement;
import ru.yandex.qatools.allure.annotations.Step;

public class ValidateFromMongoDB extends BaseTest {
	final static Logger logger = Logger.getLogger(ValidateFromMongoDB.class.getName());

	MongoDBQueryStore mongoDB = new MongoDBQueryStore();
	

	public int validateInTransitShipment(MongoCollection<Document> collection, String storeNumber, SoftAssert softassert)
			throws ParseException {

		ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();
		int count = 0;
		BasicDBObject inTransitQuery = mongoDB.queryInTransitShipment(collection, storeNumber);
		long shipmentCount = collection.count(inTransitQuery);
		if (shipmentCount > 0) {
			for (Document doc : collection.find(inTransitQuery).limit(5)) {
				String dbShipmentNumber = String.valueOf(doc.get("ShipmentNumber"));
				String dbDcInformation = String.valueOf(doc.get("DCInformation")).isEmpty() ? null
						: String.valueOf(doc.get("DCInformation"));
				Date dbETA = (Date) doc.get("EtaDateTime");
				String dbDate = convertToDateTime(doc.get("EtaDateTime").toString(), "M/dd/yyyy");
				int cartonQuantity = 0;

				if ((doc.get("Cartons") != null)) {
					java.util.List<Document> cartons = (java.util.List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if (!carton.get("IsScanned", true))
							cartonQuantity++;
					}
				}
				logger.info(dbShipmentNumber + " " + dbDcInformation + " " + cartonQuantity + " " + dbETA);

				receivingShipmentPage.searchForShipmentNumber(dbShipmentNumber);
				receivingShipmentPage.validateLabelsInDCshipmentHomePage(softassert);

				String uiETA = receivingShipmentPage.getETA();
				String uiShipmentNumber = receivingShipmentPage.getShipmentNumber();
				String dcInformationUI = receivingShipmentPage.getDCInfo();
				String cartonTotalUI = receivingShipmentPage.getPendingCarton();
				
				
				softassert.assertEquals(uiShipmentNumber, dbShipmentNumber);
				dbDcInformation = dbDcInformation == "null" ? "" : dbDcInformation;
				softassert.assertEquals(String.valueOf(dcInformationUI), String.valueOf(dbDcInformation));
				softassert.assertEquals(cartonTotalUI, String.valueOf(cartonQuantity));
				softassert.assertEquals(uiETA, dbDate);
				
				count++;
				receivingShipmentPage.clickClearSearch();
			}
			logger.info("Total number of In-Transit shipments are " + count);
		}
		return count;

	}
	
	@SuppressWarnings("unchecked")
	public void validateSkuDetailsInGlobalSearchForCarton( String cartonNumber,String storeNumber)
			throws ParseException {
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		GlobalSearchPage globalSearchPage = new GlobalSearchPage();
		BasicDBObject inTransitQuery = mongoDB.queryToGetCartonNumberForSpecificStore(collection,cartonNumber,storeNumber);
		long shipmentCount = collection.count(inTransitQuery);
		
		if (shipmentCount > 0) {
			for (Document doc : collection.find(inTransitQuery)) {
				
				String dbShipmentNumber = String.valueOf(doc.get("ShipmentNumber"));
				logger.info("Shipment Number is "+dbShipmentNumber);
				
				List<Document> cartons = (List<Document>) doc.get("Cartons");
				for (Document carton : cartons) {
					String dbCarton=carton.getString("CartonNumber");
					if (dbCarton.equals(cartonNumber)) {
						logger.info("Carton Number from DB "+dbCarton);
						String uiCartonNumber = globalSearchPage.getCartonNumberInGlobalSearch().substring(8);
						Assert.assertEquals(dbCarton, uiCartonNumber);
						
					if ((carton.get("Skus") != null)) {
						List<Document> skus = (List<Document>) carton.get("Skus");
						for (Document sku : skus) {

							String dbSkuNumber = sku.getString("SkuNumber");
							String dbSkuDescription = String.valueOf(sku.get("SkuDescription")).equals("null") ? ""
									: sku.getString("SkuDescription");
							String dbskuShippedQuantity = String.valueOf(sku.getInteger("ShippedQuantity"));
							String dbskuDamagedQuantity = String.valueOf(sku.getInteger("DamagedQuantity"));
							String dbSpecialHandling = String.valueOf(sku.get("SpecialHandlingCode")).equals("null") ? "None"
									: sku.getString("SpecialHandlingCode");
							
							logger.info("SKU Number from DB "+dbSkuNumber);
							logger.info("SKU Description from DB is " + dbSkuDescription);
							logger.info("Shipped Qty from DB is " + dbskuShippedQuantity);
							logger.info("Damaged Qty from DB "+dbskuDamagedQuantity);
							logger.info("SpecialHandling from DB is " + dbSpecialHandling);
							
							String uiSkuNo = globalSearchPage.getSkuNumberForCarton();
							String uiSkuDescForCarton = globalSearchPage.getSkuDescForCarton();
							String uiSkuQty=globalSearchPage.getCartonSkuShippedQty();
							String uiSkuDamagedQty=globalSearchPage.getCartonSkuDamagedQty();
							String uiSpecialHandling=globalSearchPage.getSpecialHandlingForCarton();
							
							
							logger.info("SKU Number from UI "+uiSkuNo);
							logger.info("SKU Description from UI is " + uiSkuDescForCarton);
							logger.info("Shipped Qty from UI is " + uiSkuQty);
							logger.info("Damaged Qty from UI "+ uiSkuDamagedQty);
							logger.info("SpecialHandling from UI is " + uiSpecialHandling);
							
							Assert.assertEquals(dbSkuNumber, uiSkuNo);
							Assert.assertEquals(dbSkuDescription, uiSkuDescForCarton);
							Assert.assertEquals(dbskuShippedQuantity, uiSkuQty);
							Assert.assertEquals(dbskuDamagedQuantity, uiSkuDamagedQty);
							Assert.assertEquals(dbSpecialHandling, uiSpecialHandling);
							
						}
					}
				}
			}
		}
			
		}
	
	}
	
	@SuppressWarnings("unchecked")
	public void validateSpecialHandlingInGlobalSearchForCarton( String cartonNumber,String storeNumber,String currentTime)
			throws ParseException {
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		GlobalSearchPage globalSearchPage = new GlobalSearchPage();
		BasicDBObject inTransitQuery = mongoDB.queryToGetCartonNumberForSpecificStore(collection,cartonNumber,storeNumber);
		long shipmentCount = collection.count(inTransitQuery);
		
		if (shipmentCount > 0) {
			for (Document doc : collection.find(inTransitQuery)) {
				
				String dbShipmentNumber = String.valueOf(doc.get("ShipmentNumber"));
				logger.info("Shipment Number is "+dbShipmentNumber);
				
				List<Document> cartons = (List<Document>) doc.get("Cartons");
				for (Document carton : cartons) {
					String dbCarton=carton.getString("CartonNumber");
					if (dbCarton.equals(cartonNumber)) {
						logger.info("Carton Number from DB "+dbCarton);
						String uiCartonNumber = globalSearchPage.getCartonNumberInGlobalSearch().substring(8);
						Assert.assertEquals(dbCarton, uiCartonNumber);
						
					if ((carton.get("Skus") != null)) {
						List<Document> skus = (List<Document>) carton.get("Skus");
						for (Document sku : skus) {

							String dbSkuNumber = sku.getString("SkuNumber");
							String dbSpecialHandling = sku.getString("SpecialHandlingCode");
							
//							String lastDocumentUpdate=String.valueOf(doc.get("LastDocumentUpdate"));
//							String formattedlastDocumentUpdateTime = convertToDateTime(lastDocumentUpdate, "MM/dd/yyyy HH:mm");
							
							logger.info("SKU Number from DB "+dbSkuNumber);
							logger.info("SpecialHandling from DB is " + dbSpecialHandling);
//							logger.info("LastDocumentUpdateTime from DB "+formattedlastDocumentUpdateTime);
							
							String uiSkuNo = globalSearchPage.getSkuNumberForCarton();
							String uiSpecialHandling=globalSearchPage.getSpecialHandlingForCarton();
							
							Assert.assertEquals(dbSkuNumber, uiSkuNo);
							Assert.assertEquals(dbSpecialHandling, uiSpecialHandling);
//							Assert.assertEquals(formattedlastDocumentUpdateTime,currentTime);
							
						}
					}
				}
			}
		}
			
		}
	
	}


	public void validateCreatedTransferNumberInDB(String TransferNumberOnHomeScreen,SoftAssert localassert,String skuNumber, String skuDescription, String transferCreatedTime, String createdBy,String storeNumber ) throws ParseException {
		
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection,
				TransferNumberOnHomeScreen,storeNumber);
		int createdTransferCount = (int) collection.count(query);
		System.out.println(createdTransferCount);
		Assert.assertEquals(createdTransferCount, 1);
       logger.info("Record exist, The count is:" + createdTransferCount);
       if (createdTransferCount > 0) {
			for (Document doc : collection.find(query)) {
				
				String dbTransferNumber = String.valueOf(doc.get("TransferNumber"));
				localassert.assertEquals(dbTransferNumber, TransferNumberOnHomeScreen);
				logger.info("dbTransferNumber " + dbTransferNumber + " CreatedTransferNumber "
						+ TransferNumberOnHomeScreen);
				
				String dbCreatedBy = doc.getString("Createdby");
				String dbCreatedTime=	String.valueOf(doc.get("CreatedDateTime"));				
				String formattedCreatedTime = convertToDateTime(dbCreatedTime, "MM/dd/yyyy HH:mm");
				
				localassert.assertEquals(dbCreatedBy, createdBy);
				localassert.assertEquals(formattedCreatedTime, transferCreatedTime);
				logger.info("dbCreatedBy " + dbCreatedBy + " createdBy "
						+ createdBy);
				logger.info("dbCreatedTime " + formattedCreatedTime + " transferCreatedTime "
						+ transferCreatedTime);
				
				
				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
				
				String dbSkuNumber = sku.getString("SkuNumber");
				String dbSkuDescription = sku.getString("SkuDescription");
				String dbSkuQty =  String.valueOf(sku.get("ShippedQuantity"));
				
				
				localassert.assertEquals(dbSkuNumber, skuNumber);
				localassert.assertEquals(dbSkuDescription,skuDescription);
				localassert.assertEquals(dbSkuQty, "1");
				logger.info("dbSkuNumber " + dbSkuNumber + " CreatedSkuNumber "
						+ skuNumber);
				logger.info("dbSkuDescription " + dbSkuDescription + " CreatedSkuDescription "
						+ skuDescription);
				logger.info("dbSkuQty " + dbSkuQty + " SkuQty "
						+ "1");
				
			}
				}
			}
       }
	}

	public int getExpectedCartonQuantity(MongoCollection<Document> collection, String storeNumber)
			throws ParseException {

		BasicDBObject inTransitQuery = mongoDB.getShipmentByETA(collection, storeNumber);

		long shipmentCount = collection.count(inTransitQuery);
		int cartonQuantity = 0;
		if (shipmentCount > 0) {
			for (Document doc : collection.find(inTransitQuery)) {
				String shipmentNumber = String.valueOf(doc.get("ShipmentNumber"));
				logger.info("Shipment Number is "+shipmentNumber);
				if ((doc.get("Cartons") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						boolean isScannedCarton = Boolean.parseBoolean(String.valueOf(carton.get("IsScanned")));
						if (isScannedCarton == false) {
							String cartonNumber = String.valueOf(carton.get("CartonNumber"));
							cartonQuantity=cartonQuantity+1;
							logger.info("Carton Number is "+cartonNumber);
						}
					}
				}
			}
		}
		return cartonQuantity;
	}

	public void validateShipmentInfo(MongoCollection<Document> collection, String storeNumber) throws ParseException {

		ReceivingShipmentPage receivingShipmentPage = new ReceivingShipmentPage();

		BasicDBObject inTransitQuery = mongoDB.queryInTransitShipment(collection, storeNumber);

		long shipmentCount = collection.count(inTransitQuery);
		if (shipmentCount > 0) {
			for (Document doc : collection.find(inTransitQuery).limit(1)) {

				String dbShipmentNumber = String.valueOf(doc.get("ShipmentNumber"));
				String dbDcInformation = String.valueOf(doc.get("DCInformation")).isEmpty() ? null
						: String.valueOf(doc.get("DCInformation"));
				Date dbETA = (Date) doc.get("EtaDateTime");
				DateFormat dateFormat = new SimpleDateFormat("M/dd/yyyy");
				String dbDate = dateFormat.format(dbETA);
				int cartonQuantity = 0;

				if ((doc.get("Cartons") != null)) {
					java.util.List<Document> cartons = (java.util.List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if (!carton.get("IsScanned", true))
							cartonQuantity++;
					}
				}

				logger.info(dbShipmentNumber + " " + dbDcInformation + " " + cartonQuantity + " " + dbETA);

				receivingShipmentPage.searchForShipmentNumber(dbShipmentNumber);

				String uiETA = receivingShipmentPage.getETA();
				String uiShipmentNumber = receivingShipmentPage.getShipmentNumber();
				String dcInformationUI = receivingShipmentPage.getDCInfo();
				String cartonTotalUI = receivingShipmentPage.getPendingCarton();

				assertEquals(uiShipmentNumber, dbShipmentNumber);
				dbDcInformation = dbDcInformation == "null" ? "" : dbDcInformation;
				assertEquals(String.valueOf(dcInformationUI), String.valueOf(dbDcInformation));
				assertEquals(cartonTotalUI, String.valueOf(cartonQuantity));
				// assertEquals(uiETA, dbDate);

			}
		}
	}

	public void validate30DaysTransferSummery(String storeNumber, SoftAssert softassert) throws ParseException {

		SendStoreTransferPage sendStoreTransfer = new SendStoreTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject sendTransferSummery = mongoDB.queryForValidatingTheTransferSummery(collection, storeNumber);

		long sendTransferCount = collection.count(sendTransferSummery);
		logger.info("Total Records matching the critria are" + sendTransferCount);

		if (sendTransferCount > 0) {
			for (Document doc : collection.find(sendTransferSummery)) {

				String transferNumber = String.valueOf(doc.get("TransferNumber"));
				String destinationStoreNumber = String.valueOf(doc.get("DestinationStoreNumber"));

				int shippedQty = 0;

				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						shippedQty = shippedQty + sku.getInteger("ShippedQuantity");
					}
				}
				logger.info(transferNumber + " " + destinationStoreNumber + " " + shippedQty + " ");

				sendStoreTransfer.searchForTransferNumber(transferNumber);
				
				sendStoreTransfer.validateLabelsInSendStoreTransfersHomePage(softassert);

				String transferNumberOnSendTransferScreenUI = sendStoreTransfer.getTransferNumber();
				String destinationStoreNumberOnTransferScreenUI = sendStoreTransfer.getDestinationStoreNumber()
						.substring(3);
				String totalSquQTYUIUI = sendStoreTransfer.getTotalQty();

				softassert.assertEquals(transferNumberOnSendTransferScreenUI, "TRANSFER  " + transferNumber);

				softassert.assertEquals(destinationStoreNumberOnTransferScreenUI, destinationStoreNumber);
				softassert.assertEquals(totalSquQTYUIUI, Integer.toString(shippedQty));
				
			}

		}

	}

	public void validateCreatedInTransitTransferNumberInDB(String sendStoreTransferNumber,SoftAssert localAssert,String storeNumber) throws ParseException {
		
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, sendStoreTransferNumber,storeNumber);
		int createdTransferCount = (int) collection.count(query);
		System.out.println(createdTransferCount);
		Assert.assertEquals(1, createdTransferCount);

		if (createdTransferCount > 0) {
			for (Document doc : collection.find(query)) {

				String transferNumber = String.valueOf(doc.get("TransferNumber"));
				String sourceStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				String ETA = String.valueOf(doc.get("ETADateTime"));
				String dbFormattedETA = convertToDateTime(ETA, "M/d/yyyy");
				System.out.println(dbFormattedETA);
				int shippedQty = 0;

				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						shippedQty = shippedQty + sku.getInteger("ShippedQuantity");
					}
				}
				logger.info(transferNumber + " " + sourceStoreNumber + " " + shippedQty + " ");

				// receiveStoreTransfer.searchForReceiveTransfer(sendStoreTransferNumber);
				String transferNumberOnReceiveTransferHomeScreenUI = receiveStoreTransfer.getTransferNoOnTransferHome();
				String SourceStoreNumberOnTransferHomeScreenUI = receiveStoreTransfer
						.getSourceStoreNumberOnTransferHome();
				String totalSquQTYHomeScreenUI = receiveStoreTransfer.getSkuQtyOntransferHome();
				String ETADAteHomeScreenUI = receiveStoreTransfer.getETAOnTransferHome();

				System.out.println(ETADAteHomeScreenUI);

				localAssert.assertEquals(transferNumberOnReceiveTransferHomeScreenUI, "TRANSFER  " + transferNumber);
				localAssert.assertEquals(SourceStoreNumberOnTransferHomeScreenUI, sourceStoreNumber);
				localAssert.assertEquals(totalSquQTYHomeScreenUI, Integer.toString(shippedQty));
				localAssert.assertEquals(ETADAteHomeScreenUI, dbFormattedETA);

				receiveStoreTransfer.validateReceiveTransferHomePageHeading();

				receiveStoreTransfer.validateGobackInHomePage();
				localAssert.assertAll();

			}

		}
	}

	public String convertToDateTime(String dateToConvert, String pattern) {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("E MMM dd HH:mm:ss z yyyy");
		LocalDateTime dateTime = LocalDateTime.parse(dateToConvert, dateTimeFormatter);
		DateTimeFormatter formatterForRightFormat = DateTimeFormatter.ofPattern(pattern);
		String convertedDate = dateTime.format(formatterForRightFormat);
		return convertedDate;

	}

	public String convertUiDate(String ETADateUI) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = dateFormat.parse(ETADateUI);
		String formateddate = dateFormat.format(date);
		return formateddate;
	}

	// added by ruthra for SRA147
	@SuppressWarnings("unchecked")
	public void validateExpectedTransfer(String storeNumber,SoftAssert softassert) throws ParseException {

		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedStoreTransfer = mongoDB.queryForExpectedStoreTransfer(collection, storeNumber);

		int expecetdQuantity = 0;
		long expectedTransferCount = collection.count(expectedStoreTransfer);
		logger.info("Fetched Transfer count from DB is " + expectedTransferCount);

		if (expectedTransferCount > 0) {
			for (Document doc : collection.find(expectedStoreTransfer)) {
				
				int pendingQuantity = 0;
				boolean pendingSkuCount = false;
				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {

						if (sku.get("ShippedQuantity") != null) {
							if (sku.getInteger("ShippedQuantity") != 0) {
								int dbShippedQuantity = sku.getInteger("ShippedQuantity");
								int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
								if (dbReceivedQuantity < dbShippedQuantity) {
									pendingSkuCount = true;
									expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
									pendingQuantity = pendingQuantity + expecetdQuantity;
									// System.out.println("pendingQuantity
									// "+pendingQuantity);
								}
							}
						}
					}
				}
				if (pendingSkuCount == true) {
					String transferNumber = String.valueOf(doc.get("TransferNumber"));
					String sourceStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));

					String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
					String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");

					// System.out.println("DB date "+dbETADateTime);
					logger.info("transferNumber " + transferNumber + " sourceStoreNumber " + sourceStoreNumber
							+ " pendingQuantity " + pendingQuantity + " dbFormattedETA " + dbFormattedETA);

					receiveStoreTransfer.searchForReceiveTransfer(transferNumber);
					
					
					String transferNumberOnReceiveTransferHomeScreenUI = receiveStoreTransfer
							.getTransferNoOnTransferHome();
					String SourceStoreNumberOnTransferHomeScreenUI = receiveStoreTransfer
							.getSourceStoreNumberOnTransferHome();
					String totalSquQTYHomeScreenUI = receiveStoreTransfer.getSkuQtyOntransferHome();
					String ETADAteHomeScreenUI = receiveStoreTransfer.getETAOnTransferHome();
					String uiConvertedDate = convertUiDate(ETADAteHomeScreenUI);
					logger.info("uiConvertedDate " + uiConvertedDate);
					logger.info("Given transfer is available in HomePage as expected");

					softassert.assertEquals(transferNumberOnReceiveTransferHomeScreenUI, "TRANSFER  " + transferNumber);
					softassert.assertEquals(SourceStoreNumberOnTransferHomeScreenUI, sourceStoreNumber);
					softassert.assertEquals(totalSquQTYHomeScreenUI, String.valueOf(pendingQuantity));
					softassert.assertEquals(uiConvertedDate, dbFormattedETA);
					
					
				}
				
			}
		}
	}

	@Step("Get In-Transit store transfer numbers for ETA T-365 from DB and validate not matches in UI-Summary table")
	public void validateOldTransferForETALessThan30(String storeNumber) throws ParseException {
		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedStoreTransfer = mongoDB.queryForOldTransferForETALessThan30(collection, storeNumber);

		long expectedTransferCount = collection.count(expectedStoreTransfer);
		logger.info("Fetched Transfer count from DB is " + expectedTransferCount);

		if (expectedTransferCount > 0) {
			for (Document doc : collection.find(expectedStoreTransfer)) {

				String transferNumber = String.valueOf(doc.get("TransferNumber"));
				String sourceStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
				String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
				// System.out.println("DB date "+dbETADateTime);
				logger.info("transferNumber " + transferNumber + " sourceStoreNumber " + sourceStoreNumber
						+ " dbFormattedETA " + dbFormattedETA);

				receiveStoreTransfer.searchForReceiveTransferFromDB(transferNumber);
				receiveStoreTransfer.verifyTransferNumberIsNotDisplayed();

			}

		} else {
			logger.info("No old intransit store transfer are available");
		}
	}

	@Step("Get In-Transit store transfer numbers for ETA T+30 from DB and validate not matches in UI-Summary table")
	public void validateFutureTransferForETAGreaterThan30(String storeNumber) throws ParseException {

		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedStoreTransfer = mongoDB.queryForFutureTransferForETAGreaterThan30days(collection,
				storeNumber);

		long expectedTransferCount = collection.count(expectedStoreTransfer);
		logger.info("Fetched Transfer count from DB is " + expectedTransferCount);

		if (expectedTransferCount > 0) {
			for (Document doc : collection.find(expectedStoreTransfer)) {

				String transferNumber = String.valueOf(doc.get("TransferNumber"));
				String sourceStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
				String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
				// System.out.println("DB date "+dbETADateTime);
				logger.info("transferNumber " + transferNumber + " sourceStoreNumber " + sourceStoreNumber
						+ " dbFormattedETA " + dbFormattedETA);

				receiveStoreTransfer.searchForReceiveTransferFromDB(transferNumber);
				receiveStoreTransfer.verifyTransferNumberIsNotDisplayed();

			}

		} else {
			logger.info("No intransit store transfer are available after 30 days");
		}

	}

	@SuppressWarnings("unchecked")
	public void validateForPendingQtyZeroInReceiveTransfer(String storeNumber) throws ParseException {

		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedStoreTransfer = mongoDB.queryForExpectedStoreTransfer(collection, storeNumber);

		int expecetdQuantity = 0;
		long expectedTransferCount = collection.count(expectedStoreTransfer);
		logger.info("Fetched Transfer count from DB is " + expectedTransferCount);

		if (expectedTransferCount > 0) {
			for (Document doc : collection.find(expectedStoreTransfer)) {
				int pendingQuantity = 0;
				boolean pendingSkuCount = false;
				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						if (sku.get("ShippedQuantity") != null) {
							if (sku.getInteger("ShippedQuantity") != 0) {
								int dbShippedQuantity = sku.getInteger("ShippedQuantity");
								int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
								pendingSkuCount = true;
								expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
								pendingQuantity = pendingQuantity + expecetdQuantity;
							}
						}
					}
				}
				if ((pendingSkuCount = true) && (pendingQuantity == 0)) {
					String transferNumber = String.valueOf(doc.get("TransferNumber"));
					String sourceStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
					String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
					String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
					// System.out.println("DB date "+dbETADateTime);
					logger.info("transferNumber " + transferNumber + " sourceStoreNumber " + sourceStoreNumber
							+ " pendingQuantity " + pendingQuantity + " dbFormattedETA " + dbFormattedETA);

					receiveStoreTransfer.searchForReceiveTransferFromDB(transferNumber);
					receiveStoreTransfer.verifyTransferNumberIsNotDisplayed();
				}
			}
		}
	}

	@Step("Validation For Sku Detail in Transfer")
	public void ValidationForSkuDetailInReceiveTransfer(String transferNumberCreated, String skuNumberCreated,
			SoftAssert localAssert,String storeNumber) throws ParseException {

		ReceivingTransferPage receiveStoreTransfer = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumberCreated,storeNumber);
		long createdTransferCount = collection.count(query);
		logger.info("Fetched Transfer count from DB is " + createdTransferCount);

		if (createdTransferCount > 0) {
			for (Document doc : collection.find(query)) {

				String transferNumber = String.valueOf(doc.get("TransferNumber"));
				logger.info("Fetched Transfer is " + transferNumber);
				if ((doc.get("SKUs") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
						String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
						String dbSkuDescription = sku.getString("SkuDescription") == null ? "" :sku.getString("SkuDescription") ;
						String dbspecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
								:sku.getString("SpecialHandlingCode");
						if (dbSkuNumber.equals(skuNumberCreated)) {
							String uiSkuNumber = receiveStoreTransfer.getSkuNumber();
							String uiShippedSkuQty = receiveStoreTransfer.getSkuShippedQtySkuDetailPage();
							String uiReceivedSkuQty = receiveStoreTransfer.getSkuReceivedQtySkuDetailPage();
							String uiSkuDescription = receiveStoreTransfer.getSkuDescSkuDetailPage();
							String uiSpecialHandling = receiveStoreTransfer.getSpecialHandlingSkuDetailPage();

							logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber + "]");
							logger.info("UI SKU shipped quantity[" + uiShippedSkuQty + "] and DB Shipped quantity["
									+ dbShippedSkuQty + "]");
							logger.info("UI SKU received quantity[" + uiReceivedSkuQty + "] and DB received quantity["
									+ dbReceivedSkuQty + "]");
							logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
									+ dbSkuDescription + "]");
							logger.info("UI Special Handling[" + uiSpecialHandling + "] and DB Special Handling["
									+ dbspecialHandling + "]");

							localAssert.assertEquals(dbSkuNumber, uiSkuNumber); // skuno
							localAssert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
							localAssert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
							localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
							localAssert.assertEquals(dbspecialHandling, uiSpecialHandling);

						}
					}
				}
			}
		}
	}

	public void validateTranferNumberAndETAFromDB(String transferNumber,String storeNumber) throws ParseException {
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumber,storeNumber);
		long transferCount = collection.count(query);
		logger.info("Fetched Transfer count from DB is " + transferCount);

		if (transferCount > 0) {
			for (Document doc : collection.find(query)) {
				String transferNo = String.valueOf(doc.get("TransferNumber"));
				logger.info("Fetched Transfer is " + transferNo);
				String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
				String dbFormattedETA = convertToDateTime(dbETADateTime, "M/d/yyyy");
				logger.info("transferNo " + transferNo + " dbFormattedETA " + dbFormattedETA);
				String transferNumberUI = globalSearch.getTransferNoOnGlobalSearch();
				String ETADateHomeScreenUI = globalSearch.getETAOnGlobalSearch();

				logger.info("ETADateHomeScreenUI " + ETADateHomeScreenUI);
				assertEquals(transferNumberUI, transferNo);
				assertEquals(ETADateHomeScreenUI, dbFormattedETA);
				logger.info("ETA validated");

			}

		}
	}

	public void validateRecedTransferDateInDB(String transferNumber,String storeNumber) throws ParseException {
		GlobalSearchPage globalSearch = new GlobalSearchPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumber,storeNumber);
		long transferCount = collection.count(query);
		logger.info("Fetched Transfer count from DB is " + transferCount);

		if (transferCount > 0) {
			for (Document doc : collection.find(query)) {
				String transferNo = String.valueOf(doc.get("TransferNumber"));
				logger.info("Fetched Transfer is " + transferNo);
				List<Document> skus = (List<Document>) doc.get("SKUs");
				String scannedTime = String.valueOf(skus.get(0).get("ScannedTime"));
				String dbFormattedScannedTime = convertToDateTime(scannedTime, "M/d/yyyy");

				logger.info("transferNumber " + transferNo + " dbFormattedScannedTime " + dbFormattedScannedTime);
				String transferNumberUI = globalSearch.getTransferNoOnGlobalSearch();
				String scannedTimeOnGlobalSearchUI = globalSearch.getScannedTimeOnGlobalSearch();
				logger.info("scannedTimeOnGlobalSearchUI " + scannedTimeOnGlobalSearchUI);
				assertEquals(transferNumberUI, transferNo);
				assertEquals(scannedTimeOnGlobalSearchUI, dbFormattedScannedTime);
			}

		}
	}

	@Step("Get expected sku qty to validate Receive Transfer summary")
	public int getPendingSkuQuantity(String sendStoreTransferNumber,String storeNumber) throws ParseException {

		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, sendStoreTransferNumber,storeNumber);
		int createdTransferCount = (int) collection.count(query);
		logger.info("Fetched Transfer count from DB is " + createdTransferCount);
		Assert.assertEquals(createdTransferCount,1 );
		int expectedQuantity = 0;
		int pendingQuantity = 0;

		if (createdTransferCount > 0) {
			for (Document doc : collection.find(query)) {

				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {

						if (sku.getInteger("ShippedQuantity") != 0) {
							int dbShippedQuantity = sku.getInteger("ShippedQuantity");
							int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");

							expectedQuantity = dbShippedQuantity - dbReceivedQuantity;
							logger.info("ShippedQty  " + dbShippedQuantity + "  ReceivedQty  " + dbReceivedQuantity);
							System.out.println("expectedQuantity " + expectedQuantity);
							pendingQuantity = pendingQuantity + expectedQuantity;
							System.out.println("pendingQuantity " + pendingQuantity);

						}

						else {
							logger.info("No Pending Qty is Calculated from DB");
						}
					}
				}
			}
		}
		return pendingQuantity;
	}

	@Step("Get Pending sku Qty to validate In Purchase Order summary")
	public int validatePendingSkuQuantityForPurchaseOrder(String purchaseOrder, SoftAssert localAssert,String storeNumber)
			throws ParseException {
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject query = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrder,storeNumber);
		long purchaseOrderCount = collection.count(query);
		logger.info("Fetched PO count from DB is " + purchaseOrderCount);

		int shippedQuantity = 0;
		int receivedQuantity = 0;
		int shortage = 0;

		if (purchaseOrderCount > 0) {
			for (Document doc : collection.find(query)) {
				String PONumber = String.valueOf(doc.get("PurchaseOrderNumber"));
				logger.info("Fetched PO is " + PONumber);

				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						logger.info("dbSkuNumber "+dbSkuNumber);
						int dbShippedQuantity = sku.getInteger("ShippedQuantity");
						int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");

						shippedQuantity = shippedQuantity + dbShippedQuantity;
						receivedQuantity = receivedQuantity + dbReceivedQuantity;
					}
					
					logger.info("shippedQuantityfromDB " + shippedQuantity + " receivedQTYfromDB " + receivedQuantity);
					shortage = shippedQuantity - receivedQuantity;
					logger.info("shortagefromDB " + shortage);
				}
			}

			String uiExpectedQuantity = purchaseOrderPage.getExpectedSkusOnPOSummaryPage();
			localAssert.assertEquals(uiExpectedQuantity, String.valueOf(shippedQuantity));

			String uiReceivedQuantity = purchaseOrderPage.getReceivedSkusOnPOSummaryPage();
			localAssert.assertEquals(uiReceivedQuantity, String.valueOf(receivedQuantity));

			String uiShortage = purchaseOrderPage.getShortageOnPOSummaryPage();
			localAssert.assertEquals(uiShortage, String.valueOf(shortage));
		}

		return shippedQuantity;
	}

	public int getReceivedSkuQuantityForMispickedCarton(String cartonNumber,String storeNumber) throws ParseException {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForMispickedCartonNumber(collection, cartonNumber,storeNumber);
		long ShipmentCount = (int) collection.count(query);
		
		Assert.assertEquals(1, ShipmentCount);
		logger.info("Mispicked Carton Count From DB is " + ShipmentCount);
		int receivedQuantity = 0;

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				if ((doc.get("Cartons") != null)) {
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {

								int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
								logger.info("Updated Received Qty From DB is " + dbReceivedQuantity);
								receivedQuantity = receivedQuantity + dbReceivedQuantity;
							}

						}
					}

				}
			}
		}
		return receivedQuantity;
	}
	
	@Step("To validate Mispick Time after Editing the Qty")
	public void validateMispickTimefromDB(String cartonNumber,String submitLocalTime,String storeNumber) throws ParseException {
		SoftAssert localAssert = new SoftAssert();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber,storeNumber);
		long ShipmentCount = collection.count(query);
		
		logger.info("Mispicked Carton Count From DB is " + ShipmentCount);

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				List<Document> cartons = (List<Document>) doc.get("Cartons");
				
					for (Document carton : cartons) {
						String dbCarton=carton.getString("CartonNumber");
						if (dbCarton.equals(cartonNumber)) {
							logger.info("Carton Number is "+dbCarton);
							
							String cartonMispickTimeDB = String.valueOf(carton.get("MispickScannedTime"));
							String formattedCartonMispickTime = convertToDateTime(cartonMispickTimeDB, "MM/dd/yyyy HH:mm");
							localAssert.assertEquals(formattedCartonMispickTime, submitLocalTime);
							logger.info("carton MispickTime from DB "+formattedCartonMispickTime);
							
//							String lastDocumentUpdate=String.valueOf(doc.get("LastDocumentUpdate"));
//							String formattedlastDocumentUpdateTime = convertToDateTime(lastDocumentUpdate, "MM/dd/yyyy HH:mm");
//							localAssert.assertEquals(formattedlastDocumentUpdateTime,submitLocalTime );
//							logger.info("LastDocumentUpdateTime from DB "+formattedlastDocumentUpdateTime);
							
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {

								String skuMispickTimeDB = String.valueOf(sku.get("MispickScannedTime"));
								String dbFormattedMispickTime = convertToDateTime(skuMispickTimeDB, "MM/dd/yyyy HH:mm");
								
								
								localAssert.assertEquals(dbFormattedMispickTime,submitLocalTime );
								logger.info("Sku MispickTime from DB "+dbFormattedMispickTime);
								
								localAssert.assertAll();
								
							}
						}
					}
				}
			}
		}
	}
	

	@Step("To validate Sku details for Sku which is added to mispicked carton")
	public void getSkuDetailsForMispickedCarton(String cartonNumber, String skuNumberCreated, SoftAssert softassert, String editedSkuQty,String storeNumber)
			throws ParseException {
		SoftAssert localAssert = new SoftAssert();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForMispickedCartonNumber(collection, cartonNumber,storeNumber);
		long ShipmentCount = (int) collection.count(query);
		System.out.println(ShipmentCount);
		Assert.assertEquals(1, ShipmentCount);
		logger.info("Mispicked Carton Count From DB is " + ShipmentCount);
		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				if ((doc.get("Cartons") != null)) {
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {
								String dbSkuNumber = sku.getString("SkuNumber");
								String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
								String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));					
								String dbSkuDescription = sku.getString("SkuDescription");
								String dbSpecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
										:sku.getString("SpecialHandlingCode");
								if (dbSkuNumber.equals(skuNumberCreated)) {
									String uiSkuNumber = mispicksScanPage.getSkuNumberFromCartonDetailPage();
									String uiSkuDescription = mispicksScanPage.getSkuDescriptionFromCartonDetailPage();
									String uiShippedSkuQty = mispicksScanPage.getSkuQtyCartonDetailPage();
									String uiReceivedSkuQty = mispicksScanPage.getReceivedSkuQtyCartonDetailPage();
									String uiSpecialHandlingCode = mispicksScanPage.getSpecialHandlingCartonDetailPage();
									logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber
											+ "]");
									logger.info("UI SKU shipped quantity[" + uiShippedSkuQty
											+ "] and DB Shipped quantity[" + dbShippedSkuQty + "]");
									logger.info("UI SKU received quantity[" + uiReceivedSkuQty
											+ "] and DB received quantity[" + dbReceivedSkuQty + "]");
									logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
											+ dbSkuDescription + "]");
									logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
											+ dbSpecialHandling + "]");

									softassert.assertEquals(dbSkuNumber, uiSkuNumber);
									softassert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
									softassert.assertEquals(dbReceivedSkuQty, editedSkuQty);
									softassert.assertEquals(dbSkuDescription, uiSkuDescription);
									softassert.assertEquals(dbSpecialHandling, uiSpecialHandlingCode);
								}

							}
						}
					}

				}
			}
		}
	}

	@Step("To validate Sku details for Sku which is added to mispicked carton")
	public void getSkuDetailsForMispickedCartonWithSingleSku(String cartonNumber, String skuNumberCreated, SoftAssert softassert,String storeNumber, String skuQtyNumber)
			throws ParseException {
		
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForMispickedCartonNumber(collection, cartonNumber,storeNumber);
		int expecetdQuantity = 0;
		long ShipmentCount = (int) collection.count(query);
		System.out.println(ShipmentCount);
		Assert.assertEquals(1, ShipmentCount);
		logger.info("Mispicked Carton Count From DB is " + ShipmentCount);
		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				if ((doc.get("Cartons") != null)) {
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						
						if ((carton.get("Skus") != null)) {
							
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {
								String dbSkuNumber = sku.getString("SkuNumber");
								String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
								String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));					
								String dbSkuDescription = sku.getString("SkuDescription");
								String dbSpecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
										:sku.getString("SpecialHandlingCode");
								
								
								if (dbSkuNumber.equals(skuNumberCreated)) {
									String uiSkuNumber = mispicksScanPage.getSkuNumberFromCartonDetailPage();
									String uiSkuDescription = mispicksScanPage.getSkuDescriptionFromCartonDetailPage();
									String uiShippedSkuQty = mispicksScanPage.getSkuQtyCartonDetailPage();
									String uiReceivedSkuQty = mispicksScanPage.getReceivedSkuQtyCartonDetailPage();
									String uiSpecialHandlingCode = mispicksScanPage.getSpecialHandlingCartonDetailPage();
									logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber
											+ "]");
									logger.info("UI SKU shipped quantity[" + uiShippedSkuQty
											+ "] and DB Shipped quantity[" + dbShippedSkuQty + "]");
									logger.info("UI SKU received quantity[" + uiReceivedSkuQty
											+ "] and DB received quantity[" + dbReceivedSkuQty + "]");
									logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
											+ dbSkuDescription + "]");
									logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
											+ dbSpecialHandling + "]");
									logger.info("DBQuantity " + dbReceivedSkuQty + " UISkuQtyPending " + skuQtyNumber);
									
									softassert.assertEquals(dbSkuNumber, uiSkuNumber);
									softassert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
									softassert.assertEquals(dbReceivedSkuQty, uiShippedSkuQty);
									softassert.assertEquals(dbSkuDescription, uiSkuDescription);
									softassert.assertEquals(dbSpecialHandling, uiSpecialHandlingCode);
									
									softassert.assertEquals(dbReceivedSkuQty, skuQtyNumber);
								}

							}
						}
					}

				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Step("To validate Sku details for Sku which is added to mispicked carton")
	public void getSkuDetailsForMispickedCartonWithMultipleSku(String cartonNumber, String SkuNumber,SoftAssert localAssert,String storeNumber)
			throws ParseException {

		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForMispickedCartonNumber(collection, cartonNumber,storeNumber);
		long CartonCount = (int) collection.count(query);
		System.out.println(CartonCount);
		Assert.assertEquals(1, CartonCount);
		logger.info("Mispicked Carton Count From DB is " + CartonCount);

		if (CartonCount > 0) {
			for (Document doc : collection.find(query)) {
				{
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {

								if (sku.get("ShippedQuantity") != null) {
									String dbSkuNumber = sku.getString("SkuNumber");
									String dbSkuDescription = sku.getString("SkuDescription");
									String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
									String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
									String dbSpecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
											:sku.getString("SpecialHandlingCode");
									

								
										if (SkuNumber.equals(dbSkuNumber)) {
										String uiSkuNumber = mispicksScanPage.getSkuNumberFromCartonDetailPage();
										String uiSkuDescription = mispicksScanPage.getSkuDescriptionFromCartonDetailPage();
										String uiShippedSkuQty = mispicksScanPage.getSkuQtyCartonDetailPage();
										String uiReceivedSkuQty = mispicksScanPage.getReceivedSkuQtyCartonDetailPage();
										String uiSpecialHandlingCode = mispicksScanPage.getSpecialHandlingCartonDetailPage();
										
										localAssert.assertEquals(dbSkuNumber, uiSkuNumber);
										localAssert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
										localAssert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
										localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
										localAssert.assertEquals(dbSpecialHandling, uiSpecialHandlingCode);
										
										logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber + "]");
										logger.info("UI SKU shipped quantity[" + uiShippedSkuQty + "] and DB Shipped quantity["
												+ dbShippedSkuQty + "]");
										logger.info("UI SKU received quantity[" + uiReceivedSkuQty + "] and DB received quantity["
												+ dbReceivedSkuQty + "]");
										logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
												+ dbSkuDescription + "]");
										logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
												+ dbSpecialHandling + "]");
										

										}
									}
								}
							}
						}
					}
				}
			}
		}
	
	// ====================================Purchase
	// order=============================================

	@Step("Validation For Sku Detail in PO")
	public void ValidationForSkuDetailInPO(String purchaseOrderNumber, String POSkuNumber, SoftAssert localAssert,String storeNumber)
			throws ParseException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject query = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrderNumber,storeNumber);
		long purchaseOrderCount = collection.count(query);
		logger.info("Fetched PO count from DB is " + purchaseOrderCount);

		if (purchaseOrderCount > 0) {
			for (Document doc : collection.find(query)) {

				String PONumber = String.valueOf(doc.get("PurchaseOrderNumber"));
				logger.info("Fetched PO is " + PONumber);
				if ((doc.get("SKUs") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
						String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
						String dbSkuDescription = sku.getString("SkuDescription");
						String dbspecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
								:sku.getString("SpecialHandlingCode");
						
						if (dbSkuNumber.equals(POSkuNumber)) {
							String uiSkuNumber = purchaseOrderPage.getSkuNumberOnSkuDetailPage();
							String uiShippedSkuQty = purchaseOrderPage.getSkuShippedQtySkuDetailPage();
							String uiReceivedSkuQty = purchaseOrderPage.getSkuReceivedQtySkuDetailPage();
							String uiSkuDescription = purchaseOrderPage.getSkuDescSkuDetailPage();
							String uiSpecialHandling = purchaseOrderPage.getSpecialHandlingSkuDetailPage();
							if (uiSkuDescription.isEmpty()) {
								uiSkuDescription = null;
							}

							logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber + "]");
							logger.info("UI SKU shipped quantity[" + uiShippedSkuQty + "] and DB Shipped quantity["
									+ dbShippedSkuQty + "]");
							logger.info("UI SKU received quantity[" + uiReceivedSkuQty + "] and DB received quantity["
									+ dbReceivedSkuQty + "]");
							logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
									+ dbSkuDescription + "]");
							logger.info("UI Special Handling[" + uiSpecialHandling + "] and DB Special Handling["
									+ dbspecialHandling + "]");
							localAssert.assertEquals(dbSkuNumber, uiSkuNumber);
							localAssert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
							localAssert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
							localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
							localAssert.assertEquals(dbspecialHandling, uiSpecialHandling);

						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Step("All Excepected Purchase Order")
	public void validateExpectedPurchaseOrder(String storeNumber) throws ParseException {
		
		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryForExpectedPurchaseOrder(collection, storeNumber);
		SoftAssert softAssert = new SoftAssert();

		int expecetdQuantity = 0;
		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {
				int pendingQuantity = 0;
				boolean pendingSkuCount = false;
				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {

						if (sku.get("ShippedQuantity") != null) {
							if (sku.getInteger("ShippedQuantity") != 0) {
								int dbShippedQuantity = sku.getInteger("ShippedQuantity");
								int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
								if (dbReceivedQuantity < dbShippedQuantity) {
									pendingSkuCount = true;
									expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
									pendingQuantity = pendingQuantity + expecetdQuantity;
									// System.out.println("pendingQuantity
									// "+pendingQuantity);
								}
							}
						}
					}
				}
				if (pendingSkuCount == true) {
					String purchaseOrderNumberDB = String.valueOf(doc.get("PurchaseOrderNumber"));
					String vendorNameDB = doc.getString("VendorName");
					String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
					String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
					
					// System.out.println("DB date "+dbETADateTime);
					logger.info("purchaseOrderNumber " + purchaseOrderNumberDB + " vendorName " + vendorNameDB
							+ " pendingQuantity " + pendingQuantity + " dbFormattedETA " + dbFormattedETA);

					purchaseOrderPage.searchForPOFromDB(purchaseOrderNumberDB);
					
					String purchaseOrderNumberOnHomeScreenUI = purchaseOrderPage.getPONumberHomePage();
					String vendorNameOnPOHomeScreenUI = purchaseOrderPage.getVendorNameHomePage();
					String totalSKUQTYHomeScreenUI = purchaseOrderPage.getPendingQuantityHomePage();
					String ETADateHomeScreenUI = purchaseOrderPage.getETAOnHomePage();
					String uiConvertedDate = convertUiDate(ETADateHomeScreenUI);
					logger.info("uiConvertedDate " + uiConvertedDate);
					logger.info("Given PO is available in HomePage as expected");
					
					softAssert.assertEquals(purchaseOrderNumberOnHomeScreenUI, purchaseOrderNumberDB);
					softAssert.assertEquals(vendorNameOnPOHomeScreenUI, vendorNameDB);
					softAssert.assertEquals(totalSKUQTYHomeScreenUI, String.valueOf(pendingQuantity));
					softAssert.assertEquals(uiConvertedDate, dbFormattedETA);
					softAssert.assertAll();
				}
			}
		}
	}

	@Step("Get PurchaseOrder numbers for ETA T-30 from DB and validate not matches in UI-Summary table")
	public void validateOldPurchaseOrderForETALessThan30(String storeNumber) throws ParseException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryForOldPurchaseOrderForETALessThan30(collection, storeNumber);

		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {

				String purchaseOrderNumber = String.valueOf(doc.get("PurchaseOrderNumber"));
				String vendorNameDB = doc.getString("VendorName");
				String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
				String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
				// System.out.println("DB date "+dbETADateTime);
				logger.info("purchaseOrderNumber " + purchaseOrderNumber + " vendorNameDB " + vendorNameDB
						+ " dbFormattedETA " + dbFormattedETA);

				purchaseOrderPage.validatePurchaseOrderNotFound(purchaseOrderNumber);
			}

		} else {
			logger.info("No old purchaseOrder are available");
		}
	}

	@Step("Get PurchaseOrder numbers for ETA T+30 from DB and validate not matches in UI-Summary table")
	public void validateFuturePurchaseOrderForETAGreaterThan30(String storeNumber) throws ParseException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryForFuturePurchaseOrderForETAGreaterThan30days(collection,
				storeNumber);

		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {

				String purchaseOrderNumber = String.valueOf(doc.get("PurchaseOrderNumber"));
				String vendorNameDB = doc.getString("VendorName");
				String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
				String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
				// System.out.println("DB date "+dbETADateTime);
				logger.info("purchaseOrderNumber " + purchaseOrderNumber + " vendorNameDB " + vendorNameDB
						+ " dbFormattedETA " + dbFormattedETA);

				purchaseOrderPage.validatePurchaseOrderNotFound(purchaseOrderNumber);
			}

		} else {
			logger.info("No old purchaseOrder are available");
		}

	}

	@SuppressWarnings("unchecked")
	public void validationForPendingQtyZeroInPO(String storeNumber) throws ParseException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryForExpectedPurchaseOrder(collection, storeNumber);

		int expecetdQuantity = 0;
		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {
				int pendingQuantity = 0;
				boolean pendingSkuCount = false;
				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						if (sku.get("ShippedQuantity") != null) {
							if (sku.getInteger("ShippedQuantity") != 0) {
								int dbShippedQuantity = sku.getInteger("ShippedQuantity");
								int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
								pendingSkuCount = true;
								expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
								pendingQuantity = pendingQuantity + expecetdQuantity;
							}
						}
					}
				}
				if ((pendingSkuCount = true) && (pendingQuantity == 0)) {
					String purchaseOrderNumber = String.valueOf(doc.get("PurchaseOrderNumber"));
					String vendorNameDB = doc.getString("VendorName");
					String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
					String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
					// System.out.println("DB date "+dbETADateTime);
					logger.info("purchaseOrderNumber " + purchaseOrderNumber + " vendorNameDB " + vendorNameDB
							+ " pendingQuantity " + pendingQuantity + " dbFormattedETA " + dbFormattedETA);

					purchaseOrderPage.validatePurchaseOrderNotFound(purchaseOrderNumber);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Step("All Excepected Purchase Order")
	public void validatePurchaseOrderInHomePage(String purchaseOrder,SoftAssert localAssert,String storeNumber) throws ParseException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrder,storeNumber);
		

		int expecetdQuantity = 0;
		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {
				int pendingQuantity = 0;
				boolean pendingSkuCount = false;
				if ((doc.get("SKUs") != null)) {
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {

						if (sku.get("ShippedQuantity") != null) {
							if (sku.getInteger("ShippedQuantity") != 0) {
								int dbShippedQuantity = sku.getInteger("ShippedQuantity");
								int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
								if (dbReceivedQuantity < dbShippedQuantity) {
									pendingSkuCount = true;
									expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
									pendingQuantity = pendingQuantity + expecetdQuantity;
									// System.out.println("pendingQuantity
									// "+pendingQuantity);
								}
							}
						}
					}
				}
				if (pendingSkuCount == true) {
					String purchaseOrderNumberDB = String.valueOf(doc.get("PurchaseOrderNumber"));
					String vendorNameDB = doc.getString("VendorName");
					String dbETADateTime = String.valueOf(doc.get("ETADateTime"));
					String dbFormattedETA = convertToDateTime(dbETADateTime, "MM/dd/yyyy");
					// System.out.println("DB date "+dbETADateTime);
					logger.info("purchaseOrderNumber " + purchaseOrderNumberDB + " vendorName " + vendorNameDB
							+ " pendingQuantity " + pendingQuantity + " dbFormattedETA " + dbFormattedETA);

					purchaseOrderPage.searchForPOFromDB(purchaseOrderNumberDB);

					String purchaseOrderNumberOnHomeScreenUI = purchaseOrderPage.getPONumberHomePage();
					String vendorNameOnPOHomeScreenUI = purchaseOrderPage.getVendorNameHomePage();
					String totalSKUQTYHomeScreenUI = purchaseOrderPage.getPendingQuantityHomePage();
					String ETADateHomeScreenUI = purchaseOrderPage.getETAOnHomePage();
					String uiConvertedDate = convertUiDate(ETADateHomeScreenUI);
					logger.info("uiConvertedDate " + uiConvertedDate);

					localAssert.assertEquals(purchaseOrderNumberOnHomeScreenUI, purchaseOrderNumberDB);
					localAssert.assertEquals(vendorNameOnPOHomeScreenUI, vendorNameDB);
					localAssert.assertEquals(totalSKUQTYHomeScreenUI, String.valueOf(pendingQuantity));
					localAssert.assertEquals(uiConvertedDate, dbFormattedETA);
					
					purchaseOrderPage.validateLabelsInPOHomePage(localAssert);

					String POHeadingInPODetailPage = purchaseOrderPage.validatePODetailPageHeading();
					localAssert.assertEquals(POHeadingInPODetailPage, "PURCHASE ORDERS");
					logger.info("HeadingInPODetailPage " + POHeadingInPODetailPage);
					String headingInReceivingPage = purchaseOrderPage.validateGobackInHomePage();
					localAssert.assertEquals(headingInReceivingPage, "RECEIVING HOME");
					logger.info("HeadingInReceivingPage " + headingInReceivingPage);

				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Step("PurchaseOrder validation in PO Detail Page from DB")
	public void validatePurchaseOrderInDetailPage(String purchaseOrderNumber, String totalSkuPending,String storeNumber) throws ParseException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrderNumber,storeNumber);

		int expecetdQuantity = 0;
		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {
				int pendingQuantity = 0;
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					if (sku.get("ShippedQuantity") != null) {
						if (sku.getInteger("ShippedQuantity") != 0) {
							int dbShippedQuantity = sku.getInteger("ShippedQuantity");
							int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
							if (dbReceivedQuantity < dbShippedQuantity) {
								// pendingSkuCount = true;
								expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
								pendingQuantity = pendingQuantity + expecetdQuantity; // check
																						// with
																						// total
																						// pending
																						// Qty
							}
						}
					}
				}
				logger.info("DBpendingQuantity " + pendingQuantity + " UItotalSkuPending " + totalSkuPending);
				Assert.assertEquals(String.valueOf(pendingQuantity), totalSkuPending);

				ArrayList<MobileElement> skuNumberListOnPODetailPage = purchaseOrderPage
						.getSkuNumberListOnPODetailPage();
				ArrayList<MobileElement> skuQtyListOnPODetailPage = purchaseOrderPage.getSkuQtyListOnPODetailPage();
				logger.info("Size " + skuNumberListOnPODetailPage.size());
				ArrayList<MobileElement> skuReceivedQtyListOnPODetailPage = purchaseOrderPage.getSkuReceivedQtyListOnPODetailPage();

				for (Document sku : skus) {
					if (sku.get("ShippedQuantity") != null) {
						if (sku.getInteger("ShippedQuantity") != 0) {
							String dbSkuNumber = sku.getString("SkuNumber");
							String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
							String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
							logger.info("dbSkuNumber " + dbSkuNumber);

							for (int i = 0; i < skuNumberListOnPODetailPage.size(); i++) {

								String skuValuetmp = skuNumberListOnPODetailPage.get(i).getText().substring(5);
								if (skuValuetmp.equals(dbSkuNumber)) {
									logger.info("Index of SKU ------ " + i);

									String skuNumberOnPODetailPage = skuNumberListOnPODetailPage.get(i).getText()
											.substring(5);
									Assert.assertEquals(skuNumberOnPODetailPage, dbSkuNumber);
									logger.info("dbSkuNumber " + dbSkuNumber + " skuNumberOnPODetailPage "
											+ skuNumberOnPODetailPage);

									String skuExpectedQuantity = skuQtyListOnPODetailPage.get(i).getText().substring(1);
									Assert.assertEquals(skuExpectedQuantity, dbShippedSkuQty);
									logger.info("dbShippedSkuQty " + dbShippedSkuQty + " skuExpectedQuantity "
											+ skuExpectedQuantity);

									String skuReceivedQuantity = skuReceivedQtyListOnPODetailPage.get(i).getText();
									Assert.assertEquals(skuReceivedQuantity, dbReceivedSkuQty);
									logger.info("dbReceivedSkuQty " + dbReceivedSkuQty + " skuReceivedQuantity "
											+ skuReceivedQuantity);
								}
							}

						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Step("PurchaseOrder SKU Detail validation in Print Ticket Page from DB")
	public void validateSKUDetailInPOPrintTicket(String purchaseOrderNumber, SoftAssert localAssert,String storeNumber)
			throws ParseException, ClassNotFoundException, SQLException {

		PurchaseOrderPage purchaseOrderPage = new PurchaseOrderPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		OracleDBConnection oracleDB= new OracleDBConnection();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedpurchaseOrder = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrderNumber,storeNumber);

		long expectedPOCount = collection.count(expectedpurchaseOrder);
		logger.info("Fetched purchaseOrder count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedpurchaseOrder)) {

				List<Document> skus = (List<Document>) doc.get("SKUs");

				ArrayList<MobileElement> skuNumberListOnPrintPage = purchaseOrderPage.getSkuNumberListOnPrintPage();
				ArrayList<MobileElement> skuPrintQtyListOnPrintPage = purchaseOrderPage.getSkuPrintQtyListOnPrintPage();
				ArrayList<MobileElement> skuPrintButtonList = purchaseOrderPage.getSkuPrintButtonListOnPrintPage();
				ArrayList<MobileElement> skuPriceList = purchaseOrderPage.getSkuPriceListOnPrintPage();
				logger.info("Size " + skuNumberListOnPrintPage.size());

				for (Document sku : skus) {
					String dbSkuNumber = sku.getString("SkuNumber");
					String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
					logger.info("dbSkuNumber " + dbSkuNumber);

					for (int i = 0; i < skuNumberListOnPrintPage.size(); i++) {

						String skuNumberOnPrintPage = skuNumberListOnPrintPage.get(i).getText().substring(5);

						if (skuNumberOnPrintPage.equals(dbSkuNumber)) {
							logger.info("Index of SKU ------ " + i);

							localAssert.assertEquals(skuNumberOnPrintPage, dbSkuNumber);
							logger.info("dbSkuNumber " + dbSkuNumber + " skuNumberOnPrintPage " + skuNumberOnPrintPage);

							String skuPrintQuantity = skuPrintQtyListOnPrintPage.get(i).getText();
							localAssert.assertEquals(skuPrintQuantity, dbReceivedSkuQty);
							logger.info(
									"dbReceivedSkuQty " + dbReceivedSkuQty + " skuPrintQuantity " + skuPrintQuantity);
							
							WebElement skuPrintButton = skuPrintButtonList.get(i);
							assertTrue(skuPrintButton.isDisplayed());
							logger.info("Print Button is displayed");
							
							WebElement skuPrice = skuPriceList.get(i);
							assertTrue(skuPrice.isDisplayed());
							logger.info("Sku price is displayed");
							
							String uiSkuPrice=skuPrice.getText().substring(1).replaceAll(",", "");
							Float price=Float.valueOf(uiSkuPrice);
							HashMap<String, String>  skuValueMap=oracleDB.getSkuPriceFromOracleDB(dbSkuNumber,storeNumber);
							String skuPriceDB=skuValueMap.get("skuprice");
							localAssert.assertEquals(String.valueOf(price), skuPriceDB);
							logger.info("Sku Price from UI "+price);
							logger.info("Sku Price from OracleDB "+skuPriceDB);
						}
					}

				}
			}
		}
	}

	// ====================================In-Store
	// Damages=============================================
	public void updateSkuMarkedAsInStoreDamages(String skunumber) throws ParseException {

		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getInStoreDamageCollection();
		BasicDBObject expectedInstoreDamages = mongoDB.queryToGetSkuNumberMarkedAsDamagedToday(collection, skunumber);

		long expectedCount = collection.count(expectedInstoreDamages);
		logger.info("Fetched InStore Damages count from DB is " + expectedCount);

		if (expectedCount > 0) {
			for (Document doc : collection.find(expectedInstoreDamages)) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				String DecreasedDate = getDateDecreaseDay("yyyy-MM-dd", 2);
				Date UpdatedDecreasedDate = format.parse(DecreasedDate);
				logger.info("updated Yesterday date is " + UpdatedDecreasedDate);

				// Change the modified Time To the previous date
				doc.put("ModifiedTime", UpdatedDecreasedDate);
				doc.put("CreatedTime", UpdatedDecreasedDate);
				updateDocInStoreCollection(doc);

			}
		}
	}
	
	public void validateDamagedSkuaddedToInStoreDamagesScreen(String skunumber, SoftAssert localAssert) throws ParseException {

		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getInStoreDamageCollection();
		BasicDBObject expectedInstoreDamages = mongoDB.queryToGetSkuNumberMarkedAsDamagedToday(collection, skunumber);

		long expectedCount = collection.count(expectedInstoreDamages);
		logger.info("Fetched InStore Damages count from DB is " + expectedCount);
		if (expectedCount > 0) {
			for (Document doc : collection.find(expectedInstoreDamages)) {
				String dbSkuNumber = doc.getString("SkuNumber");
				String dbDamagedSkuQty = String.valueOf(doc.getInteger("DamagedQuantity"));
				localAssert.assertEquals(dbSkuNumber, skunumber);
				localAssert.assertEquals(dbDamagedSkuQty, "1");
				logger.info("dbSkuNumber " + dbSkuNumber + " CreatedSkuNumber "
						+ skunumber);
				logger.info("dbDamagedSkuQty " + dbDamagedSkuQty + " DamagedQty "
						+ "1");
				
			}
		}
		
	}
public void validateSkuDetailsForDamageMarkedSku(String skunumber,SoftAssert localAssert) throws ParseException {

		
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getInStoreDamageCollection();
		BasicDBObject expectedInstoreDamages = mongoDB.queryToGetSkuNumberMarkedAsDamagedToday(collection, skunumber);
		AuditingInStoreDamagesScanPage InStoreDamagesPage = new AuditingInStoreDamagesScanPage();
		
		long expectedCount = collection.count(expectedInstoreDamages);
		logger.info("Fetched InStore Damages count from DB is " + expectedCount);

		if (expectedCount > 0) {
			for (Document doc : collection.find(expectedInstoreDamages)) {
				String dbSkuNumber = doc.getString("SkuNumber");
				String dbSkuDescription = doc.getString("SkuDescription");
				String dbDamagedSkuQty = String.valueOf(doc.getInteger("DamagedQuantity"));
				
				String uiSkuNumber =InStoreDamagesPage.captureSkuNumberInDetailPage();
				String uiSkuDescription =InStoreDamagesPage.captureSkuDescriptionInDetailPage();
				String uiDamagedSkuQty =InStoreDamagesPage.captureDamagedSkuQtyInDetailPage();
				
				localAssert.assertEquals(dbSkuNumber, uiSkuNumber);
				localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
				localAssert.assertEquals(dbDamagedSkuQty, uiDamagedSkuQty);
				logger.info("dbSkuNumber " + dbSkuNumber + " DisplayedSkuNumber "
						+ uiSkuNumber);	
				logger.info("dbSkuDescription " + dbSkuDescription + " DisplayedSkuDescription "
						+ uiSkuDescription);			
				logger.info("dbDamagedSkuQty " + dbDamagedSkuQty + " DisplayedDamagedSkuQty "
						+ uiDamagedSkuQty);
				
}
		}
	}
public void validateEditedDamagedQuantityForInStoreDamages(String skunumber,String uiDamagedQty,String skuModifiedTime, String damagedBy,SoftAssert localassert) throws ParseException {

	MongoDBQueryStore mongoDB = new MongoDBQueryStore();
	MongoCollection<Document> collection = MongoDBManager.getInStoreDamageCollection();
	BasicDBObject expectedInstoreDamages = mongoDB.queryToGetSkuNumberMarkedAsDamagedToday(collection, skunumber);
	
	long expectedCount = collection.count(expectedInstoreDamages);
	logger.info("Fetched InStore Damages count from DB is " + expectedCount);

	if (expectedCount > 0) {
		for (Document doc : collection.find(expectedInstoreDamages)) {
			String dbDamagedSkuQty = String.valueOf(doc.getInteger("DamagedQuantity"));
			String dbModifiedBy = doc.getString("ModifiedBy");
			String dbModifiedTime=	String.valueOf(doc.get("ModifiedTime"));				
			String formattedModifiedTime = convertToDateTime(dbModifiedTime, "MM/dd/yyyy HH:mm");
						
					
			localassert.assertEquals(dbDamagedSkuQty, uiDamagedQty);
			localassert.assertEquals(dbModifiedBy, damagedBy);
			localassert.assertEquals(formattedModifiedTime, skuModifiedTime);
							
		    logger.info("dbDamagedSkuQty " + dbDamagedSkuQty + " uiDamagedQty "+ uiDamagedQty);
		    logger.info("dbModifiedBy " + dbModifiedBy + " damagedBy "+ damagedBy);
		    logger.info("dbModifiedTime " + formattedModifiedTime + " skuModifiedTime "+ skuModifiedTime);
						}

					}
				}
					

			
		
	
	


//================================In-Transit damages=========================================


	@SuppressWarnings("unchecked")
	@Step("To validate Sku details for In-Transit Damaged Cartons")
	public void validateSkuDetailsForDamagedCarton(String cartonNumber, SoftAssert softassert,String storeNumber) throws ParseException {
		SoftAssert localAssert = new SoftAssert();
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber,storeNumber);

		long ShipmentCount = collection.count(query);
		logger.info("Shipment count from DB is " + ShipmentCount);

		for (Document doc : collection.find(query)) {
			List<Document> cartons = (List<Document>) doc.get("Cartons");
			for (Document carton : cartons) {
				String dbCarton=carton.getString("CartonNumber");
				//logger.info("Carton Number is "+dbCarton);
				if (dbCarton.equals(cartonNumber)) {
					List<Document> skus = (List<Document>) carton.get("Skus");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
						String dbReceivedSkuQty=String.valueOf(sku.getInteger("ReceivedQuantity"));
						String dbDamagedQty = String.valueOf(sku.getInteger("DamagedQuantity"));
						String dbSkuDescription = sku.getString("SkuDescription");
						String dbspecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
								:sku.getString("SpecialHandlingCode");

						String uiSkuNumber = inTransitDamagePage.getSKUNumberCartonDetailPage();
						String uiSkuDescription = inTransitDamagePage.getSKUDescCartonDetailPage();
						String uiShippedSkuQty = inTransitDamagePage.getSKUQtyCartonDetailPage();
						String uiReceivedSkuQty = inTransitDamagePage.getSkuReceivedQtyCartonDetailPage();
						String uiDamagedQty = inTransitDamagePage.getDamagedSKUQty();
						String uispecialHandling = inTransitDamagePage.getSpecialHandlingCartonDetailPage();
						

						logger.info("Carton Number is "+dbCarton);
						logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber + "]");
						logger.info("UI SKU shipped quantity[" + uiShippedSkuQty + "] and DB Shipped quantity["
								+ dbShippedSkuQty + "]");
						logger.info("UI SKU Received quantity[" + uiReceivedSkuQty + "] and DB Received quantity["
								+ dbReceivedSkuQty + "]");
						logger.info("UI SKU Damaged quantity[" + uiDamagedQty + "] and DB damaged quantity["
								+ dbDamagedQty + "]");
						logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
								+ dbSkuDescription + "]");

						localAssert.assertEquals(dbSkuNumber, uiSkuNumber);
						localAssert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
						localAssert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
						localAssert.assertEquals(dbDamagedQty, uiDamagedQty);
						localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
						localAssert.assertEquals(dbspecialHandling, uispecialHandling);
					}
				}
			}

		}

	}
	
	@SuppressWarnings("unchecked")
	@Step("To validate Sku details for In-Transit Damaged Carton with multiple SKU")
	public void validateSkuDetailsForDamagedCartonWithMultipleSku(String cartonNumber, SoftAssert localAssert,String storeNumber) throws ParseException{
		
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber,storeNumber);

		long ShipmentCount = collection.count(query);
		logger.info("Shipment count from DB is " + ShipmentCount);
		
		ArrayList<MobileElement> skuNumberListOnCartonDetailPage = inTransitDamagePage.getSkuNumberListOnCartonDetailPage();
		ArrayList<MobileElement> skuQtyListOnCartonDetailPage = inTransitDamagePage.getSkuQtyListOnCartonDetailPage();
		ArrayList<MobileElement> receivedQtyListOnCartonDetailPage = inTransitDamagePage.getReceivedQtyListOnCartonDetailPage();
		ArrayList<MobileElement> skuDescriptionListOnCartonDetailPage = inTransitDamagePage.getSkuDescriptionListOnCartonDetailPage();
		ArrayList<MobileElement> damagedQtyListOnCartonDetailPage = inTransitDamagePage.getSkuDamagedQtyListOnCartonDetailPage();
		ArrayList<MobileElement> specialHandlingListOnDetailPage = inTransitDamagePage.getSpecialHandlingListOnCartonDetailPage();
		logger.info("Size " + skuNumberListOnCartonDetailPage.size());
		
		
		for (Document doc : collection.find(query)) {
			List<Document> cartons = (List<Document>) doc.get("Cartons");
			for (Document carton : cartons) {
				String dbCarton=carton.getString("CartonNumber");
				if (dbCarton.equals(cartonNumber)) {
					logger.info("Carton Number is "+dbCarton);
					
					List<Document> skus = (List<Document>) carton.get("Skus");
				    outerloop:
					for (Document sku : skus) {
						boolean checked=false;
						String dbSkuNumber = sku.getString("SkuNumber");
						String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
						String dbReceivedSkuQty=String.valueOf(sku.getInteger("ReceivedQuantity"));
						String dbDamagedQty = String.valueOf(sku.getInteger("DamagedQuantity"));
						String dbSkuDescription = sku.getString("SkuDescription");
						String dbspecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" :sku.getString("SpecialHandlingCode");
						
					
						for (int i = 0; i < skuNumberListOnCartonDetailPage.size(); i++) {
							String skuValuetmp = skuNumberListOnCartonDetailPage.get(i).getText();
							logger.info("dbSkuNumber " + dbSkuNumber); 
							if (skuValuetmp.equals(dbSkuNumber)) {
								checked=true;
								logger.info("Index of SKU ------ " + i);
								

								String skuNumberOnCartonDetailPage = skuNumberListOnCartonDetailPage.get(i).getText();
								localAssert.assertEquals(skuNumberOnCartonDetailPage, dbSkuNumber);
								logger.info("dbSkuNumber " + dbSkuNumber +"  skuNumberOnCartonDetailPage "+ skuNumberOnCartonDetailPage);

								String skuDescriptionOnCartonDetailPage = skuDescriptionListOnCartonDetailPage.get(i).getText();
								localAssert.assertEquals(skuDescriptionOnCartonDetailPage,dbSkuDescription);
								logger.info("dbSkuDescription [" + dbSkuDescription+ "] skuDescriptionOnCartonDetailPage ["
										+ skuDescriptionOnCartonDetailPage+"]");

								String skuQtyOnCartonDetailPage = skuQtyListOnCartonDetailPage.get(i).getText();
								localAssert.assertEquals(skuQtyOnCartonDetailPage, dbShippedSkuQty);
								logger.info("dbShippedQty " + dbShippedSkuQty + " skuQtyOnCartonDetailPage "+ skuQtyOnCartonDetailPage);
								
								String skuReceivedQtyOnCartonDetailPage = receivedQtyListOnCartonDetailPage.get(i).getText();
								localAssert.assertEquals(skuReceivedQtyOnCartonDetailPage,dbReceivedSkuQty );
								logger.info("dbReceivedSkuQty " + dbReceivedSkuQty + " skuReceivedQtyOnCartonDetailPage "+ skuReceivedQtyOnCartonDetailPage);
								
								String damagedQtyOnCartonDetailPage = damagedQtyListOnCartonDetailPage.get(i).getText();
								localAssert.assertEquals(damagedQtyOnCartonDetailPage, dbDamagedQty);
								logger.info("dbDamagedQty " + dbDamagedQty + " damagedQtyOnCartonDetailPage "+damagedQtyOnCartonDetailPage);
								
								int uiReceivedSkuQty = Integer.parseInt(skuReceivedQtyOnCartonDetailPage);
								int uiDamagedSkuQty = Integer.parseInt(damagedQtyOnCartonDetailPage);
								
								boolean value=true; 
								if(uiDamagedSkuQty>uiReceivedSkuQty){
									value=false;
									logger.info("Damaged Quantity is greater than Received quantity");
								}
								localAssert.assertTrue(value);
								localAssert.assertEquals(uiDamagedSkuQty, 0);
								
								/*String specialHandlingDetailPage = specialHandlingListOnDetailPage.get(i).getText();
								localAssert.assertEquals(specialHandlingDetailPage, dbspecialHandling);
								logger.info("dbspecialHandling " + dbspecialHandling + " specialHandlingDetailPage "
										+ specialHandlingDetailPage);*/
							}
						
						}
						
						if(checked=true){
							break outerloop ;
						}
					}
				}
				else{
					logger.info("Carton Number is not found in UI");
				}
			}

		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Step("To validate Sku details for In-Transit Damaged Carton with multiple SKU")
	public void getSkuDetailsForDamagedCartonWithMultipleSku(String cartonNumber, String SkuNumber,SoftAssert localAssert,String storeNumber)
			throws ParseException {

		
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber,storeNumber);

		long ShipmentCount = collection.count(query);
		logger.info("Shipment count from DB is " + ShipmentCount);
		

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				{
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {

								if (sku.get("ShippedQuantity") != null) {
									String dbSkuNumber = sku.getString("SkuNumber");
									String dbSkuDescription = sku.getString("SkuDescription");
									String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
									String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
									String dbDamagedQty = String.valueOf(sku.getInteger("DamagedQuantity"));
									String dbspecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
											:sku.getString("SpecialHandlingCode");
									
									
										if (dbSkuNumber.equals(SkuNumber)) {
											String uiSkuNumber = inTransitDamagePage.getSKUNumberCartonDetailPage();
											String uiSkuDescription = inTransitDamagePage.getSKUDescCartonDetailPage();
											String uiShippedSkuQty = inTransitDamagePage.getSKUQtyCartonDetailPage();
											String uiReceivedSkuQty = inTransitDamagePage.getSkuReceivedQtyCartonDetailPage();
											String uiDamagedQty = inTransitDamagePage.getDamagedSKUQty();
											String uispecialHandling = inTransitDamagePage.getSpecialHandlingCartonDetailPage();
											
										localAssert.assertEquals(dbSkuNumber, uiSkuNumber);
										localAssert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
										localAssert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
										localAssert.assertEquals(dbDamagedQty, uiDamagedQty);
										localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
										localAssert.assertEquals(dbspecialHandling, uispecialHandling);
										
										logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber + "]");
										logger.info("UI SKU shipped quantity[" + uiShippedSkuQty + "] and DB Shipped quantity["
												+ dbShippedSkuQty + "]");
										logger.info("UI SKU received quantity[" + uiReceivedSkuQty + "] and DB received quantity["
												+ dbReceivedSkuQty + "]");
										logger.info("UI SKU Damaged quantity[" + uiDamagedQty + "] and DB damaged quantity["
												+ dbDamagedQty + "]");
										logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
												+ dbSkuDescription + "]");
										logger.info("UI Special Handling[" + uispecialHandling + "] and DB Special Handling["
												+ dbspecialHandling + "]");
										
										int uiReceivedQty = Integer.parseInt(uiReceivedSkuQty);
										int uiDamagedSkuQty = Integer.parseInt(uiDamagedQty);
										
										boolean value=true; 
										if(uiDamagedSkuQty>uiReceivedQty){
											value=false;
											logger.info("Damaged Quantity is greater than Received quantity");
										}
										localAssert.assertTrue(value);
										localAssert.assertEquals(uiDamagedSkuQty, 0);
										

										}
										
									}
								  
								}
							}
						}
					}
				}
			}
		}
	
	public void validateScannedTimeFromDB(String cartonNumber,String scannedTime,String scannedBy,SoftAssert localAssert,String storeNumber) throws ParseException {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber, storeNumber);
		long ShipmentCount = collection.count(query);
		
		logger.info("Carton Count From DB is " + ShipmentCount);

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				List<Document> cartons = (List<Document>) doc.get("Cartons");
				
					for (Document carton : cartons) {
						String dbCarton=carton.getString("CartonNumber");
						if (dbCarton.equals(cartonNumber)) {
							logger.info("Carton Number is "+dbCarton);
							
							Boolean isScannedFlag=carton.getBoolean("IsScanned");
							String cartonScannedTimeDB = String.valueOf(carton.get("ScannedTime"));
							String formattedCartonScannedTime = convertToDateTime(cartonScannedTimeDB, "MM/dd/yyyy HH:mm");
							
							String dbScannedBy = carton.getString("ScannedBy");
//							String lastDocumentUpdate=String.valueOf(doc.get("LastDocumentUpdate"));
//							String formattedlastDocumentUpdateTime = convertToDateTime(lastDocumentUpdate, "MM/dd/yyyy HH:mm");

							
							localAssert.assertTrue(isScannedFlag);
							localAssert.assertEquals(formattedCartonScannedTime,scannedTime );
							localAssert.assertEquals(dbScannedBy, scannedBy);
//							localAssert.assertEquals(formattedlastDocumentUpdateTime,scannedTime );
							
							logger.info("Carton Scanned Flag from DB is " + isScannedFlag);
							logger.info("carton ScannedTime from DB "+formattedCartonScannedTime);
							logger.info("Carton Scanned BY from DB is " + dbScannedBy);
//							logger.info("LastDocumentUpdateTime from DB "+formattedlastDocumentUpdateTime);
					}
				}
			}
		}
	}
	
	public void validateScannedTimeAndReceivedQtyFromDB(String cartonNumber,String scannedTime,String scannedBy,SoftAssert localAssert,String storeNumber) throws ParseException {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber, storeNumber);
		long ShipmentCount = collection.count(query);
		
		logger.info("Carton Count From DB is " + ShipmentCount);

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						String dbCarton=carton.getString("CartonNumber");
						if (dbCarton.equals(cartonNumber)) {
							logger.info("Carton Number is "+dbCarton);
							
							Boolean isScannedFlag=carton.getBoolean("IsScanned");
							String cartonScannedTimeDB = String.valueOf(carton.get("ScannedTime"));
							String formattedCartonScannedTime = convertToDateTime(cartonScannedTimeDB, "MM/dd/yyyy HH:mm");
							
							String dbScannedBy = carton.getString("ScannedBy");
//							String lastDocumentUpdate=String.valueOf(doc.get("LastDocumentUpdate"));
//							String formattedlastDocumentUpdateTime = convertToDateTime(lastDocumentUpdate, "MM/dd/yyyy HH:mm");

							
							localAssert.assertTrue(isScannedFlag);
							localAssert.assertEquals(formattedCartonScannedTime,scannedTime );
							localAssert.assertEquals(dbScannedBy, scannedBy);
//							localAssert.assertEquals(formattedlastDocumentUpdateTime,scannedTime );
						
							logger.info("Validating Scanned Carton");
							logger.info("Carton Scanned Flag from DB is " + isScannedFlag);
							logger.info("carton ScannedTime from DB "+formattedCartonScannedTime);
							logger.info("Carton Scanned BY from DB is " + dbScannedBy);
//							logger.info("LastDocumentUpdateTime from DB "+formattedlastDocumentUpdateTime);
							
							if ((carton.get("Skus") != null)) {
								List<Document> skus = (List<Document>) carton.get("Skus");
								for (Document sku : skus) {

									String dbShippedQty = String.valueOf(sku.getInteger("ShippedQuantity"));
									String dbReceivedQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
									localAssert.assertEquals(dbShippedQty, dbReceivedQty);
									logger.info("shipped quantity from DB is "+dbShippedQty);
									logger.info("Received quantity from DB is "+dbReceivedQty);
									
								}
					}
						}
							
						else{
							
							logger.info("Validating Not Scanned Carton in Shipment");
							Boolean isScannedFlag=carton.getBoolean("IsScanned");
							String cartonScannedTimeDB = String.valueOf(carton.get("ScannedTime"));
							String dbScannedBy = String.valueOf(carton.get("ScannedBy"));
							
							localAssert.assertFalse(isScannedFlag);
							localAssert.assertEquals(cartonScannedTimeDB,"null" );
							localAssert.assertEquals(dbScannedBy,"null" );
							
//							logger.info("Carton Scanned Flag from DB is " + isScannedFlag);
//							logger.info("carton ScannedTime from DB "+cartonScannedTimeDB);
//							logger.info("Carton Scanned BY from DB is " + dbScannedBy);
						}
				}
			}
		}
	}
	
	public void validateScannedTimeBeforeSubmit(String cartonNumber,SoftAssert localAssert,String storeNumber) throws ParseException {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber, storeNumber);
		long ShipmentCount = collection.count(query);
		
		logger.info("Carton Count From DB is " + ShipmentCount);

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						String dbCarton=carton.getString("CartonNumber");
						if (dbCarton.equals(cartonNumber)) {
							logger.info("Carton Number is "+dbCarton);
							
							logger.info("Validate scanned time is null Before submitting carton");
							Boolean isScannedFlag=carton.getBoolean("IsScanned");
							String cartonScannedTimeDB = String.valueOf(carton.get("ScannedTime"));
							String dbScannedBy = String.valueOf(carton.get("ScannedBy"));
							
							localAssert.assertFalse(isScannedFlag);
							localAssert.assertEquals(cartonScannedTimeDB,"null" );
							localAssert.assertEquals(dbScannedBy,"null" );
							
							logger.info("Carton Scanned Flag from DB is " + isScannedFlag);
							logger.info("carton ScannedTime from DB "+cartonScannedTimeDB);
							logger.info("Carton Scanned BY from DB is " + dbScannedBy);
							
				      }
				}
			}
		}
	}
	
	public void validateDamagedQuantityFromDB(String cartonNumber,String uiDamagedQty,String damagedBy,String skuDamagedTime,String CartondamagedTime,SoftAssert localAssert,String storeNumber) throws ParseException {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber, storeNumber);
		long ShipmentCount = collection.count(query);
		
		
		
		logger.info("Damaged Carton Count From DB is " + ShipmentCount);

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				List<Document> cartons = (List<Document>) doc.get("Cartons");
				
					for (Document carton : cartons) {
						String dbCarton=carton.getString("CartonNumber");
						if (dbCarton.equals(cartonNumber)) {
							logger.info("Carton Number is "+dbCarton);
							
							Boolean  isDamagedFlag=carton.getBoolean("IsDamaged");
							localAssert.assertTrue(isDamagedFlag);
							logger.info("Carton Damaged Flag from DB is " + isDamagedFlag);
							
							String cartonDamagedTimeDB = String.valueOf(carton.get("DamagedTime"));
							String formattedCartonDamagedTime = convertToDateTime(cartonDamagedTimeDB, "MM/dd/yyyy HH:mm");
							localAssert.assertEquals(formattedCartonDamagedTime, CartondamagedTime);
							logger.info("carton DamagedTime from DB "+formattedCartonDamagedTime);
							
//							String lastDocumentUpdate=String.valueOf(doc.get("LastDocumentUpdate"));
//							String formattedlastDocumentUpdateTime = convertToDateTime(lastDocumentUpdate, "MM/dd/yyyy HH:mm");
//							localAssert.assertEquals(formattedlastDocumentUpdateTime, skuDamagedTime);
//							logger.info("LastDocumentUpdateTime from DB "+formattedlastDocumentUpdateTime);
							
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {

								String dbDamagedQty = String.valueOf(sku.getInteger("DamagedQuantity"));
								String dbDamagedBy = sku.getString("DamagedBy");
								String skuDamagedTimeDB = String.valueOf(sku.get("DamagedTime"));
								String dbFormattedDamagedTime = convertToDateTime(skuDamagedTimeDB, "MM/dd/yyyy HH:mm");
								Boolean isSkuDamagedFlag=sku.getBoolean("IsDamaged");
								
								
								localAssert.assertEquals(dbDamagedQty, uiDamagedQty);
								localAssert.assertEquals(dbDamagedBy, damagedBy);
								localAssert.assertEquals(dbFormattedDamagedTime, skuDamagedTime);
								localAssert.assertTrue(isSkuDamagedFlag);
								
								logger.info("Damaged Quantity from DB is " + dbDamagedQty);
								logger.info("Damaged By from DB is " + dbDamagedBy);
								logger.info("Sku DamagedTime from DB "+dbFormattedDamagedTime);
								logger.info("SKU Damaged Flag from DB is " + isSkuDamagedFlag);
							}
						}
					}
				}
			}
		}
	}
	
	public void validateDamagedQuantityNotUpdatedInDB(String cartonNumber,SoftAssert localAssert,String storeNumber) throws ParseException{
		
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForDamagedCartonNumber(collection, cartonNumber, storeNumber);
		long ShipmentCount = collection.count(query);
		
		logger.info("Damaged Carton Count From DB is " + ShipmentCount);
		
		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				List<Document> cartons = (List<Document>) doc.get("Cartons");
				
					for (Document carton : cartons) {
						String dbCarton=carton.getString("CartonNumber");
						if (dbCarton.equals(cartonNumber)) {
							logger.info("Carton Number is "+dbCarton);
							
							String cartonDamagedTimeDB = String.valueOf(carton.get("DamagedTime")).isEmpty() ? null 
									: String.valueOf(carton.get("DamagedTime"));
							localAssert.assertEquals(cartonDamagedTimeDB, "null");
							logger.info("carton DamagedTime from DB "+cartonDamagedTimeDB);
							boolean isDamaged=carton.getBoolean("IsDamaged");
							localAssert.assertEquals(isDamaged, false);
							logger.info("Damaged Flag from DB is " + isDamaged);
							
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {

								String dbDamagedQty = String.valueOf(sku.getInteger("DamagedQuantity"));
								String dbDamagedBy = sku.getString("DamagedBy");
								String skuDamagedTimeDB = String.valueOf(sku.get("DamagedTime")).isEmpty() ? null 
										:String.valueOf(sku.get("DamagedTime"));
								
								localAssert.assertEquals(dbDamagedQty, "0");
								localAssert.assertEquals(dbDamagedBy, null);
								localAssert.assertEquals(skuDamagedTimeDB, "null");
								
								logger.info("Damaged Quantity from DB is " + dbDamagedQty);
								logger.info("Damaged By from DB is " + dbDamagedBy);
								logger.info("Sku DamagedTime from DB "+skuDamagedTimeDB);
								
							}
						}
					}
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	@Step("ReceiveTransferOrder validation in  Detail Page from DB")
	public void validateReceiveTransferInDetailPage(String transferNumber, String totalSkuPending,
			SoftAssert localAssert,String storeNumber) throws ParseException {

		ReceivingTransferPage receivingTransferPage = new ReceivingTransferPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedTransfer = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumber, storeNumber);

		int expecetdQuantity = 0;
		long expectedPOCount = collection.count(expectedTransfer);
		logger.info("Fetched Transfer count from DB is " + expectedPOCount);

		if (expectedPOCount > 0) {
			for (Document doc : collection.find(expectedTransfer)) {
				int pendingQuantity = 0;
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					if (sku.get("ShippedQuantity") != null) {
						if (sku.getInteger("ShippedQuantity") != 0) {
							int dbShippedQuantity = sku.getInteger("ShippedQuantity");
							int dbReceivedQuantity = sku.getInteger("ReceivedQuantity");
							if (dbReceivedQuantity < dbShippedQuantity) {
								expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
								pendingQuantity = pendingQuantity + expecetdQuantity; // check
																						// with
																						// total
																						// pending
																						// Qty
							}
						}
					}
				}
				logger.info("DBpendingQuantity " + pendingQuantity + " UItotalSkuPending " + totalSkuPending);
				localAssert.assertEquals(String.valueOf(pendingQuantity), totalSkuPending);

	ArrayList<MobileElement> skuNumberListOnTransferDetailPage =receivingTransferPage.getSkuNumberListOnTransferDetailPage();
				
	List<MobileElement> skuQtyListOnTransferDetailPage =receivingTransferPage.getSkuQtyListOnTransferDetailPage();
	List<MobileElement> skuReceivedQtyListOnTransferDetailPage =receivingTransferPage.getSkuReceivedQtyListOnTransferDetailPage();
				logger.info("Size " + skuNumberListOnTransferDetailPage.size());

				for (Document sku : skus) {
							String dbSkuNumber = sku.getString("SkuNumber");
							String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
							String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
							logger.info("dbSkuNumber " + dbSkuNumber);

							for (int i = 0; i < skuNumberListOnTransferDetailPage.size(); i++) {

								String skuValuetmp = skuNumberListOnTransferDetailPage.get(i).getText().substring(5);
								if (skuValuetmp.equals(dbSkuNumber)) {
									logger.info("Index of SKU ------ " + i);

									String skuNumberOnTransferDetailPage = skuNumberListOnTransferDetailPage.get(i).getText()
											.substring(5);
									localAssert.assertEquals(skuNumberOnTransferDetailPage, dbSkuNumber);
									logger.info("dbSkuNumber " + dbSkuNumber + " skuNumberOnTransferDetailPage "
											+ skuNumberOnTransferDetailPage);

									String skuExpectedQuantity = skuQtyListOnTransferDetailPage.get(i).getText().substring(1);
									localAssert.assertEquals(skuExpectedQuantity, dbShippedSkuQty);
									logger.info("dbShippedSkuQty " + dbShippedSkuQty + " skuExpectedQuantity "
											+ skuExpectedQuantity);

									String skuReceivedQuantity = skuReceivedQtyListOnTransferDetailPage.get(i).getText();
									localAssert.assertEquals(skuReceivedQuantity, dbReceivedSkuQty);
									logger.info("dbReceivedSkuQty " + dbReceivedSkuQty + " skuReceivedQuantity "
											+ skuReceivedQuantity);
								}
							}
				}
			}
		}
	}
	
	
	public String getValidStoreTransferNumberWithMultipleSku(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedTransfer = mongoDB.queryStoreTransfers(collection, storeNumber);
		
		int expecetdQuantity = 0, pendingQuantity = 0;
		String dbTransferNumber=null;
		
		long TransferOrderCount = collection.count(expectedTransfer);
		if (TransferOrderCount > 0) {
			for (Document doc : collection.find(expectedTransfer)) {
				int skucount = 0;
				boolean pendingSkuCount = false;
				String dbSoureStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				@SuppressWarnings("unchecked")
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					int dbShippedQuantity = Integer.parseInt(String.valueOf(sku.get("ShippedQuantity")));
					int dbReceivedQuantity = Integer.parseInt(String.valueOf(sku.get("ReceivedQuantity")));
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					if (dbReceivedQuantity < dbShippedQuantity) {
						pendingSkuCount = true;
						expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
						pendingQuantity = pendingQuantity + expecetdQuantity;
					}
				}
				if (pendingSkuCount == true && skucount>=2) {
					dbTransferNumber = String.valueOf(doc.get("TransferNumber"));
					logger.info("Transfer Number from DB is "+dbTransferNumber);
					logger.info("skucount "+skucount);
					break;
				}
			}

		} else {
			logger.info("No intransit store transfers available");
		}
		return dbTransferNumber;
	}
	
	
	public String getValidStoreTransferNumberWithSingleSku(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedTransfer = mongoDB.queryStoreTransfers(collection, storeNumber);
		
		int expecetdQuantity = 0, pendingQuantity = 0;
		String dbTransferNumber=null;
		
		long TransferOrderCount = collection.count(expectedTransfer);
		if (TransferOrderCount > 0) {
			for (Document doc : collection.find(expectedTransfer)) {
				int skucount = 0;
				boolean pendingSkuCount = false;
				String dbSoureStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				@SuppressWarnings("unchecked")
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					int dbShippedQuantity = Integer.parseInt(String.valueOf(sku.get("ShippedQuantity")));
					int dbReceivedQuantity = Integer.parseInt(String.valueOf(sku.get("ReceivedQuantity")));
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					if (dbReceivedQuantity < dbShippedQuantity) {
						pendingSkuCount = true;
						expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
						pendingQuantity = pendingQuantity + expecetdQuantity;
					}
				}
				if (pendingSkuCount == true && skucount==1) {
					dbTransferNumber = String.valueOf(doc.get("TransferNumber"));
					logger.info("Transfer Number from DB is "+dbTransferNumber);
					logger.info("skucount "+skucount);
					break;
				}
			}

		} else {
			logger.info("No intransit store transfers available");
		}
		return dbTransferNumber;
	}

	//For SRA 582
	public String validatingSkuDetailInReceiveTransferWithMultipleSku(String storeNumber) throws Exception{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedTransfer = mongoDB.queryStoreTransfers(collection, storeNumber);
		ReceivingTransferPage receiveTransfer= new ReceivingTransferPage();
		
		int expecetdQuantity = 0, pendingQuantity = 0;
		String dbTransferNumber=null;
		
		long TransferOrderCount = collection.count(expectedTransfer);
		if (TransferOrderCount > 0) {
			for (Document doc : collection.find(expectedTransfer)) {
				int skucount = 0;
				boolean pendingSkuCount = false;
				String dbSoureStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				@SuppressWarnings("unchecked")
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					int dbShippedQuantity = Integer.parseInt(String.valueOf(sku.get("ShippedQuantity")));
					int dbReceivedQuantity = Integer.parseInt(String.valueOf(sku.get("ReceivedQuantity")));
					if (dbReceivedQuantity < dbShippedQuantity) {
						skucount=skucount+1;
						pendingSkuCount = true;
						expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
						pendingQuantity = pendingQuantity + expecetdQuantity;
					}
				}
				if (pendingSkuCount == true && skucount>=2) {
					dbTransferNumber = String.valueOf(doc.get("TransferNumber"));
					logger.info("Transfer Number from DB is "+dbTransferNumber);
					logger.info("skucount "+skucount);
					
					for (Document sku : skus) {
						int dbShippedQuantity = Integer.parseInt(String.valueOf(sku.get("ShippedQuantity")));
						int dbReceivedQuantity = Integer.parseInt(String.valueOf(sku.get("ReceivedQuantity")));
						String skuNumber=sku.getString("SkuNumber");
						if (dbReceivedQuantity < dbShippedQuantity) {
						receiveTransfer.validatingSkuDetailInReceiveTransfer(dbTransferNumber, skuNumber, String.valueOf(dbShippedQuantity),storeNumber);
						receiveTransfer.editSkuQty(String.valueOf(dbShippedQuantity));
						break;
						}
					}
					
					
				}
				break;
			}

		} else {
			logger.info("No intransit store transfers available");
		}
		return dbTransferNumber;
	}
	
	public String getValidPONumberWithMultipleSku(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedPO = mongoDB.queryPurchaseOrder(collection, storeNumber);
		
		int expecetdQuantity = 0, pendingQuantity = 0;
		String dbPONumber=null;
		
		long POOrderCount = collection.count(expectedPO);
		if (POOrderCount > 0) {
			for (Document doc : collection.find(expectedPO)) {
				int skucount = 0;
				boolean pendingSkuCount = false;
				String dbSoureStoreNumber = String.valueOf(doc.get("SourceStoreNumber"));
				@SuppressWarnings("unchecked")
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					int dbShippedQuantity = Integer.parseInt(String.valueOf(sku.get("ShippedQuantity")));
					int dbReceivedQuantity = Integer.parseInt(String.valueOf(sku.get("ReceivedQuantity")));
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					if (dbReceivedQuantity < dbShippedQuantity) {
						pendingSkuCount = true;
						expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
						pendingQuantity = pendingQuantity + expecetdQuantity;
					}
				}
				if (pendingSkuCount == true && skucount>=2) {
					dbPONumber = String.valueOf(doc.get("PurchaseOrderNumber"));
					logger.info("PurchaseOrder Number from DB is "+dbPONumber);
					logger.info("skucount "+skucount);
					break;
				}
			}

		} else {
			logger.info("No PurchaseOrder is available");
		}
		return dbPONumber;
	}
	
	public String getValidPONumberWithSingleSku(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject expectedPO = mongoDB.queryPurchaseOrder(collection, storeNumber);
		
		int expecetdQuantity = 0, pendingQuantity = 0;
		String dbPONumber=null;
		
		long POOrderCount = collection.count(expectedPO);
		if (POOrderCount > 0) {
			for (Document doc : collection.find(expectedPO)) {
				int skucount = 0;
				boolean pendingSkuCount = false;
				@SuppressWarnings("unchecked")
				List<Document> skus = (List<Document>) doc.get("SKUs");
				for (Document sku : skus) {
					int dbShippedQuantity = Integer.parseInt(String.valueOf(sku.get("ShippedQuantity")));
					int dbReceivedQuantity = Integer.parseInt(String.valueOf(sku.get("ReceivedQuantity")));
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					if (dbReceivedQuantity < dbShippedQuantity) {
						pendingSkuCount = true;
						expecetdQuantity = dbShippedQuantity - dbReceivedQuantity;
						pendingQuantity = pendingQuantity + expecetdQuantity;
					}
				}
				if (pendingSkuCount == true && skucount==1) {
					dbPONumber = String.valueOf(doc.get("PurchaseOrderNumber"));
					logger.info("PurchaseOrder Number from DB is "+dbPONumber);
					logger.info("skucount "+skucount);
					break;
				}
			}

		} else {
			logger.info("No PurchaseOrder is available");
		}
		return dbPONumber;
	}
	
	@Step("To verify Scanned time in DB for PO")
	public void ValidateReceivedQTYAndScannedTimeInPOInDB(String purchaseOrderNumber, String POSkuNumber, String localScannedTime, String receivedQuantity,SoftAssert localAssert,String storeNumber)
			throws ParseException {

		
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject query = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrderNumber,storeNumber);
		long purchaseOrderCount = collection.count(query);
		logger.info("Fetched PO count from DB is " + purchaseOrderCount);

		if (purchaseOrderCount > 0) {
			for (Document doc : collection.find(query)) {

				String PONumber = String.valueOf(doc.get("PurchaseOrderNumber"));
				logger.info("Fetched PO is " + PONumber);
				if ((doc.get("SKUs") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						if (dbSkuNumber.equals(POSkuNumber)) {
						String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
						Boolean dbScannedFlag=sku.getBoolean("IsScanned");
						
						String dbSkuScannedTime = String.valueOf(sku.get("ScannedTime"));
						String formattedSkuScannedTime = convertToDateTime(dbSkuScannedTime, "MM/dd/yyyy HH:mm");
						
						String POUpdatedTime=String.valueOf(doc.get("UpdatedDatetime"));
						String formattedPOUpdateTime = convertToDateTime(POUpdatedTime, "MM/dd/yyyy HH:mm");
						
//						String lastDocUpdatedTime=String.valueOf(doc.get("LastDocumentUpdate"));
//						String formattedlastDocUpdatedTime = convertToDateTime(lastDocUpdatedTime, "MM/dd/yyyy HH:mm");
						
							localAssert.assertEquals(dbSkuNumber, POSkuNumber);
							localAssert.assertTrue(dbScannedFlag);
							localAssert.assertEquals(dbReceivedSkuQty, receivedQuantity);
							localAssert.assertEquals(formattedSkuScannedTime, localScannedTime);
							localAssert.assertEquals(formattedPOUpdateTime, localScannedTime);
//							localAssert.assertEquals(formattedlastDocUpdatedTime, localScannedTime);
							
							logger.info("dbSkuNumber "+dbSkuNumber);
							logger.info("dbReceivedSkuQty "+dbReceivedSkuQty);
							logger.info("dbScannedFlag "+dbScannedFlag);
							logger.info("DBSkuScannedTime "+formattedSkuScannedTime);
							logger.info("DBPOUpdateTime "+formattedPOUpdateTime);
//							logger.info("DBlastDocUpdatedTime "+formattedlastDocUpdatedTime);
							
						}
					}
				}
			}
		}
	}
	
	
	@Step("To verify Scanned time in DB for Transfer")
	public void ValidateReceivedQTYAndScannedTimeInTransferInDB(String transferNumber, String skuNumber, String localScannedTime, String receivedQuantity,SoftAssert localAssert,String storeNumber)
			throws ParseException {

		
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumber,storeNumber);
		long transferCount = collection.count(query);
		logger.info("Fetched Transfer count from DB is " + transferCount);

		if (transferCount > 0) {
			for (Document doc : collection.find(query)) {

				String DBtransferNumber = String.valueOf(doc.get("TransferNumber"));
				logger.info("Fetched TransferNumber from DB is " + DBtransferNumber);
				if ((doc.get("SKUs") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						
						if (dbSkuNumber.equals(skuNumber)) {
						
						
						String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
						Boolean dbScannedFlag=sku.getBoolean("IsScanned");
						
						String dbSkuScannedTime = String.valueOf(sku.get("ScannedTime"));
						String formattedSkuScannedTime = convertToDateTime(dbSkuScannedTime, "MM/dd/yyyy HH:mm");
						
						
						String transferUpdatedTime=String.valueOf(doc.get("UpdatedDatetime"));
						String formattedUpdateTime = convertToDateTime(transferUpdatedTime, "MM/dd/yyyy HH:mm");
						
//						String lastDocUpdatedTime=String.valueOf(doc.get("LastDocumentUpdate"));
//						String formattedlastDocUpdatedTime = convertToDateTime(lastDocUpdatedTime, "MM/dd/yyyy HH:mm");
						
							localAssert.assertEquals(dbSkuNumber, skuNumber);
							localAssert.assertTrue(dbScannedFlag);
							localAssert.assertEquals(dbReceivedSkuQty, receivedQuantity);
							localAssert.assertEquals(formattedSkuScannedTime, localScannedTime);
							localAssert.assertEquals(formattedUpdateTime, localScannedTime);
//							localAssert.assertEquals(formattedlastDocUpdatedTime, localScannedTime);
							
							logger.info("dbSkuNumber "+dbSkuNumber);
							logger.info("dbReceivedSkuQty "+dbReceivedSkuQty);
							logger.info("dbScannedFlag "+dbScannedFlag);
							logger.info("DBSkuScannedTime "+formattedSkuScannedTime);
							logger.info("DBTransferUpdateTime "+formattedUpdateTime);
//							logger.info("DBlastDocUpdatedTime "+formattedlastDocUpdatedTime);
							
						}
					}
				}
			}
		}
	}


	


	
	
	@Step("To verify specialHandlingcode and Time in DB")
	public void ValidateSpecialHandlingAndTimeInPOInDB(String purchaseOrderNumber, String POSkuNumber, String localScannedTime, SoftAssert localAssert,String storeNumber)
			throws ParseException {

		GlobalSearchPage globalSearchPage = new GlobalSearchPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getPurchaseOrderCollection();
		BasicDBObject query = mongoDB.queryToGetPurchaseOrder(collection, purchaseOrderNumber,storeNumber);
		long purchaseOrderCount = collection.count(query);
		logger.info("Fetched PO count from DB is " + purchaseOrderCount);

		if (purchaseOrderCount > 0) {
			for (Document doc : collection.find(query)) {

				String PONumber = String.valueOf(doc.get("PurchaseOrderNumber"));
				logger.info("Fetched PO is " + PONumber);
				if ((doc.get("SKUs") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						
						if (dbSkuNumber.equals(POSkuNumber)) {
						
					    String dbspecialHandling = sku.getString("SpecialHandlingCode");
					    String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
						String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
						String dbSkuDescription = sku.getString("SkuDescription")== null ? ""
								: sku.getString("SkuDescription");
						
						String dbSkuspecialHandlingTime = String.valueOf(sku.get("SpecialHandlingCodeUpdatedDateTime"));
						String formattedSpecialHandlingTime = convertToDateTime(dbSkuspecialHandlingTime, "MM/dd/yyyy HH:mm");
						
//						String lastDocUpdatedTime=String.valueOf(doc.get("LastDocumentUpdate"));
//						String formattedlastDocUpdatedTime = convertToDateTime(lastDocUpdatedTime, "MM/dd/yyyy HH:mm");
//						
						String uiSkuDescription=globalSearchPage.getDescriptionInPOSKU();
					    String uispecialHandling=globalSearchPage.getSpecialHandlingInPOSKU();
					    String uiSkuQty=globalSearchPage.getSkuQuantityInPOSKU();
					    String uiSkuReceivedQty=globalSearchPage.getSkuReceivedQuantityInPOSKU();
						
							localAssert.assertEquals(dbSkuNumber, POSkuNumber);
							localAssert.assertEquals(dbspecialHandling, uispecialHandling);
							localAssert.assertEquals(formattedSpecialHandlingTime, localScannedTime);
							localAssert.assertEquals(dbShippedSkuQty, uiSkuQty);
							localAssert.assertEquals(dbReceivedSkuQty, uiSkuReceivedQty);
							localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
						
//							localAssert.assertEquals(formattedlastDocUpdatedTime, localScannedTime);
							
							logger.info("dbSkuNumber :"+dbSkuNumber);
							logger.info("dbspecialHandling :"+dbspecialHandling);
							logger.info("uispecialHandling :"+uispecialHandling);
							logger.info("dbSkuspecialHandlingTime :"+formattedSpecialHandlingTime);
							
							logger.info("dbShippedSkuQty :"+dbShippedSkuQty);
							logger.info("uiSkuQty :"+uiSkuQty);
							logger.info("dbReceivedSkuQty :"+dbReceivedSkuQty);
							logger.info("uiSkuReceivedQty :"+uiSkuReceivedQty);
							logger.info("dbSkuDescription :"+dbSkuDescription);
							logger.info("uiSkuDescription :"+uiSkuDescription);
//							logger.info("DBlastDocUpdatedTime :"+formattedlastDocUpdatedTime);
							
						}
					}

				}
			}
		}
	}

	@Step("To validate Sku details for Sku which is added to mispicked carton")
	public void getSkuDetailsForScannedCartonMultipleSku(String cartonNumber, SoftAssert assertion,String storeNumber)
			throws ParseException {

		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForScannedCartonNumber(collection, cartonNumber,storeNumber);
		long ShipmentCount = (int) collection.count(query);
		logger.info("Scanned Carton Count From DB is " + ShipmentCount);
		
		ArrayList<MobileElement> skuNumberListOnSkuListPage = receivingShipmentScanPage.getSkuNumberOnSkuListPage();
		logger.info("Size " + skuNumberListOnSkuListPage.size());
		

		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				{
					List<Document> cartons = (List<Document>) ((java.util.List<Document>) doc.get("Cartons"));
					for (Document carton : cartons) {
					String dbCartonNumber = carton.getString("CartonNumber");
					logger.info("dbCartonNumber " + dbCartonNumber);
					if (dbCartonNumber.equals(cartonNumber)) {
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {
									
									String dbSkuNumber = sku.getString("SkuNumber");
									String dbSkuDescription = sku.getString("SkuDescription");
									String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
									String dbDamagedQty = String.valueOf(sku.getInteger("DamagedQuantity"));
									String dbspecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
											:sku.getString("SpecialHandlingCode");
									
									logger.info("dbSkuNumber " + dbSkuNumber);

									for (int i = 0; i < skuNumberListOnSkuListPage.size(); i++) {
										skuNumberListOnSkuListPage = receivingShipmentScanPage.getSkuNumberOnSkuListPage();
										String skuValuetmp = skuNumberListOnSkuListPage.get(i).getText().substring(5);
										
										if (skuValuetmp.equals(dbSkuNumber)) {
											logger.info("Index of SKU ------ " + i);
											skuNumberListOnSkuListPage.get(i).click();
											
											String cartonNumberInDetailPage=receivingShipmentScanPage.getCartonNumberOnCartonDetailScreen().substring(8);
											assertion.assertEquals(cartonNumberInDetailPage, dbCartonNumber);
							
											String uiSkuNumber = receivingShipmentScanPage.getSkuNumberOnCartonDetailScreen();
											String uiSkuDescription = receivingShipmentScanPage.getSKUDescription();
											String uiShippedSkuQty = receivingShipmentScanPage.getSKUQty();
											String uiDamagedSkuQty = receivingShipmentScanPage.damagedSkuQtyOnDetailPage();
											String uiSpecialHandlingCode = receivingShipmentScanPage.getSpecialHandlingDesc();
											
											assertion.assertEquals(dbSkuNumber, uiSkuNumber);
											assertion.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
											assertion.assertEquals(dbDamagedQty, uiDamagedSkuQty);
											assertion.assertEquals(dbSkuDescription, uiSkuDescription);
											assertion.assertEquals(dbspecialHandling, uiSpecialHandlingCode);
											
											logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber+ "]");
											logger.info("UI SKU shipped quantity[" + uiShippedSkuQty
													+ "] and DB Shipped quantity[" + dbShippedSkuQty + "]");
											logger.info("UI SKU Damaged quantity[" + uiDamagedSkuQty
													+ "] and DB Damaged quantity[" + dbDamagedQty + "]");
											logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
													+ dbSkuDescription + "]");
											logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
													+ dbspecialHandling + "]");
											
											receivingShipmentScanPage.clickOnGoBackButtonInDetailPage();

					
										}
									}
							}
						}
					}
					}
				}
				
			}
		}
	}

	
	@Step("To verify specialHandlingcode and Time in DB for storeTransfer")
	public void ValidateSpecialHandlingAndTimeInDBForStoreTransfer(String transferNumber, String skuNumber, String localScannedTime, SoftAssert localAssert,String storeNumber)
			throws ParseException {

		GlobalSearchPage globalSearchPage = new GlobalSearchPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject query = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumber,storeNumber);
		long transferCount = collection.count(query);
		logger.info("Fetched Transfer count from DB is " + transferCount);

		if (transferCount > 0) {
			for (Document doc : collection.find(query)) {

				String DBtransferNumber = String.valueOf(doc.get("TransferNumber"));
				logger.info("Fetched TransferNumber from DB is " + DBtransferNumber);
				if ((doc.get("SKUs") != null)) {
					@SuppressWarnings("unchecked")
					List<Document> skus = (List<Document>) doc.get("SKUs");
					for (Document sku : skus) {
						String dbSkuNumber = sku.getString("SkuNumber");
						
						if (dbSkuNumber.equals(skuNumber)) {
						
					    String dbspecialHandling = sku.getString("SpecialHandlingCode");
					    String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
						String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
						String dbSkuDescription = sku.getString("SkuDescription")== null ? ""
								: sku.getString("SkuDescription");
						
						String dbSkuspecialHandlingTime = String.valueOf(sku.get("SpecialHandlingCodeUpdatedDateTime"));
						String formattedSpecialHandlingTime = convertToDateTime(dbSkuspecialHandlingTime, "MM/dd/yyyy HH:mm");
						
//						String lastDocUpdatedTime=String.valueOf(doc.get("LastDocumentUpdate"));
//						String formattedlastDocUpdatedTime = convertToDateTime(lastDocUpdatedTime, "MM/dd/yyyy HH:mm");
						
						String uiSkuDescription=globalSearchPage.getSkuDescriptionOnTransfer();
					    String uispecialHandling=globalSearchPage.getSpecialHandlingValue();
					    String uiSkuQty=globalSearchPage.getSkuQtyOnTransfer();
					    String uiSkuReceivedQty=globalSearchPage.getReceivedSkuQtyOnTransfer();
						
							localAssert.assertEquals(dbSkuNumber, skuNumber);
							localAssert.assertEquals(dbspecialHandling, uispecialHandling);
							localAssert.assertEquals(formattedSpecialHandlingTime, localScannedTime);
							localAssert.assertEquals(dbShippedSkuQty, uiSkuQty);
							localAssert.assertEquals(dbReceivedSkuQty, uiSkuReceivedQty);
							localAssert.assertEquals(dbSkuDescription, uiSkuDescription);
						
//							localAssert.assertEquals(formattedlastDocUpdatedTime, localScannedTime);
							
							logger.info("dbSkuNumber :"+dbSkuNumber);
							logger.info("dbspecialHandling :"+dbspecialHandling);
							logger.info("uispecialHandling :"+uispecialHandling);
							logger.info("dbSkuspecialHandlingTime :"+formattedSpecialHandlingTime);
							
							logger.info("dbShippedSkuQty :"+dbShippedSkuQty);
							logger.info("uiSkuQty :"+uiSkuQty);
							logger.info("dbReceivedSkuQty :"+dbReceivedSkuQty);
							logger.info("uiSkuReceivedQty :"+uiSkuReceivedQty);
							logger.info("dbSkuDescription :"+dbSkuDescription);
							logger.info("uiSkuDescription :"+uiSkuDescription);
//							logger.info("DBlastDocUpdatedTime :"+formattedlastDocUpdatedTime);
							

						}
					}
				}
			}
		}
	}

	
	public void getSkuDetailsForScannedCartonSingleSku(String cartonNumber, SoftAssert assertion,String storeNumber) throws ParseException {
	
		ReceivingShipmentScanPage receivingShipmentScanPage = new ReceivingShipmentScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForScannedCartonNumber(collection, cartonNumber,storeNumber);
		long ShipmentCount = (int) collection.count(query);
		System.out.println(ShipmentCount);
		Assert.assertEquals(1, ShipmentCount);
		logger.info("Scanned Carton Count From DB is " + ShipmentCount);
		if (ShipmentCount > 0) {
			for (Document doc : collection.find(query)) {
				if ((doc.get("Cartons") != null)) {
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if ((carton.get("Skus") != null)) {
							List<Document> skus = (List<Document>) carton.get("Skus");
							for (Document sku : skus) {
								String dbSkuNumber = sku.getString("SkuNumber");
								String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
								int dbDamagedSkuQty = sku.getInteger("DamagedQuantity") == null ? 0
										:sku.getInteger("DamagedQuantity");					
								String dbSkuDescription = sku.getString("SkuDescription");
								String dbSpecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
										:sku.getString("SpecialHandlingCode");
					
									
									String uiSkuNumber = receivingShipmentScanPage.getSkuNumberOnCartonDetailScreen();
									String uiSkuDescription = receivingShipmentScanPage.getSKUDescription();
									String uiShippedSkuQty = receivingShipmentScanPage.getSKUQty();
									String uiDamagedSkuQty = receivingShipmentScanPage.damagedSkuQtyOnDetailPage();
									String uiSpecialHandlingCode = receivingShipmentScanPage.getSpecialHandlingDesc();
									
									logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber
											+ "]");
									logger.info("UI SKU shipped quantity[" + uiShippedSkuQty
											+ "] and DB Shipped quantity[" + dbShippedSkuQty + "]");
									logger.info("UI SKU Damaged quantity[" + uiDamagedSkuQty
											+ "] and DB Damaged quantity[" + dbDamagedSkuQty + "]");
									logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
											+ dbSkuDescription + "]");
									logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
											+ dbSpecialHandling + "]");

									assertion.assertEquals(dbSkuNumber, uiSkuNumber);
									assertion.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
									assertion.assertEquals(dbDamagedSkuQty, Integer.parseInt(uiDamagedSkuQty));
									assertion.assertEquals(dbSkuDescription, uiSkuDescription);
									assertion.assertEquals(dbSpecialHandling, uiSpecialHandlingCode);
								

							}
						}
						
					
					}
				}
			}
		}
	}

	public void validateDetailsOfCreatedOrphanCarton(String cartonNumber) {
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		BasicDBObject query = mongoDB.queryForOrphanCartonNumber(collection, cartonNumber);
		long OrphanCartonCount = (int) collection.count(query);
		System.out.println(OrphanCartonCount);
		Assert.assertEquals(1, OrphanCartonCount);
		logger.info("Orphan Carton Count From DB is " + OrphanCartonCount);
		
		
	}

	public void validateUpdatedOrphanCartonDetailsFromDB(String orphanCartonNumber, String storeNumber,String updatedDamagedQty, String UpdatedReceivedQty) {
		AuditingInTransitDamagesScanPage inTransitDamagePage = new AuditingInTransitDamagesScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		BasicDBObject query = mongoDB.queryForOrphanCartonNumber(collection, orphanCartonNumber);
		
		long ShipmentCount = (int) collection.count(query);
		System.out.println(ShipmentCount);
		Assert.assertEquals(1, ShipmentCount);
		logger.info("Orphan Carton Count From DB is " + ShipmentCount);
		if (ShipmentCount > 0) {
			
			for (Document doc : collection.find(query)) {
				String dbCartonNumber=doc.getString("CartonNumber");
				Boolean dbIsScanned=doc.getBoolean("IsScanned");
				String dbDestinationStoreNumber=doc.getString("DestinationStoreNumber");
				
				Assert.assertEquals(dbCartonNumber, orphanCartonNumber);
				Assert.assertTrue(dbIsScanned);
				Assert.assertEquals(dbDestinationStoreNumber, storeNumber);
				
				logger.info("UI Carton number[" + orphanCartonNumber + "] and  DB Carton Number[" + dbCartonNumber
						+ "]");
				logger.info("UI Destination number[" + storeNumber + "] and  DB Destination Number[" + dbDestinationStoreNumber
						+ "]");

						if ((doc.get("Skus") != null)) {
							List<Document> skus = (List<Document>) doc.get("Skus");
							for (Document sku : skus) {
								String dbSkuNumber = sku.getString("SkuNumber");
								String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
								String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));
								String dbIsDamaged = String.valueOf(sku.getBoolean("IsDamaged"));
								String dbDamagedSkuQty = String.valueOf(sku.getInteger("DamagedQuantity"));					
								String dbSkuDescription = sku.getString("SkuDescription");
								String dbSpecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
										:sku.getString("SpecialHandlingCode");
					
									
									String uiSkuNumber = inTransitDamagePage.getSKUNumberCartonDetailPage();
									String uiSkuDescription = inTransitDamagePage.getSkuDescriptionCartonDetailPage();
									String uiShippedSkuQty = inTransitDamagePage.getSKUQtyCartonDetailPage();
									String uiReceivedSkuQty = inTransitDamagePage.getReceivedSkuQtyCartonDetailPage();
									String uiDamagedSkuQty = inTransitDamagePage.getDamagedSKUQty();
									String uiSpecialHandlingCode = inTransitDamagePage.getSpecialHandlingCartonDetailPage();
									
									logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber
											+ "]");
									logger.info("UI SKU shipped quantity[" + uiShippedSkuQty
											+ "] and DB Shipped quantity[" + dbShippedSkuQty + "]");
									logger.info("UI SKU Received quantity[" + uiReceivedSkuQty
											+ "] and DB Received quantity[" + dbReceivedSkuQty + "]");
									
									logger.info("UI SKU Damaged quantity[" + uiDamagedSkuQty
											+ "] and DB Damaged quantity[" + dbDamagedSkuQty + "]");
									logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
											+ dbSkuDescription + "]");
									logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
											+ dbSpecialHandling + "]");
									
									Assert.assertEquals(dbSkuNumber, uiSkuNumber);
									Assert.assertEquals(dbIsDamaged, "true");
									Assert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
									Assert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
									Assert.assertEquals(dbReceivedSkuQty, UpdatedReceivedQty);
									Assert.assertEquals(dbDamagedSkuQty, uiDamagedSkuQty);
									Assert.assertEquals(dbDamagedSkuQty, updatedDamagedQty);
									Assert.assertEquals(dbSkuDescription, uiSkuDescription);
									Assert.assertEquals(dbSpecialHandling, uiSpecialHandlingCode);
								

							}
						}
						
					
					}
				}
			}
	@Step("To validate Sku details for Sku which is added to Orphan carton")
	public void getSkuDetailsForOrphanCartonMarkedAsMispicks(String orphanCartonNumber, String storeNumber, String skuNumberCreated, SoftAssert softassert, String editedSkuQty)
			throws ParseException {
		SoftAssert localAssert = new SoftAssert();
		MispicksScanPage mispicksScanPage = new MispicksScanPage();
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		BasicDBObject query = mongoDB.queryForOrphanCartonNumber(collection, orphanCartonNumber);
		long OrphanCartonCount = (int) collection.count(query);
		System.out.println(OrphanCartonCount);
		Assert.assertEquals(1, OrphanCartonCount);
		logger.info("Mispicked Orphan Carton Count From DB is " + OrphanCartonCount);
		if (OrphanCartonCount > 0) {
			
			for (Document doc : collection.find(query)) 
			{
				String dbCartonNumber=doc.getString("CartonNumber");
				Boolean dbIsScanned=doc.getBoolean("IsScanned");
				String dbDestinationStoreNumber=doc.getString("DestinationStoreNumber");
				
				Assert.assertEquals(dbCartonNumber, orphanCartonNumber);
				Assert.assertTrue(dbIsScanned);
				Assert.assertEquals(dbDestinationStoreNumber, storeNumber);
				
				logger.info("UI Carton number[" + orphanCartonNumber + "] and  DB Carton Number[" + dbCartonNumber
						+ "]");
				logger.info("UI Destination number[" + storeNumber + "] and  DB Destination Number[" + dbDestinationStoreNumber
						+ "]");

						if ((doc.get("Skus") != null)) {
							List<Document> skus = (List<Document>) doc.get("Skus");
							for (Document sku : skus) {
								String dbSkuNumber = sku.getString("SkuNumber");
								String dbShippedSkuQty = String.valueOf(sku.getInteger("ShippedQuantity"));
								String dbReceivedSkuQty = String.valueOf(sku.getInteger("ReceivedQuantity"));					
								String dbSkuDescription = sku.getString("SkuDescription");
								String dbSpecialHandling = sku.getString("SpecialHandlingCode") == null ? "None" 
										:sku.getString("SpecialHandlingCode");
								if (dbSkuNumber.equals(skuNumberCreated)) {
									String uiSkuNumber = mispicksScanPage.getSkuNumberFromCartonDetailPage();
									String uiSkuDescription = mispicksScanPage.getSkuDescriptionFromCartonDetailPage();
									String uiShippedSkuQty = mispicksScanPage.getSkuQtyCartonDetailPage();
									String uiReceivedSkuQty = mispicksScanPage.getReceivedSkuQtyCartonDetailPage();
									String uiSpecialHandlingCode = mispicksScanPage.getSpecialHandlingCartonDetailPage();
									logger.info("UI SKU number[" + uiSkuNumber + "] and  DB SKU Number[" + dbSkuNumber
											+ "]");
									logger.info("UI SKU shipped quantity[" + uiShippedSkuQty
											+ "] and DB Shipped quantity[" + dbShippedSkuQty + "]");
									logger.info("UI SKU received quantity[" + uiReceivedSkuQty
											+ "] and DB received quantity[" + dbReceivedSkuQty + "]");
									logger.info("UI SKU description[" + uiSkuDescription + "] and DB SKU Description["
											+ dbSkuDescription + "]");
									logger.info("UI Special Handling[" + uiSpecialHandlingCode + "] and DB Special Handling["
											+ dbSpecialHandling + "]");

									softassert.assertEquals(dbSkuNumber, uiSkuNumber);
									softassert.assertEquals(dbShippedSkuQty, uiShippedSkuQty);
									softassert.assertEquals(dbReceivedSkuQty, editedSkuQty);
									softassert.assertEquals(dbReceivedSkuQty, uiReceivedSkuQty);
									softassert.assertEquals(dbSkuDescription, uiSkuDescription);
									softassert.assertEquals(dbSpecialHandling, uiSpecialHandlingCode);
								}

							}
						}
					}

				}
			}
	
	public String getInTransitCartonNumberWithSingleSku(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryInTransitShipment(collection, storeNumber);
		String dbCartonNumber=null;
		
		
		long  ShipmentCount= collection.count(query);
		if (ShipmentCount > 0) {
			 outerloop:
			for (Document doc : collection.find(query)) {
			List<Document> cartons = (List<Document>) doc.get("Cartons");
			
				for(Document carton : cartons) {
					int skucount = 0;
					Boolean isScannedCarton=carton.getBoolean("IsScanned");
					if (isScannedCarton == false) {		 
				    List<Document> skus = (List<Document>) carton.get("Skus");
					for (Document sku : skus) {
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					
					}
					
					}
				
			       if (skucount==1 && isScannedCarton == false) {
					dbCartonNumber = carton.getString("CartonNumber");
					logger.info("dbCartonNumber " + dbCartonNumber);
					 break outerloop;
			 } 
				}
				
					
			}	
			}
		return dbCartonNumber;
		}

	@Step("To get Received Carton Number")
	public HashMap<String, String> getReceivedCartonNumber(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryReceivedShipment(collection, storeNumber);
		String dbCartonNumber=null;
		HashMap<String, String> map = new HashMap<String, String>();
		int totalShippedQuantity=0;
		
		long  ShipmentCount= collection.count(query);
		if (ShipmentCount > 0) {
			 outerloop:
			for (Document doc : collection.find(query)) {
			List<Document> cartons = (List<Document>) doc.get("Cartons");
			
				for(Document carton : cartons) {
					int skucount = 0;
					Boolean isScannedCarton=carton.getBoolean("IsScanned");
					if (isScannedCarton == true) {		 
				    List<Document> skus = (List<Document>) carton.get("Skus");
					for (Document sku : skus) {
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					}
					}
				
			       if (skucount>=1) {
					dbCartonNumber = carton.getString("CartonNumber");
					logger.info("dbCartonNumber " + dbCartonNumber);
					logger.info("Total skucount is "+skucount);
					map.put("dbCartonNumber", dbCartonNumber);
					map.put("numberOfSku", String.valueOf(skucount));
					
					if ((carton.get("Skus") != null)){
					List<Document> skus = (List<Document>) carton.get("Skus");
					for(Document sku : skus) {
						int skuQuantity=sku.getInteger("ShippedQuantity");
						totalShippedQuantity=skuQuantity+totalShippedQuantity;
					}
					}
					logger.info("Total shipped Quantity is "+totalShippedQuantity);
					map.put("totalShippedQuantity", String.valueOf(totalShippedQuantity));
					
					 break outerloop;
			 } 
				}
					
			}	
			}
		return map;
		}
	
	@Step("To get UnReceived Carton Number")
	public HashMap<String, String> getUnReceivedCartonNumber(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getCollection();
		BasicDBObject query = mongoDB.queryForCartonNumberforInTransitShipment(collection, storeNumber);
		String dbCartonNumber=null;
		HashMap<String, String> map = new HashMap<String, String>();
		int totalShippedQuantity=0;
		
		long  ShipmentCount= collection.count(query);
		if (ShipmentCount > 0) {
			 outerloop:
			for (Document doc : collection.find(query)) {
			List<Document> cartons = (List<Document>) doc.get("Cartons");
			
				for(Document carton : cartons) {
					int skucount = 0;
					Boolean isScannedCarton=carton.getBoolean("IsScanned");
					if (isScannedCarton == false) {		 
				    List<Document> skus = (List<Document>) carton.get("Skus");
					for (Document sku : skus) {
					skucount=skucount+1;
					logger.info("skucount "+skucount);
					}
					}
				
			       if (skucount>1) {
					dbCartonNumber = carton.getString("CartonNumber");
					logger.info("dbCartonNumber " + dbCartonNumber);
					logger.info("Total skucount is "+skucount);
					map.put("dbCartonNumber", dbCartonNumber);
					map.put("numberOfSku", String.valueOf(skucount));
					
					if ((carton.get("Skus") != null)){
					List<Document> skus = (List<Document>) carton.get("Skus");
					for(Document sku : skus) {
						int skuQuantity=sku.getInteger("ShippedQuantity");
						totalShippedQuantity=skuQuantity+totalShippedQuantity;
					}
					}
					logger.info("Total shipped Quantity is "+totalShippedQuantity);
					map.put("totalShippedQuantity", String.valueOf(totalShippedQuantity));
					
					 break outerloop;
			 } 
				}
					
			}	
			}
		return map;
		}
	
	
	@Step("To get Received Orphan Carton Number")
	public HashMap<String, String> getReceivedOrphanCartonNumberWithMultipleSku(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		BasicDBObject query = mongoDB.queryForOrphanCartonNumberForStoreNumber(collection, storeNumber);
		String dbCartonNumber=null;
		HashMap<String, String> map = new HashMap<String, String>();
		int totalReceivedQuantity=0;
		int skucount = 0;
		
		long  ShipmentCount= collection.count(query);
		if (ShipmentCount > 0) {
			 outerloop:
			for (Document doc : collection.find(query)) {
				if ((doc.get("Skus") != null)){
					dbCartonNumber = doc.getString("CartonNumber");
					 skucount = 0;
					 List<Document> skus = (List<Document>) doc.get("Skus");
						for (Document sku : skus) {
						skucount=skucount+1;
						logger.info("skucount "+skucount);
						}
				}
				
			       if (skucount>=1) {
					dbCartonNumber = doc.getString("CartonNumber");
					logger.info("dbCartonNumber " + dbCartonNumber);
					logger.info("Total skucount is "+skucount);
					map.put("dbCartonNumber", dbCartonNumber);
					map.put("numberOfSku", String.valueOf(skucount));
					
					if ((doc.get("Skus") != null)){
					List<Document> skus = (List<Document>) doc.get("Skus");
					for(Document sku : skus) {
						int skuQuantity=sku.getInteger("ReceivedQuantity");
						totalReceivedQuantity=skuQuantity+totalReceivedQuantity;
					}
					}
					logger.info("Total Received Quantity is "+totalReceivedQuantity);
					map.put("totalReceivedQuantity", String.valueOf(totalReceivedQuantity));
					
					 break outerloop;
			 } 
				}
					
			}	
			
		return map;
		}
	
	
	@Step("To get Received Orphan Carton Number with Zero sku Quantity")
	public HashMap<String, String> getReceivedOrphanCartonNumberWithZeroSkuQuantity(String storeNumber) throws ParseException{
		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getOrphanCartonCollection();
		BasicDBObject query = mongoDB.queryForOrphanCartonNumberForStoreNumber(collection, storeNumber);
		String dbCartonNumber=null;
		HashMap<String, String> map = new HashMap<String, String>();
		int totalReceivedQuantity=0;
		int skucount = 0;
		
		long  ShipmentCount= collection.count(query);
		if (ShipmentCount > 0) {
			 outerloop:
			for (Document doc : collection.find(query)) {
				if ((doc.get("Skus")=="[]")){
					dbCartonNumber = doc.getString("CartonNumber");
					 skucount = 0;
					 totalReceivedQuantity=0;
					 logger.info("dbCartonNumber " + dbCartonNumber);
					 logger.info("Total skucount is "+skucount);
						map.put("dbCartonNumber", dbCartonNumber);
						map.put("numberOfSku", String.valueOf(skucount));
						logger.info("Total Received Quantity is "+totalReceivedQuantity);
						map.put("totalReceivedQuantity", String.valueOf(totalReceivedQuantity));
				}
				else{
					logger.info("sku is " +doc.get("Skus"));
				}
				 break outerloop;
				}
					
			}	
			
		return map;
		}
	
	
	
	@Step("Verify Canceled Transfer is not Stored in DB")
	public void validateCanceledTransferInDB(String transferNumber,String storeNumber) throws ParseException {

		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		MongoCollection<Document> collection = MongoDBManager.getStoreToStoreTransferCollection();
		BasicDBObject expectedTransfer = mongoDB.queryForValidatingTheCreatedTransferNumber(collection, transferNumber, storeNumber);

		long expectedPOCount = collection.count(expectedTransfer);
		logger.info("Fetched Transfer count from DB is " + expectedPOCount);
		Assert.assertEquals(expectedPOCount, 0);
		
	}

	
	
}

		

		
	

		
