package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.util.AndroidDriverConfig;
import com.util.BaseUtil;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class PurchaseOrderPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(PurchaseOrderPage.class.getName());
	SoftAssert softassert = new SoftAssert();
	ValidateFromMongoDB mongoDB = new ValidateFromMongoDB();
	protected By specificSku = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU# 3086100']");

	protected By specialHandlingDetail = By.id("com.si:id/liPO_SKUDescDetails_SplHandling");
	protected By POTextBox = By.id("com.si:id/searchViewPO_Home");
	protected By purchaseOrderListOnHome = By.id("com.si:id/liPO_Home_PONo");
	protected By skuNumberListOnPODetailPage = By.id("com.si:id/liPO_SKUDetails_SKUNo");
	protected By buttonToEditSkuQty = By.id("com.si:id/imgPO_SKUDescDetails_Edit");
	protected By inputBtnToEnterSkuQty = By.id("com.si:id/txtPO_SKUEdit_RecQty");
	protected By saveButtonOnSkuQtyEditScreen = By.id("com.si:id/btnPO_SKUEdit_Save");
	protected By alertmessageSkuQtyEditScreen = By.id("com.si:id/lblSKUQtyMessage");
	protected By alertPopupYesSkuQtyEditScreen = By.id("com.si:id/btnPopUpYes");
	protected By alertPopupNoSkuQtyEditScreen = By.id("com.si:id/btnPopUpNo");
	protected By cancelButtonOnSkuQtyEditScreen = By.id("com.si:id/btnPO_SKUEdit_Cancel");
	protected By receivedSkuQtyOnSkuDetailPage = By.id("com.si:id/liPO_SKUDescDetails_RecSKUQty");
	protected By searchBarHomePage = By.id("com.si:id/searchViewPO_Home");
	protected By searchIconHomePage = By.id("com.si:id/imgPO_Home_Search");
	protected By PONumberOnHomePage = By.id("com.si:id/liPO_Home_PONo");
	protected By pendingQtyLabelInPODetailPage = By.id("com.si:id/lblPO_SKUDetails_PendingQty");
	protected By POSummaryInPODetailPage = By.id("com.si:id/btnPO_SKUDetails_POSummary");
	protected By POHeadingInSummaryPage = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Purchase Order Summary']");
	protected By PONumberOnSummaryPage = By.id("com.si:id/lblPO_POSummary_Header");
	protected By continueScanBtnSummaryPage = By.id("com.si:id/btnPO_POSummary_ContinueScan");
	protected By POHomeBtnSummaryPage = By.id("com.si:id/btnPO_POSummary_POHome");
	protected By printTicketsBtnSummaryPage = By.id("com.si:id/btnPO_POSummary_Print");
	protected By expectedSkuQtySummaryPage = By.id("com.si:id/lblPO_POSummary_ExpectedQty");
	protected By receivedSkuQtySummaryPage = By.id("com.si:id/lblPO_POSummary_ReceivedQty");
	protected By shortageSkuQtySummaryPage = By.id("com.si:id/lblPO_POSummary_Shortage");
	protected By scannedSkuQtySummaryPage = By.id("com.si:id/lblPO_POSummary_ToSubmit");
	protected By backBtnOnSkuDetailPage = By.id("com.si:id/btnPO_SKUDescDetails_Back");
	protected By submitBtnPOSummery = By.id("com.si:id/btnPO_POSummary_Submit");
	protected By printTicketHeading = By.id("com.si:id/lblPO_PrintTickets_Header");
	protected By cancelBtnOnPrintScreen = By.id("com.si:id/btnPO_PrintTickets_Back");
	protected By POLabelOnPOSummaryPage = By.id("com.si:id/lblPO_SKUDetails_PONo");
	protected By POHeadingInHomePage = By.id("com.si:id/lblPO_Home_Header");
	protected By successMessageOnPOSummaryPage = By.id("android:id/message");
	protected By okButtonOnPO = By.id("android:id/button1");
	protected By skuNumberSkuDetailPage = By.id("com.si:id/liPO_SKUDescDetails_SKUNumber");
	protected By skuQtySkuDetailPage = By.id("com.si:id/liPO_SKUDescDetails_SKUQty");
	protected By receivedQtySkuDetailPage = By.id("com.si:id/liPO_SKUDescDetails_RecSKUQty");
	protected By specialHandlingSkuDetailPage = By.id("com.si:id/liPO_SKUDescDetails_SplHandling");
	protected By skuDescriptionSkuDetailPage = By.id("com.si:id/liPO_SKUDescDetails_SKUDesc");
	protected By backButtonOnSkuDetailPage = By.id("com.si:id/btnPO_SKUDescDetails_Back");
	protected By PONumberSkuDetailPage = By.id("com.si:id/lblPO_SKUDescDetails_PONo");
	protected By vendorNameHomePage = By.id("com.si:id/liPO_Home_Vendor");
	protected By pendingQuantityHomePage = By.id("com.si:id/liPO_Home_SKUQty");
	protected By ETAOnHomePage = By.id("com.si:id/liPO_Home_ETA");
	protected By POHeadingInStatus = By.id("com.si:id/txtToolbarTitle");
	protected By goBackInPOHome = By.id("com.si:id/btnPO_Home_Back");
	protected By goBackInPODetailPage = By.id("com.si:id/btnPO_SKUDetails_Back");
	protected By skuQtyListOnPODetailPage = By.id("com.si:id/liPO_SKUDetails_SKUQty");
	protected By skuReceivedQtyListOnPODetailPage = By.id("com.si:id/txtPO_SKUDetails_RecQty");
	protected By skuNumberOnPrintPage = By.id("com.si:id/liSTPO_PrintTickets_SKUs");
	protected By skuPriceOnPrintPage = By.id("com.si:id/liSTPO_PrintTickets_Price");
	protected By skuPrintQtyOnPrintPage = By.id("com.si:id/txtPO_PrintTickets_Qty");
	protected By skuPrintButton = By.id("com.si:id/imgBtn_PrintTicket_Print");
	protected By printTicketButton = By.id("com.si:id/btnPO_PrintTickets_Print");
	protected By printTicketPopUpLabel = By.id("com.si:id/Ticketing_lblPopUp_Message");
	protected By printTicketPopUpWithPrice = By.id("com.si:id/Ticketing_PopUp_btnWithPrice");
	protected By printTicketPopUpWithOutPrice = By.id("com.si:id/Ticketing_PopUp_btnWithOutPrice");
	protected By errorMessageInPrint = By.id("android:id/message");
	
	protected By skuLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU QTY']");
	protected By receivedSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Received SKU QTY']");
	protected By specialHandlingLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Special Handling']");
	
	protected By vendorLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='VENDOR']");
	protected By pendingSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='PNDG SKU QTY']");
	protected By etaLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='ETA']");
	
	

	public void clickOnFirstPO() {
		elementClick(purchaseOrderListOnHome);
	}

	public void clickOnFirstSkuNumber() {
		elementClick(skuNumberListOnPODetailPage);
	}

	public void clickOnSKuEditButton() {
		elementClick(buttonToEditSkuQty);
	}

	public void sendTextToEditSkuQty(String skuQty) {
		setText(inputBtnToEnterSkuQty, skuQty);
		clickSearchButton();

	}

	public void clickOnSave() {
		elementClick(saveButtonOnSkuQtyEditScreen);
	}

	public void clickOnAlertMessageYes() {
		elementClick(alertPopupYesSkuQtyEditScreen);
	}

	public void clickOnAlertMessageNo() {
		elementClick(alertPopupNoSkuQtyEditScreen);
	}

	public void clickOnCancelButton() {
		elementClick(cancelButtonOnSkuQtyEditScreen);
	}

	public void clickSearchButton() {

		TouchAction touchAction = new TouchAction(driver);

		touchAction.tap(PointOption.point(700, 1200)).perform();

	}

	public void clickOnSearchIconInHomePage() {
		elementClick(searchIconHomePage);
	}

	public void searchForPurchaseOrder(String purchaseOrder) {

		elementClick(searchBarHomePage);
		setText(searchBarHomePage, purchaseOrder);
		clickOnSearchIconInHomePage();
		fluentWait(PONumberOnHomePage);
	}

	public void clickOnPurchaseOrder() {
		elementClick(PONumberOnHomePage);
	}

	public void clickOnPOSummary() {
		elementClick(POSummaryInPODetailPage);
	}

	public String getPONumberOnPOSummaryPage() {
		return getText(PONumberOnSummaryPage).substring(16);
	}

	public String getExpectedSkusOnPOSummaryPage() {
		return getText(expectedSkuQtySummaryPage);
	}

	public String getReceivedSkusOnPOSummaryPage() {
		return getText(receivedSkuQtySummaryPage);
	}

	public String getShortageOnPOSummaryPage() {
		return getText(shortageSkuQtySummaryPage);
	}

	public String getScannedSkuOnPOSummaryPage() {
		return getText(scannedSkuQtySummaryPage);
	}

	public String getTotalPendingQtyPODetailPage() {
		return getText(pendingQtyLabelInPODetailPage).substring(9);
	}

	public void clickOnBackBtnOnSkuDetailPage() {
		elementClick(backBtnOnSkuDetailPage);
	}
	
	public void clickOnReceivedSkuQuantity() {
		elementClick(skuReceivedQtyListOnPODetailPage);
	}
	
	 public void sendTextToEditReceivedSkuQty(String skuQty) {
			clearTextField(skuReceivedQtyListOnPODetailPage);
			setText(skuReceivedQtyListOnPODetailPage, skuQty);
			clickSearchButton();
		}
	 
	 public void enterPONumberInPOHome(String pONumber) {
			clickOnSearchPO(pONumber);
			clickSearchButton();

		}

		public void clickOnSku() {
			elementClick(specificSku);
		}

		private void clickOnSearchPO(String pONumber) {
			elementClick(POTextBox);
			SetPONumber(pONumber);

		}

		private void SetPONumber(String pONumber) {
			setText(POTextBox, pONumber);

		}
		
		public boolean specialHandlingNotDisplayed() {
			return isDisplayed(specialHandlingDetail);
		}


		public void clickSubmitBtnOnPOSummary() {
			elementClick(submitBtnPOSummery);
		}

		public String getSubmittedMessage() {
			return getText(successMessageOnPOSummaryPage);
		}

		public void clickOnOkButtonAfterSubmit() {
			elementClick(okButtonOnPO);
		}
		

		public void searchForPOFromDB(String purchaseOrder) {

			elementClick(searchBarHomePage);
			clearTextField(searchBarHomePage);
			setText(searchBarHomePage, purchaseOrder);
			clickOnSearchIconInHomePage();
		}

		@Step("Verify PO is not displayed")
		public void verifyPOIsNotDisplayed() {
			assertFalse(isDisplayedWithoutWait(PONumberOnHomePage));
			logger.info("Given PO is not searchable in HomePage as expecetd");
		}


		public ArrayList<MobileElement> getSkuNumberListOnPODetailPage() {
			return (ArrayList<MobileElement>) getListText(skuNumberListOnPODetailPage);
		}

		public ArrayList<MobileElement> getSkuQtyListOnPODetailPage() {
			return (ArrayList<MobileElement>) getListText(skuQtyListOnPODetailPage);
		}
		
		public ArrayList<MobileElement> getSkuReceivedQtyListOnPODetailPage() {
			return (ArrayList<MobileElement>) getListText(skuReceivedQtyListOnPODetailPage);
		}
		
		public String getSpecificSkuReceivedQtyOnPODetailPage() {
			return getText(skuReceivedQtyListOnPODetailPage);
		}

		public String getSkuNumberOnSkuDetailPage() {
			return getText(skuNumberSkuDetailPage);
		}

		public String getSkuShippedQtySkuDetailPage() {
			return getText(skuQtySkuDetailPage);
		}

		public String getSkuReceivedQtySkuDetailPage() {
			return getText(receivedQtySkuDetailPage);
		}

		public String getSpecialHandlingSkuDetailPage() {
			return getText(specialHandlingSkuDetailPage);
		}

		public String getSkuDescSkuDetailPage() {
			return getText(skuDescriptionSkuDetailPage);
		}

		public void clickGoBackOnSkuDetailPage() {
			elementClick(backButtonOnSkuDetailPage);
		}

		public String getPONumberOnSkuDetailPage() {
			return getText(PONumberSkuDetailPage).substring(4);
		}


		public String getPONumberHomePage() {
			return getText(PONumberOnHomePage).substring(16);
		}

		public String getVendorNameHomePage() {
			return getText(vendorNameHomePage);
		}

		public String getPendingQuantityHomePage() {
			return getText(pendingQuantityHomePage);
		}

		public String getETAOnHomePage() {
			return getText(ETAOnHomePage);
		}
		
		

		public void clickOnWithPriceLabel() {
			elementClick(printTicketPopUpWithPrice);
		}

		public void clickOnWithOutPriceLabel() {
			elementClick(printTicketPopUpWithOutPrice);
		}

		public void clickOnOkButton() throws InterruptedException {
			Thread.sleep(2000);
			elementClick(okButtonOnPO);

		}

		public String getErrorMsgInPrint() throws InterruptedException {
			Thread.sleep(2000);
			return getText(errorMessageInPrint);
		}

		public boolean isNoPrinterConnectionMsgDisplayed() throws InterruptedException {
			Thread.sleep(2000);
			return isDisplayedWithoutWait(errorMessageInPrint);
		}

		public void clickOnPrintButton() {
			elementClick(printTicketButton);
		}
		
		

		public List<MobileElement> getSkuNumberSetOnPODetailPage() {
			return getListText(skuNumberListOnPODetailPage);
		}

		public List<MobileElement> getSkuQtySetOnPODetailPage() {
			return getListText(skuQtyListOnPODetailPage);
		}

		public ArrayList<MobileElement> getSkuNumberListOnPrintPage() {
			return (ArrayList<MobileElement>) getListText(skuNumberOnPrintPage);
		}

		public ArrayList<MobileElement> getSkuPrintQtyListOnPrintPage() {
			return (ArrayList<MobileElement>) getListText(skuPrintQtyOnPrintPage);
		}

		public ArrayList<MobileElement> getSkuPrintButtonListOnPrintPage() {
			return (ArrayList<MobileElement>) getListText(skuPrintButton);
		}
		
		public ArrayList<MobileElement> getSkuPriceListOnPrintPage() {
			return (ArrayList<MobileElement>) getListText(skuPriceOnPrintPage);
		}



	public void validateAlertMessageWhenReceivingSkuQtyGreaterThan10(String receivedQty) {
		clickOnFirstPO();
		clickOnFirstSkuNumber();
		logger.info("Received SKU QTY is---- " + receivedQty);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		String alertMessage = getText(alertmessageSkuQtyEditScreen);
		logger.info("Captured alert message------> " + alertMessage);
		assertEquals(alertMessage, "Received SKU QTY exceeds 10. Do you wish to continue?");
		clickOnAlertMessageYes();
		String skuQtyAfterEditing = getText(receivedSkuQtyOnSkuDetailPage);
		assertEquals(skuQtyAfterEditing, receivedQty);
	}

	public void validateSkuQtyNotChangedWhenClickingOnNoButtonInAlertMessage(String receivedQty) {
		String skuReceivedQtyonSkuDetailPage = getText(receivedSkuQtyOnSkuDetailPage);
		logger.info("Received SKU QTY is---- " + receivedQty);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		String alertMessage = getText(alertmessageSkuQtyEditScreen);
		logger.info("Captured alert message------> " + alertMessage);
		assertEquals(alertMessage, "Received SKU QTY exceeds 10. Do you wish to continue?");
		clickOnAlertMessageNo();
		clickOnCancelButton();
		String skuQtyAfterEditing = getText(receivedSkuQtyOnSkuDetailPage);
		assertEquals(skuQtyAfterEditing, skuReceivedQtyonSkuDetailPage);
	}

	public void validateAlterMessageNotDisplayedWhenReceivedQtyIs10(String receivedQty) {
		logger.info("Received SKU QTY is---- " + receivedQty);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		assertFalse(isDisplayedWithoutWait(alertmessageSkuQtyEditScreen));
		logger.info("Alter Message is Not Displayed when Received QTY is 10");

	}

	public void validateAbleToEditReceivedQtyUpTo99(String receivedQty) {

		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		String alertMessage = getText(alertmessageSkuQtyEditScreen);
		logger.info("Captured alert message------> " + alertMessage);
		assertEquals(alertMessage, "Received SKU QTY exceeds 10. Do you wish to continue?");
		clickOnAlertMessageYes();
		String skuQtyAfterEditing = getText(receivedSkuQtyOnSkuDetailPage);
		assertEquals(skuQtyAfterEditing, receivedQty);
		logger.info("Received SKU QTY is---- " + skuQtyAfterEditing);
	}

	public void validateNotAbletoEditReceivedQtyAbove99(String receivedQty) {
		logger.info("Received SKU QTY is---- " + receivedQty);
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		// elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		int sizeOfReceivedQty = getText(inputBtnToEnterSkuQty).length();
		logger.info("Length of received SKU QTY entered------> " + sizeOfReceivedQty);
		assertEquals(2, sizeOfReceivedQty);
		clickOnSave();
		clickOnAlertMessageYes();
	}

	public void validateSpecialHandlingInReceivingPO(String PONumber,String setSpecialHandlingCode, SoftAssert assertion) {
		enterPONumberInPOHome(PONumber);
		clickOnFirstPO();
		clickOnSku();
		validateSpecialHandlingDetailDisplayed( setSpecialHandlingCode, assertion);
	}

	public void validateSpecialHandlingDetailDisplayed( String setSpecialHandlingCode, SoftAssert assertion ) {
		String specialHandlingMsg = getText(specialHandlingDetail);
		assertion.assertEquals(specialHandlingMsg, setSpecialHandlingCode);
		logger.info("Displayed Special Handling message is --> "+specialHandlingMsg);
		

	}

	public void validateSpecialHandlingNotVisible(String PONumber,String setSpecialHandlingCode,SoftAssert assertion ) {
		enterPONumberInPOHome(PONumber);
		clickOnFirstPO();
		clickOnSku();
		validateSpecialHandlingDetailDisplayed( setSpecialHandlingCode, assertion);

	}

	
	public void validateSpecialHandlingDetailNotDisplayed() {

		boolean specialHandling = specialHandlingNotDisplayed();
		Assert.assertEquals(specialHandling, true);
	}

	public void validateSummaryOfPurchaseOrderBeforeScanningSku(String purchaseOrder,String storeNumber) throws ParseException {

		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		String pendingQtyPODetailPage = getTotalPendingQtyPODetailPage();
		clickOnPOSummary();

		String PONumberSummaryPage = getPONumberOnPOSummaryPage();
		System.out.println("PO NumberOnPOSummaryPage " + PONumberSummaryPage);
		softassert.assertEquals(PONumberSummaryPage, purchaseOrder);

		// Validating buttons in transfer summary page
		boolean submitButtonNotfound = isDisplayedWithoutWait(submitBtnPOSummery);
		softassert.assertFalse(submitButtonNotfound);
		boolean isPrintTicketsButtonDisplyed = isDisplayed(printTicketsBtnSummaryPage);
		softassert.assertTrue(isPrintTicketsButtonDisplyed);

		boolean isContinueScanButtonDisplayed = isDisplayed(continueScanBtnSummaryPage);
		softassert.assertTrue(isContinueScanButtonDisplayed);

		boolean isPOHomeButtonDisplayed = isDisplayed(POHomeBtnSummaryPage);
		softassert.assertTrue(isPOHomeButtonDisplayed);

		// Validating Expected, received, scanned and shortage skus in PO
		// summary
		// page
		int shortageSkuQty = new ValidateFromMongoDB().validatePendingSkuQuantityForPurchaseOrder(purchaseOrder, softassert,storeNumber);

		String expectedSkuBeforeScan = getExpectedSkusOnPOSummaryPage();
		softassert.assertEquals(expectedSkuBeforeScan, pendingQtyPODetailPage);

		String receivedSkuBeforeScan = getReceivedSkusOnPOSummaryPage();
		softassert.assertEquals(receivedSkuBeforeScan, "0");

		String shortageBeforeScan = getShortageOnPOSummaryPage();
		softassert.assertEquals(shortageBeforeScan, expectedSkuBeforeScan);

		String scannedSkuBeforeScan = getScannedSkuOnPOSummaryPage();
		softassert.assertEquals(scannedSkuBeforeScan, "0");
		softassert.assertAll();

	}

	public void validateSummaryOfPurchaseOrderAfterScanningSku(String purchaseOrder, String receivedQty,String storeNumber)
			throws ParseException {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		String pendingQtyPODetailPage = getTotalPendingQtyPODetailPage();

		clickOnFirstSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		clickOnBackBtnOnSkuDetailPage();
		clickOnPOSummary();

		String PONumberSummaryPage = getPONumberOnPOSummaryPage();
		softassert.assertEquals(PONumberSummaryPage, purchaseOrder);

		// Validating buttons in transfer summary page
		boolean issubmitButtonDisplayed = isDisplayed(submitBtnPOSummery);
		softassert.assertTrue(issubmitButtonDisplayed);
		boolean isPrintTicketsButtonDisplyed = isDisplayed(printTicketsBtnSummaryPage);
		softassert.assertTrue(isPrintTicketsButtonDisplyed);

		boolean isContinueScanButtonDisplayed = isDisplayed(continueScanBtnSummaryPage);
		softassert.assertTrue(isContinueScanButtonDisplayed);

		boolean isPOHomeButtonDisplayed = isDisplayed(POHomeBtnSummaryPage);
		softassert.assertTrue(isPOHomeButtonDisplayed);

		// Validating Expected, received, scanned and shortage skus in PO
		// summary
		// page
		int shortageSkuQty = new ValidateFromMongoDB().validatePendingSkuQuantityForPurchaseOrder(purchaseOrder, softassert,storeNumber);

		String expectedSkuAfterScan = getExpectedSkusOnPOSummaryPage();
		softassert.assertEquals(expectedSkuAfterScan, pendingQtyPODetailPage);

		String receivedSkuAfterScan = getReceivedSkusOnPOSummaryPage();
		softassert.assertEquals(receivedSkuAfterScan, "0");

		String shortageAfterScan = getShortageOnPOSummaryPage();
		softassert.assertEquals(shortageAfterScan, expectedSkuAfterScan);

		String scannedSkuAfterScan = getScannedSkuOnPOSummaryPage();
		softassert.assertEquals(scannedSkuAfterScan, receivedQty);
		softassert.assertAll();

	}

	public String validateContinueScanningBtnNavigation() {

		elementClick(continueScanBtnSummaryPage);
		String POLabel = getText(POLabelOnPOSummaryPage).substring(0, 2);
		System.out.println(POLabel);
		clickOnPOSummary();
		return POLabel;
	}

	public String validateTransferHomeBtnNavigation() {
		elementClick(POHomeBtnSummaryPage);
		String POHeading = getText(POHeadingInHomePage);
		return POHeading;

	}

	public String validatePrintBtnNavigation() {

		elementClick(printTicketsBtnSummaryPage);
		fluentWait(printTicketHeading);
		String printTicketLabel = getText(printTicketHeading);
		elementClick(cancelBtnOnPrintScreen);
		softassert.assertTrue(isDisplayed(POHeadingInSummaryPage));
		return printTicketLabel;

	}

	public void validateNavigationInPOSummary(String purchaseOrder) {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		clickOnPOSummary();

		boolean isPOHeadingDisplayed = isDisplayed(POHeadingInSummaryPage);
		softassert.assertTrue(isPOHeadingDisplayed);

		String printTicketLabel = validatePrintBtnNavigation();
		softassert.assertEquals(printTicketLabel, "Print Tickets");

		String POLabelOnPODetailPage = validateContinueScanningBtnNavigation();
		softassert.assertEquals(POLabelOnPODetailPage, "PO");

		String POHeadingInPOHomePage = validateTransferHomeBtnNavigation();
		softassert.assertEquals(POHeadingInPOHomePage, "Purchase Orders");

		softassert.assertAll();
	}

	public void validateSummaryOfPurchaseOrderAfterSubmit(String purchaseOrder, String receivedQty,String storeNumber)
			throws ParseException {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();

		clickOnFirstSkuNumber();
		String skuNumber=getText(skuNumberSkuDetailPage);
		
		WebElement skuNo = driver.findElement(By.id("com.si:id/liPO_SKUDescDetails_SKUNumber"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		clickOnBackBtnOnSkuDetailPage();
		clickOnPOSummary();

		String PONumberSummaryPage = getPONumberOnPOSummaryPage();
		softassert.assertEquals(PONumberSummaryPage, purchaseOrder);

		// Validating buttons in transfer summary page
		boolean issubmitButtonDisplayed = isDisplayed(submitBtnPOSummery);
		Assert.assertTrue(issubmitButtonDisplayed);
		boolean isPrintTicketsButtonDisplyed = isDisplayed(printTicketsBtnSummaryPage);
		softassert.assertTrue(isPrintTicketsButtonDisplyed);

		boolean isContinueScanButtonDisplayed = isDisplayed(continueScanBtnSummaryPage);
		softassert.assertTrue(isContinueScanButtonDisplayed);

		boolean isPOHomeButtonDisplayed = isDisplayed(POHomeBtnSummaryPage);
		softassert.assertTrue(isPOHomeButtonDisplayed);

		// Validating Success message on Submitting the skus scanned
		clickSubmitBtnOnPOSummary();
		String SuccessMessage = getSubmittedMessage();
		softassert.assertEquals(SuccessMessage, "Scanned SKUs Submitted Successfully");
		clickOnOkButtonAfterSubmit();

		// Validating Expected, received, scanned and shortage skus in PO
		// summary
		// page
		
		String skuScannedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current ScannedTime is "+skuScannedTime);
		mongoDB.ValidateReceivedQTYAndScannedTimeInPOInDB(purchaseOrder, skuNumber,skuScannedTime,receivedQty,softassert,storeNumber);
		
		int shippedQuantity = mongoDB.validatePendingSkuQuantityForPurchaseOrder(purchaseOrder, softassert,storeNumber);
		System.out.println("shippedQuantity" + shippedQuantity);

		String expectedSkuAfterSubmit = getExpectedSkusOnPOSummaryPage();
		softassert.assertEquals(String.valueOf(shippedQuantity), expectedSkuAfterSubmit);

		String uiReceivedSkuAfterSubmit = getReceivedSkusOnPOSummaryPage();
		softassert.assertEquals(receivedQty, uiReceivedSkuAfterSubmit);

		int uiShortageSku = Integer.parseInt(expectedSkuAfterSubmit) - Integer.parseInt(uiReceivedSkuAfterSubmit);
		String shortageAfterSubmit = getShortageOnPOSummaryPage();
		softassert.assertEquals(String.valueOf(uiShortageSku), shortageAfterSubmit);

		String scannedSkuAfterSubmit = getScannedSkuOnPOSummaryPage();
		softassert.assertEquals(scannedSkuAfterSubmit, "0");
		softassert.assertAll();

	}

	public void editQuantityOfPOForCompletelyReceived(String purchaseOrder, String receivedQty) throws ParseException {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		clickOnFirstSkuNumber();
		WebElement skuNo = driver.findElement(By.id("com.si:id/liPO_SKUDescDetails_SKUNumber"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		clickOnBackBtnOnSkuDetailPage();
		clickOnPOSummary();
		clickSubmitBtnOnPOSummary();
		clickOnOkButtonAfterSubmit();

	}

	public void validateSummaryOfPurchaseOrderAfterSubmitCompletelyReceived(String purchaseOrder)
			throws ParseException {
		searchForPOFromDB(purchaseOrder);
		verifyPOIsNotDisplayed();

	}

	public void validatingSkuDetailInPurchaseOrder(String purchaseOrder, String POSkuNumber,SoftAssert softassert,String storeNumber) throws ParseException {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		ArrayList<MobileElement> skuNumberListOnPODetailPage = getSkuNumberListOnPODetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnPODetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnPODetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(POSkuNumber)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}
		skuNumberListOnPODetailPage.get(index).click();
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(softassert);

		String PONumber = getPONumberOnSkuDetailPage();
		softassert.assertEquals(PONumber, purchaseOrder);

		String skuNumberToReceive = getSkuNumberOnSkuDetailPage();
		softassert.assertEquals(skuNumberToReceive, POSkuNumber);

		String receivedSkuQty = getSkuReceivedQtySkuDetailPage();
		softassert.assertEquals(receivedSkuQty, "0");

		String specialHandling = getSpecialHandlingSkuDetailPage();
		logger.info("specialHandling is " + specialHandling);
		softassert.assertEquals(specialHandling, "None");

		// call DB validation
		mongoDB.ValidationForSkuDetailInPO(purchaseOrder, POSkuNumber, softassert,storeNumber);
		

	}

	private void validateSkuLabel(SoftAssert softassert2) {
		boolean isPOLabelDisplayed = isDisplayed(PONumberSkuDetailPage);
		softassert.assertTrue(isPOLabelDisplayed);
		
		boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
		softassert.assertTrue(isSkuLabelDisplayed);
		
		boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
		softassert.assertTrue(isSkuDescLabelDisplayed);
		
		boolean isSkuQtyLabelDisplayed = isDisplayed(skuQtyLabel);
		softassert.assertTrue(isSkuQtyLabelDisplayed);
		
		boolean isReceivedSkuQtyLabelDisplayed = isDisplayed(receivedSkuQtyLabel);
		softassert.assertTrue(isReceivedSkuQtyLabelDisplayed);
		
		boolean isSpecialHandlingLabelDisplayed = isDisplayed(specialHandlingLabel);
		softassert.assertTrue(isSpecialHandlingLabelDisplayed);
		logger.info("All the sku labels are displayed in the sku detail page");
		
	}

	public void editQuantityInPO(String receivedQty) throws ParseException {
		WebElement skuNo = driver.findElement(By.id("com.si:id/liPO_SKUDescDetails_SKUNumber"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQty);
		clickOnSave();
		clickOnBackBtnOnSkuDetailPage();
		clickOnPOSummary();
		clickSubmitBtnOnPOSummary();
		clickOnOkButtonAfterSubmit();
	}

	public void validatingSkuDetailInPOForCompletelyReceived(String purchaseOrder, String POSkuNumber,
			String receivedQty ,SoftAssert softassert,String storeNumber) throws ParseException {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		ArrayList<MobileElement> skuNumberListOnPODetailPage = getSkuNumberListOnPODetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnPODetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnPODetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(POSkuNumber)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}
		skuNumberListOnPODetailPage.get(index).click();
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(softassert);

		String PONumber = getPONumberOnSkuDetailPage();
		softassert.assertEquals(PONumber, purchaseOrder);

		String skuNumberToReceive = getSkuNumberOnSkuDetailPage();
		softassert.assertEquals(skuNumberToReceive, POSkuNumber);

		String receivedSkuQty = getSkuReceivedQtySkuDetailPage();
		softassert.assertEquals(receivedSkuQty, receivedQty);

		String specialHandling = getSpecialHandlingSkuDetailPage();
		logger.info("specialHandling is " + specialHandling);
		softassert.assertEquals(specialHandling, "None");

		// call DB validation
		mongoDB.ValidationForSkuDetailInPO(purchaseOrder, POSkuNumber, softassert,storeNumber);
		

	}


	public void validatePurchaseOrderNotFound(String purchaseOrder) {
		searchForPOFromDB(purchaseOrder);
		verifyPOIsNotDisplayed();

	}

	public void validatePOHeading(SoftAssert softassert) {
		String POHeadingInPOHomePage = getText(POHeadingInHomePage);
		softassert.assertEquals(POHeadingInPOHomePage, "Purchase Orders");
	}

	public String validatePODetailPageHeading() {
		clickOnFirstPO();
		String POHeadingInPODetailPage = getText(POHeadingInStatus);
		return POHeadingInPODetailPage;
	}

	public String validateGobackInHomePage() {
		elementClick(goBackInPODetailPage);
		fluentWait(goBackInPOHome);
		elementClick(goBackInPOHome);
		String headingInReceivingPage = getText(POHeadingInStatus);
		return headingInReceivingPage;

	}

	@Step("Validating PurchaseOrder details in PO detail Page")
	public void validationInPODetailPageforMultipeSku(String purchaseOrderNumber,String storeNumber) throws ParseException {

		searchForPurchaseOrder(purchaseOrderNumber);
		clickOnPurchaseOrder();

		String PONumberInDetailPage = getText(POLabelOnPOSummaryPage).substring(4);
		Assert.assertEquals(PONumberInDetailPage, purchaseOrderNumber);
		logger.info("PO Number In PO DetailPage " + PONumberInDetailPage);

		String totalPendingSkuQtyLabel = getText(pendingQtyLabelInPODetailPage).substring(0, 8);
		Assert.assertEquals(totalPendingSkuQtyLabel, "PNDG QTY");
		logger.info("TotalPending Sku Quantity Label " + totalPendingSkuQtyLabel);

		String totalPendingQty = getText(pendingQtyLabelInPODetailPage).substring(9);

		// Validation in DB
		mongoDB.validatePurchaseOrderInDetailPage(purchaseOrderNumber, totalPendingQty,storeNumber);

		elementClick(goBackInPODetailPage);
		String POHeadingInPOHomePage = getText(POHeadingInHomePage);
		softassert.assertEquals(POHeadingInPOHomePage, "Purchase Orders");
		logger.info("PO Heading In PO HomePage " + POHeadingInPOHomePage);
		softassert.assertAll();

	}

	public void scrollDown() {
		Dimension dimension = AndroidDriverConfig.getAndroidDriver().manage().window().getSize();
		Double scrollHeightStart = dimension.getHeight() * 0.5;
		int scrollstart = scrollHeightStart.intValue();

		Double scrollHeightEnd = dimension.getHeight() * 0.2;
		int scrollEnd = scrollHeightEnd.intValue();

		new TouchAction((PerformsTouchActions) AndroidDriverConfig.getAndroidDriver())
				.press(PointOption.point(0, scrollstart)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
				.moveTo(PointOption.point(0, scrollEnd)).release().perform();
	}

	@Step("Validating Edit funtionality in PO")
	public void validateTotalPendingQTYInPOAfterQuantityEdit(String purchaseOrderNumber, String skuNumber,
			String receivedQuantity,String storeNumber) throws ParseException {

		searchForPurchaseOrder(purchaseOrderNumber);
		clickOnPurchaseOrder();

		String totalPendingQtyBeforeEdit = getText(pendingQtyLabelInPODetailPage).substring(9);
		logger.info("Pending QTY Before Scanning is " + totalPendingQtyBeforeEdit);

		ArrayList<MobileElement> skuNumberListOnPODetailPage = getSkuNumberListOnPODetailPage();
		ArrayList<MobileElement> skuReceivedQtyListOnPODetailPage = getSkuReceivedQtyListOnPODetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnPODetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnPODetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(skuNumber)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}

		String receviedQtyBeforeEdit = skuReceivedQtyListOnPODetailPage.get(index).getText();
		logger.info("Received QTY Before Scanning is " + receviedQtyBeforeEdit);
		skuNumberListOnPODetailPage.get(index).click();

		String skuQtyBeforeEditing = getText(receivedSkuQtyOnSkuDetailPage);

		WebElement skuNo = driver.findElement(By.id("com.si:id/liPO_SKUDescDetails_SKUNumber"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQuantity);
		clickOnSave();
		String skuQtyAfterEditing = getText(receivedSkuQtyOnSkuDetailPage);
		softassert.assertEquals(skuQtyAfterEditing, receivedQuantity);
		softassert.assertNotEquals(skuQtyBeforeEditing, skuQtyAfterEditing);
		elementClick(backBtnOnSkuDetailPage);

		String totalPendingQtyAfterEdit = getText(pendingQtyLabelInPODetailPage).substring(9);
		logger.info("Pending QTY After Scanning is " + totalPendingQtyAfterEdit);

		int newTotalpendingQtyAfterEdit = Integer.parseInt(totalPendingQtyBeforeEdit)
				- Integer.parseInt(receivedQuantity);
		softassert.assertEquals(totalPendingQtyAfterEdit, String.valueOf(newTotalpendingQtyAfterEdit));

		skuReceivedQtyListOnPODetailPage = getSkuReceivedQtyListOnPODetailPage();
		String receviedQtyAfterEdit = skuReceivedQtyListOnPODetailPage.get(index).getText();
		logger.info("Received QTY After Scanning is " + receviedQtyAfterEdit);
		softassert.assertEquals(receviedQtyAfterEdit, receivedQuantity);

		clickOnPOSummary();
		clickSubmitBtnOnPOSummary();
		clickOnOkButtonAfterSubmit();
		
		String skuScannedTime =BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current ScannedTime is "+skuScannedTime);
		mongoDB.ValidateReceivedQTYAndScannedTimeInPOInDB(purchaseOrderNumber, skuNumber,skuScannedTime,receivedQuantity, softassert,storeNumber);
		
		elementClick(POHomeBtnSummaryPage);
		searchForPurchaseOrder(purchaseOrderNumber);
	    String pendingQtyHomePage=getPendingQuantityHomePage();
	    softassert.assertEquals(totalPendingQtyAfterEdit,pendingQtyHomePage);
	    logger.info("Pending QTY in HomePage is " + pendingQtyHomePage);
		softassert.assertAll();

	}

	public String editCountOfPendingQuantitywithoutsubmit(String purchaseOrderNumber, String skuNumber,
			String receivedQuantity) {
		searchForPurchaseOrder(purchaseOrderNumber);
		clickOnPurchaseOrder();

		ArrayList<MobileElement> skuNumberListOnPODetailPage = getSkuNumberListOnPODetailPage();
//		ArrayList<MobileElement> skuQtyListOnPODetailPage = getSkuQtyListOnPODetailPage();
		ArrayList<MobileElement> skuReceivedQtyListOnPODetailPage = getSkuReceivedQtyListOnPODetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnPODetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnPODetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(skuNumber)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}
		skuNumberListOnPODetailPage.get(index).click();

		WebElement skuNo = driver.findElement(By.id("com.si:id/liPO_SKUDescDetails_SKUNumber"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQuantity);
		clickOnSave();
		elementClick(backBtnOnSkuDetailPage);

		logger.info("Index of SKU ------ " + index);

		skuReceivedQtyListOnPODetailPage = getSkuReceivedQtyListOnPODetailPage();
		String receviedQtyBeforeLogout = skuReceivedQtyListOnPODetailPage.get(index).getText();

		return receviedQtyBeforeLogout;
	}

	public void validateCountOfPendingQuantityAfterLogout(String purchaseOrderNumber,
			String totalPendingQtyBeforeLogout, String receviedQtyBeforeLogout, String skuNumber) throws ParseException {

		searchForPurchaseOrder(purchaseOrderNumber);
		clickOnPurchaseOrder();

		ArrayList<MobileElement> skuNumberListOnPODetailPage = getSkuNumberListOnPODetailPage();
		//ArrayList<MobileElement> skuQtyListOnPODetailPage = getSkuQtyListOnPODetailPage();
		ArrayList<MobileElement> skuReceivedQtyListOnPODetailPage = getSkuReceivedQtyListOnPODetailPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnPODetailPage.size(); i++) {
			String skuValuetmp = skuNumberListOnPODetailPage.get(i).getText().substring(5);
			if (skuValuetmp.equals(skuNumber)) {
				index = i;
				logger.info("Index of SKU ------ " + index);
			}
		}

		String totalPendingQtyAfterLogout = getTotalPendingQtyPODetailPage();
		String receviedQtyAfterLogout = skuReceivedQtyListOnPODetailPage.get(index).getText();
		logger.info("Pending QTY After Logout is " + totalPendingQtyAfterLogout);
		logger.info("Received QTY After Logout is " + receviedQtyAfterLogout);

		softassert.assertEquals(totalPendingQtyBeforeLogout, totalPendingQtyAfterLogout);
		softassert.assertEquals(receviedQtyBeforeLogout, receviedQtyAfterLogout);

		clickOnPOSummary();
		clickSubmitBtnOnPOSummary();
		clickOnOkButtonAfterSubmit();
		softassert.assertAll();
	}

	public void validateSkuQuantityInPrintTicketPage(String purchaseOrder,SoftAssert softassert,String storeNumber) throws ParseException, ClassNotFoundException, SQLException {
		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		clickOnPOSummary();

		String printTicketLabel = validatePrintBtnNavigation();
		softassert.assertEquals(printTicketLabel, "Print Tickets");

		elementClick(printTicketsBtnSummaryPage);
		fluentWait(printTicketHeading);
		mongoDB.validateSKUDetailInPOPrintTicket(purchaseOrder, softassert,storeNumber);


	}

	@SuppressWarnings("rawtypes")
	public void validateSkuQuantityEditInPrintTicketPage(String purchaseOrder, String printQuantity,SoftAssert softassert) {

		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		clickOnPOSummary();
		elementClick(printTicketsBtnSummaryPage);
		fluentWait(printTicketHeading);

		ArrayList<MobileElement> skuPrintQtyListOnPrintPage = getSkuPrintQtyListOnPrintPage();

		ArrayList<MobileElement> skuPrintButtonList = getSkuPrintButtonListOnPrintPage();

		for (int i = 0; i < skuPrintQtyListOnPrintPage.size(); i++) {

			WebElement printQty = skuPrintQtyListOnPrintPage.get(i);
			printQty.click();
			printQty.clear();
			printQty.sendKeys(printQuantity);
			String QtyAfterEdit = printQty.getText();
			logger.info("PrintQty after edit " + QtyAfterEdit);
			softassert.assertEquals(printQuantity, QtyAfterEdit);

			WebElement skuPrintButton = skuPrintButtonList.get(i);
			assertTrue(skuPrintButton.isDisplayed());
			skuPrintButton.click();

			boolean isLabelDisplayed = isDisplayed(printTicketPopUpLabel);
			softassert.assertTrue(isLabelDisplayed);

			boolean isWithPriceLabelDisplayed = isDisplayed(printTicketPopUpWithPrice);
			softassert.assertTrue(isWithPriceLabelDisplayed);

			boolean isWithOutPriceLabelDisplayed = isDisplayed(printTicketPopUpWithOutPrice);
			softassert.assertTrue(isWithOutPriceLabelDisplayed);

			TouchAction touchAction = new TouchAction(driver);
			touchAction.tap(PointOption.point(550, 250)).perform();

		}

	}

	public void validateNotAbletoPrintQtyAbove99(String printQuantity,SoftAssert softassert) {

		ArrayList<MobileElement> skuPrintQtyListOnPrintPage = getSkuPrintQtyListOnPrintPage();

		for (int i = 0; i < skuPrintQtyListOnPrintPage.size(); i++) {

			WebElement printQty = skuPrintQtyListOnPrintPage.get(i);
			printQty.click();
			printQty.clear();
			printQty.sendKeys(printQuantity);
			int sizeOfReceivedQty = printQty.getText().length();
			logger.info("Length of Print SKU QTY entered------> " + sizeOfReceivedQty);
			softassert.assertEquals(2, sizeOfReceivedQty);

		}
	}
	
	
	
	public void validateNotAbleToPrintZeroQuantity(String printQuantity,SoftAssert softassert) throws InterruptedException{
		
		ArrayList<MobileElement> skuPrintQtyListOnPrintPage = getSkuPrintQtyListOnPrintPage();
		ArrayList<MobileElement> skuPrintButtonList = getSkuPrintButtonListOnPrintPage();
		
		for (int i = 0; i < skuPrintQtyListOnPrintPage.size(); i++) {
			
			skuPrintQtyListOnPrintPage = getSkuPrintQtyListOnPrintPage();
		    skuPrintButtonList = getSkuPrintButtonListOnPrintPage();
			
			WebElement printQty = skuPrintQtyListOnPrintPage.get(i);
			printQty.click();
			printQty.clear();
			printQty.sendKeys(printQuantity);
			String QtyAfterEdit = printQty.getText();
			logger.info("PrintQty after edit " + QtyAfterEdit);
			
			WebElement skuPrintButton = skuPrintButtonList.get(i);
			assertTrue(skuPrintButton.isDisplayed());
			skuPrintButton.click();
			
			String errorMessage=getText(errorMessageInPrint);
			softassert.assertEquals(errorMessage, "Please enter valid SKU Quantity");
			elementClick(okButtonOnPO);
		}
		
		clickOnPrintButton();
		String errorMessage=getErrorMsgInPrint();
		softassert.assertEquals(errorMessage, "Please enter valid SKU Quantity");
		clickOnOkButton();
		

		for (int i = 0; i < 1; i++) {
			skuPrintQtyListOnPrintPage = getSkuPrintQtyListOnPrintPage();

			WebElement printQty = skuPrintQtyListOnPrintPage.get(i);
			printQty.click();
			printQty.clear();
			printQty.sendKeys("2");
			String QtyAfterEdit = printQty.getText();
			logger.info("PrintQty after edit " + QtyAfterEdit);
		}
		
		TouchAction touchAction = new TouchAction(driver);
		touchAction.tap(PointOption.point(550, 250)).perform();
		
		clickOnPrintButton();

		String printLabel = getText(printTicketPopUpLabel);
		softassert.assertEquals(printLabel, "Print Ticket");
		
		boolean isWithPriceLabelDisplayed = isDisplayed(printTicketPopUpWithPrice);
		softassert.assertTrue(isWithPriceLabelDisplayed);

		boolean isWithOutPriceLabelDisplayed = isDisplayed(printTicketPopUpWithOutPrice);
		softassert.assertTrue(isWithOutPriceLabelDisplayed);

		touchAction.tap(PointOption.point(550, 250)).perform();
		
	}

	public void validatePrintButtonInPOPrintPage(String purchaseOrder,SoftAssert softassert) throws InterruptedException {

		searchForPurchaseOrder(purchaseOrder);
		clickOnPurchaseOrder();
		clickOnPOSummary();
		elementClick(printTicketsBtnSummaryPage);
		fluentWait(printTicketHeading);

		elementClick(skuPrintButton);
		String printLabel = getText(printTicketPopUpLabel);
		softassert.assertEquals(printLabel, "Print Ticket");

		clickOnWithPriceLabel();

		boolean errorMessage = isNoPrinterConnectionMsgDisplayed();
		softassert.assertTrue(errorMessage);
		clickOnOkButton();

//		boolean noPrinterConnectionMsg = isNoPrinterConnectionMsgDisplayed();
//		softassert.assertTrue(noPrinterConnectionMsg);
//		clickOnOkButton();

		elementClick(skuPrintButton);
		clickOnWithOutPriceLabel();

		boolean errorMessageWithOutPrice = isNoPrinterConnectionMsgDisplayed();
		softassert.assertTrue(errorMessageWithOutPrice);
		clickOnOkButton();

//		boolean NoPrinterErrorMessageWithOutPrice = isNoPrinterConnectionMsgDisplayed();
//		softassert.assertTrue(NoPrinterErrorMessageWithOutPrice);
//		clickOnOkButton();

		validatePrintButtonAtBottom(softassert);

	}

	public void validatePrintButtonAtBottom(SoftAssert softassert) throws InterruptedException {
		clickOnPrintButton();

		String printLabel = getText(printTicketPopUpLabel);
		softassert.assertEquals(printLabel, "Print Ticket");

		clickOnWithPriceLabel();

		// String errorMessage=getErrorMsgInPrint();
		// softassert.assertEquals(errorMessage, "Printer connection error.
		// Please check that printer is online and able to be connected.");
		// clickOnOkButton();
		//
		// String NoPrinterErrorMessage=getErrorMsgInPrint();
		// softassert.assertEquals(NoPrinterErrorMessage, "Error. No printer
		// connection established.");
		// clickOnOkButton();

		boolean errorMessage = isNoPrinterConnectionMsgDisplayed();
		softassert.assertTrue(errorMessage);
		clickOnOkButton();

//		boolean noPrinterConnectionMsg = isNoPrinterConnectionMsgDisplayed();
//		softassert.assertTrue(noPrinterConnectionMsg);
//		clickOnOkButton();

		clickOnPrintButton();
		clickOnWithOutPriceLabel();

		boolean errorMessageWithOutPrice = isNoPrinterConnectionMsgDisplayed();
		softassert.assertTrue(errorMessageWithOutPrice);
		clickOnOkButton();

//		boolean NoPrinterErrorMessageWithOutPrice = isNoPrinterConnectionMsgDisplayed();
//		softassert.assertTrue(NoPrinterErrorMessageWithOutPrice);
//		clickOnOkButton();

		// String errorMessageWithOutPrice=getErrorMsgInPrint();
		// softassert.assertEquals(errorMessageWithOutPrice, "Printer connection
		// error. Please check that printer is online and able to be
		// connected.");
		// clickOnOkButton();
		//
		//
		// String NoPrinterErrorMessageWithOutPrice=getErrorMsgInPrint();
		// softassert.assertEquals(NoPrinterErrorMessageWithOutPrice, "Error. No
		// printer connection established.");
		// clickOnOkButton();

		softassert.assertAll();

	}
	
	public void scrollInHomePage(){
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
		 String isScrollable=element.getAttribute("scrollable");
         logger.info("Scrollable flag for PO HOMEPAGE is :"+isScrollable);
         assertEquals(isScrollable, "true");
         
         List<MobileElement> poNumberList=driver.findElementsById("com.si:id/liPO_Home_PONo");
         
         boolean isScrolled= scrollDownByElement(poNumberList);
         assertTrue(isScrolled);
	}
	
	public void scrollInPODetailPage(String purchaseOrderNumber){
		searchForPurchaseOrder(purchaseOrderNumber);
		clickOnPurchaseOrder();
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
		 String isScrollable=element.getAttribute("scrollable");
        logger.info("Scrollable flag for PO DetailPage is :"+isScrollable);
        assertEquals(isScrollable, "true");
        
        List<MobileElement>  skuNumberListOnPODetailPage = getSkuNumberListOnPODetailPage();
        boolean isScrolled= scrollDownByElement(skuNumberListOnPODetailPage);
        assertTrue(isScrolled);
        
//        String  text= skuNumberListOnPODetailPage.get(skuNumberListOnPODetailPage.size() - 1).getText();
//       // scrollToAnElementByText(text);
//        scroll(text);
        
	}
	
	public void scrollInPrintTicketPage(){
		
		clickOnPOSummary();
		elementClick(printTicketsBtnSummaryPage);
		fluentWait(printTicketHeading);
		
		MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
		
	   String isScrollable=element.getAttribute("scrollable");
       logger.info("Scrollable flag for PO PrintTicketPage is :"+isScrollable);
       assertEquals(isScrollable, "true");
       
       List<MobileElement> skuNumberListOnPrintPage = getSkuNumberListOnPrintPage();
       boolean isScrolled= scrollDownByElement(skuNumberListOnPrintPage);
       assertTrue(isScrolled);
       
//       String  text= skuNumberListOnPrintPage.get(skuNumberListOnPrintPage.size() - 2).getText();
//       scrollElementByContentDesc("com.si:id/liSTPO_PrintTickets_SKUs", "android.support.v7.widget.RecyclerView",
//    		   text);

	}

	public void validateLabelsInPOHomePage(SoftAssert softassert) {
		logger.info("To Validate if all the labels are displayed in the home page");
		
	    boolean isVendorLabelDisplayed = isDisplayed(vendorLabel);
		softassert.assertTrue(isVendorLabelDisplayed);
		
		boolean isPendingSkuQtyLabelDisplayed = isDisplayed(pendingSkuQtyLabel);
		softassert.assertTrue(isPendingSkuQtyLabelDisplayed);
		
		boolean isETALabelDisplayed = isDisplayed(etaLabel);
		softassert.assertTrue(isETALabelDisplayed);
		logger.info("All the labels are displayed in the Home Page");
		
	}
	
  public void validateSearchExitInPOHomePage(String purchaseOrder) throws InterruptedException{
    	
	   elementClick(searchBarHomePage);
	   setText(searchBarHomePage, purchaseOrder);
		
	   boolean keyboardBefore=driver.isKeyboardShown();
		logger.info("Keyboard Displayed flag before search Exit in PO :"+keyboardBefore);
		
		Thread.sleep(1000);
		TouchAction touchAction = new TouchAction(driver);
		touchAction.tap(PointOption.point(650, 190)).perform();
		
		boolean keyboardAfter=driver.isKeyboardShown();
		logger.info("Keyboard Displayed flag after search Exit in PO:"+keyboardAfter);
		assertFalse(keyboardAfter);
	
    }
  
	@Step("Validating received Quantity Edit funtionality in PO Detail Page")
	public void validateReceivedQuantityEditInPODetailPage(String purchaseOrderNumber,String storeNumber) throws ParseException {
		SoftAssert softassert = new SoftAssert();

		searchForPurchaseOrder(purchaseOrderNumber);
		clickOnPurchaseOrder();

		int totalPendingQtyBeforeEdit = Integer.parseInt(getTotalPendingQtyPODetailPage());
		int receviedQtyBeforeEdit = Integer.parseInt(getSpecificSkuReceivedQtyOnPODetailPage());
		int receivedQuantityToEdit = receviedQtyBeforeEdit + 1;

		logger.info("Pending QTY Before Edit is " + totalPendingQtyBeforeEdit);
		logger.info("Received QTY Before Edit is " + receviedQtyBeforeEdit);

		editSkuReceivedQuantityInDetailPage(String.valueOf(receivedQuantityToEdit));

		int totalPendingQtyAfterEdit = Integer.parseInt(getTotalPendingQtyPODetailPage());
		int receviedQtyAfterEdit = Integer.parseInt(getSpecificSkuReceivedQtyOnPODetailPage());

		logger.info("Pending QTY After Edit is " + totalPendingQtyAfterEdit);
		logger.info("Received QTY After Edit is " + receviedQtyAfterEdit);

		assertEquals(totalPendingQtyAfterEdit, totalPendingQtyBeforeEdit - 1);
		assertEquals(receviedQtyAfterEdit, receivedQuantityToEdit);

		clickOnFirstSkuNumber();
		String skuNumber = getSkuNumberOnSkuDetailPage();

		int receivedQuantityInSkuDetailPage = Integer.parseInt(getSkuReceivedQtySkuDetailPage());
		logger.info("Received QTY in Sku Detail Page " + receivedQuantityInSkuDetailPage);
		assertEquals(receivedQuantityInSkuDetailPage, receivedQuantityToEdit);

		clickOnBackBtnOnSkuDetailPage();
		clickOnPOSummary();
		clickSubmitBtnOnPOSummary();
		clickOnOkButtonAfterSubmit();
		elementClick(continueScanBtnSummaryPage);

		String skuScannedTime = BaseUtil.getTodayDate("MM/dd/yyyy HH:mm");
		logger.info("Current ScannedTime is " + skuScannedTime);
		mongoDB.ValidateReceivedQTYAndScannedTimeInPOInDB(purchaseOrderNumber, skuNumber, skuScannedTime,
				String.valueOf(receivedQuantityToEdit), softassert, storeNumber);
		
		clickOnFirstSkuNumber();
		String receivedQuantityToEditInDetailPage=String.valueOf(receivedQuantityToEdit+1);

		editSkuReceivedQuantityInSkuDetailPage(receivedQuantityToEditInDetailPage);
		String skuReceivedQtyAfterEditing = getSkuReceivedQtySkuDetailPage();
		Assert.assertEquals(skuReceivedQtyAfterEditing, receivedQuantityToEditInDetailPage);
		
		clickOnBackBtnOnSkuDetailPage();
		String receviedQtyAfterEditInDetailPage = getSpecificSkuReceivedQtyOnPODetailPage();
		logger.info("Received QTY After Edit in Sku Detail Page is " + receviedQtyAfterEditInDetailPage);
		Assert.assertEquals(receivedQuantityToEditInDetailPage, receviedQtyAfterEditInDetailPage);
		
		softassert.assertAll();
	}

	public void editSkuReceivedQuantityInDetailPage(String receivedQuantityToEdit) {
		clickOnReceivedSkuQuantity();
		sendTextToEditReceivedSkuQty(receivedQuantityToEdit);
	}
	
	public void editSkuReceivedQuantityInSkuDetailPage(String receivedQuantityToEditInDetailPage) {
		WebElement skuNo = driver.findElement(By.id("com.si:id/liPO_SKUDescDetails_SKUNumber"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnSKuEditButton();
		elementClick(inputBtnToEnterSkuQty);
		sendTextToEditSkuQty(receivedQuantityToEditInDetailPage);
		clickOnSave();
	}


}
