package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.touch.offset.PointOption;


public class ReceivingShipmentPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(ReceivingTransferPage.class.getName());

	protected By scanButton = By.id("com.si:id/btnDCShip_Home_Scan");
	protected By searchBar = By.id("com.si:id/search_bar");
	protected By shipmentText = By.id("com.si:id/liDCShip_Home_ShipmentNo");
	protected By dcInfo = By.id("com.si:id/liDCShip_Home_DCInfo");
	//protected By pendingCartonNumber = By.id("com.si:id/txtQuantityItem");
	//protected By pendingCartonNumber = By.id("//com.si:id/liDCShip_Home_Qty");
	protected By pendingCartonNumber = By.id("com.si:id/liDCShip_Home_Qty");
	protected By clearSearch = By.id("com.si:id/search_close_btn");
	protected By searchBarTextBox = By.id("com.si:id/search_src_text");
	protected By etaTextBox = By.id("com.si:id/liDcSHIP_Home_ETADate");
	protected By shipmentNumberItem = By.id("com.si:id/liDCShip_Home_ShipmentNo");
	protected By goBackBtn=By.id("com.si:id/btnDCShip_Home_Back");
	//DC Info label android.widget.TextView Text DC INFO
	//protected Dc info value  id com.si:id/liDCShip_Home_DCInfo
	//Pending carton qty- id-com.si:id/liDCShip_Home_Qty
	//eta date value -ID-com.si:id/liDcSHIP_Home_ETADate
	
	protected By dcInfoLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='DC INFO']");
	protected By pendingCartonsLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='PDNG CRTNS']");
	protected By etaLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='ETA']");


	public void clickOnScanButton() {
		logger.info("Clicking on DC Shipment Scan Button");
		elementClick(scanButton);
	}

	public boolean searchForShipmentNumber(String shipmentNumber) {
		elementClick(searchBar);
		setText(searchBarTextBox, shipmentNumber);
		pressEnter();
		return isDisplayed(shipmentText);
		
	}

	public void searchForShipmentNumberWhenAlreadyScanned(String shipmentNumber, SoftAssert assertion) {
		elementClick(searchBar);
		setText(searchBarTextBox, shipmentNumber);
		pressEnter();
		boolean shipmentNumberAfterSubmitting = isDisplayedWithoutWait(shipmentNumberItem);
		assertion.assertFalse(shipmentNumberAfterSubmitting);
		assertion.assertAll();
		

	}
	
	@SuppressWarnings("deprecation")
	public void searchForShipmentNumberWhenPartiallyScanned(String shipmentNumber) {
		SoftAssert assertion=new SoftAssert();
		elementClick(searchBar);
		setText(searchBarTextBox, shipmentNumber);
		driver.pressKeyCode(AndroidKeyCode.ENTER);
		
//		boolean shipmentNumberIfPartiallySubmitted=isDisplayed(shipmentNumberItem);
//		Assert.assertTrue(shipmentNumberIfPartiallySubmitted);
		
		boolean noOfCartonsForHalfSubmittedShipment=isDisplayed(pendingCartonNumber);
		assertion.assertTrue(noOfCartonsForHalfSubmittedShipment);
		
		String pendingCartonValue=pendingCartonValue();
		assertion.assertEquals("1", pendingCartonValue);
		assertion.assertAll();
		
	}
	
	public String pendingCartonValue() {
		return getText(pendingCartonNumber);
	}

	public boolean isShipmentDisplayed(String shipmentNumber) {
		elementClick(searchBar);
		setText(searchBarTextBox, shipmentNumber);
		pressEnter();
		return isDisplayedWithoutWait(shipmentText);

	}

	public String getDCInfo() {
		return getText(dcInfo);
	}

	public String getShipmentNumber() {
		return getText(shipmentText);
	}

	public String getPendingCarton() {
		return getText(pendingCartonNumber);
	}

	public void clickClearSearch() {
		elementClick(clearSearch);
	}

	public String getETA() {
		return getText(etaTextBox);
	}

	public boolean isScanButtonDisplayed() {
		return isDisplayed(scanButton);
	}
	public void validateLabelsInDCshipmentHomePage(SoftAssert softassert) {
		 logger.info("To Validate if all the labels are displayed in the home page");
		 
			
		    boolean isDCInfoLabelDisplayed = isDisplayed(dcInfoLabel);
			softassert.assertTrue(isDCInfoLabelDisplayed);
			
			boolean isPendingCartonsLabelDisplayed = isDisplayed(pendingCartonsLabel);
			softassert.assertTrue(isPendingCartonsLabelDisplayed);
			
			boolean isETALabelDisplayed = isDisplayed(etaLabel);
			softassert.assertTrue(isETALabelDisplayed);
			
			logger.info("All the labels are displayed in the Home Page");
		
	}
	
	 public void scrollInDCShipmentHomePage(){
			fluentWait(shipmentNumberItem);
			
			MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
			
			 String isScrollable=element.getAttribute("scrollable");
	         logger.info("Scrollable flag for DC Shipment HOMEPAGE is :"+isScrollable);
	         assertEquals(isScrollable, "true");
	         
	         List<MobileElement> shipmentList=driver.findElementsById("com.si:id/liDCShip_Home_ShipmentNo");
	         
	         boolean isScrolled= scrollDownByElement(shipmentList);
	         assertTrue(isScrolled);
		}
	 
	
    public void validateSearchExitInDCShipmentHomePage(String shipmentNumber) throws InterruptedException{
    	
    	elementClick(searchBar);
		setText(searchBarTextBox, shipmentNumber);
		
		boolean keyboardBefore=driver.isKeyboardShown();
		logger.info("Keyboard Displayed flag before search Exit in DC:"+keyboardBefore);
		
		Thread.sleep(1000);
		TouchAction touchAction = new TouchAction(driver);
		touchAction.tap(PointOption.point(650, 190)).perform();
		
		boolean keyboardAfter=driver.isKeyboardShown();
		logger.info("Keyboard Displayed flag after search Exit in DC :"+keyboardAfter);
		assertFalse(keyboardAfter);
	
    }
	
}