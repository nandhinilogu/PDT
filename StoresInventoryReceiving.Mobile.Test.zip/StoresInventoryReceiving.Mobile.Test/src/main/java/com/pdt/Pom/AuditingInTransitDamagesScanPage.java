package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.util.DataBase.MongoDBManager;
import com.util.DataBase.MongoDBQueryStore;
import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class AuditingInTransitDamagesScanPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(AuditingInTransitDamagesScanPage.class.getName());
	SoftAssert softAssert = new SoftAssert();
	ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();

	protected By addButton = By.id("com.si:id/btnAuditITD_Home_Add");
	protected By searchButton = By.id("com.si:id/search_bar");
	protected By addDamagedCartonsTextBox = By.id("com.si:id/search_src_text");
	protected By AddButtonOnBottom = By.id("com.si:id/btnAuditITD_AddCarton_Add");
	protected By reEnter4Digits = By.id("com.si:id/txtPopUpTemplateNum");
	protected By enterButton = By.id("com.si:id/btnPopUpEnter");
	protected By cartonNumberInTransitScreen = By.id("com.si:id/liAuditITD_Home_CartonNo");

	protected By scannedDamagedCarton = By.id("com.si:id/liAuditITD_Home_CartonNo");
	// com.si:id/layoutAuditITD_AddCarton
	protected By damagedSKUQtyOnDetailPage = By.id("com.si:id/liAuditITD_CartonDetails_DamSKUQty");
	protected By damagedCartonOnInTransitDamages = By.id("com.si:id/liAuditITD_Home_CartonNo");
	protected By inTransitHeading = By.id("com.si:id/lblAuditITD_Home_Header");
	protected By defaultMessage = By.id("com.si:id/lblAuditITD_Home_ScanMsg");
	protected By errorMessageInAddCarton = By.id("com.si:id/lblAuditITD_AddCarton_CartonNo");
	protected By closeButtonSearchBar = By.id("com.si:id/search_close_btn");
	protected By enter4LastDigitsMessage = By.id("com.si:id/lblPopUpTemplateMsg");
	protected By cartonNumberDoesNotMatchMsg = By.id("com.si:id/lblPopUpErrorMsg");
	protected By clickCancelPopUpBox = By.id("com.si:id/btnPopUpCancel");
	protected By cartonNumber = By.id("com.si:id/lblAuditITD_AddCarton_CartonNo");
	protected By submitDamagesButton = By.id("com.si:id/btnAuditITD_Home_Submit");
	protected By goBackInAddCartonScreen=By.id("com.si:id/btnAuditITD_AddCarton_Back");
	protected By androidMessage=By.id("android:id/message");
	protected By okButton=By.id("android:id/button1");
	
	protected By skuNumberOnAddSku=By.id("com.si:id/liAuditITDOrp_SKUDetails_SKUNo");
	protected By cartonNumberOnAddskuPage=By.id("com.si:id/lblAuditITDOrp_CartonDetails_Header");
	protected By goBackButtonInAddSkuPage=By.id("com.si:id/btnAuditITDOrp_CartonDetails_Back");
	
	protected By cartonNumberCartonDetailPage=By.id("com.si:id/lblAuditITD_CartonDetails_CartonNo");
	protected By skuNummberCartonDetailPage=By.id("com.si:id/liAuditITD_CartonDetails_SKUNumber");
	protected By skuDescCartonDetailPage=By.id("com.si:id/liAuditITD_CartonDetails_SKUDesc");
	protected By skuQtyCartonDetailPage=By.id("com.si:id/liAuditITD_CartonDetails_SKUQty");
	protected By receivedQtyCartonDetailPage=By.id("com.si:id/liAuditITD_CartonDetails_RecQty");
	protected By specialHandling=By.id("com.si:id/liAuditITD_CartonDetails_SplHandling");
	protected By goBackCartonDetailPage=By.id("com.si:id/btnAuditITD_CartonDetails_Back");
	protected By skuReceivedQty=By.id("com.si:id/liAuditITD_CartonDetails_RecQty");
	
	protected By savebutton = By.id("com.si:id/txtAuditITD_EditSKU_Save");
	protected By cancelbutton = By.id("com.si:id/txtAuditITD_EditSKU_Cancel");
	protected By editDamagedQty=By.id("com.si:id/txtAuditITD_EditSKU_SKUQty");
	protected By editReceivedQty=By.id("com.si:id/txtAuditITD_Rec_SKUQty");
	protected By editButtonCartonDetailPage=By.id("com.si:id/imgAuditITD_CartonDetails_Edit");
	protected By damagedQtyErrorMessage=By.id("com.si:id/txtAuditITD_EditSKU_ErrorMsg");
	
	protected By skuLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU QTY']");
	protected By receivedSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Received SKU QTY']");
	protected By damagedSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Damaged SKU QTY']");
	protected By specialHandlingLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Special Handling']");

	
	protected By AddIconOrphanCarton = By.id("com.si:id/btnAuditITDOrp_CartonDetails_Add");
	protected By searchButtonAddSkuPage=By.id("com.si:id/search_button");
	protected By searchBarAddSkuPage=By.id("com.si:id/search_src_text");
	protected By skuNumberAddSkuPage=By.id("com.si:id/lblAuditMAD_AddSKU_SKUNo");
	protected By  skuDescriptionAddSkuPage=By.id("com.si:id/lblAuditMAD_AddSKU_SKUDesc");
	protected By  addButtonAddSkuPage=By.id("com.si:id/btnAuditMAD_AddSKU_Add");
    protected By  skuNumberInDetailPage=By.id("com.si:id/liAuditITDOrp_SKUDetails_SKUNo");
	protected By  qtyInDetailPage=By.id("com.si:id/liAuditITDOrp_SKUDetails_SKUQty");
	
	public String validatingCartonNumberOnInTransitDamage() {
		return getText(damagedCartonOnInTransitDamages);
	}

	public String getDamagedSKUQty() {
		return getText(damagedSKUQtyOnDetailPage);
	}

	public void clickOnDamagedCarton() {
		elementClick(scannedDamagedCarton);
	}

	public void initiateInTransitDamages(String cartonNumber) throws ParseException {
		// String CartonNumber = getCartonNumber(storeNumber);
		clickOnAddButton();
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		clickAddButtonOnBottom();
		reEnter4DigitsCartonNumber(cartonNumber);
		clickOnEnter();

	}

	private String getCartonNumber(String storeNumber) throws ParseException {

		MongoDBQueryStore mongoDB = new MongoDBQueryStore();
		// BasePage basePage = new BasePage();
		MongoCollection<Document> collection = MongoDBManager.getCollection();

		BasicDBObject inTransitQuery = mongoDB.getReceivedShipmentsByCartonsForInTransitDamages(collection,
				storeNumber);
		long shipmentCount = collection.count(inTransitQuery);
		if (shipmentCount > 0) {

			for (Document doc : collection.find(inTransitQuery).limit(1)) {
				if ((doc.get("Cartons") != null)) {
					List<Document> cartons = (List<Document>) doc.get("Cartons");
					for (Document carton : cartons) {
						if (carton.get("IsScanned", false) == true)
							return carton.getString("CartonNumber");
					}
				}

			}
		}

		return null;
	}

	public void enterDamagedCartonNumber(String CartonNumber) {
		elementClick(searchButton);
		setText(addDamagedCartonsTextBox, CartonNumber);

	}

	public void clickSearchButton() {
		TouchAction touchAction=new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();
		//pressEnter();
	}

	public void clickAddButtonOnBottom() {
		elementClick(AddButtonOnBottom);

	}

	public void reEnter4DigitsCartonNumber(String CartonNumber) {
		setText(reEnter4Digits, CartonNumber.substring(CartonNumber.length() - 4, CartonNumber.length()));
	}

	public void reEnter4CartonDigitsIncorrectly(String cartonNumber) {
		setText(reEnter4Digits, cartonNumber.substring(cartonNumber.length() - 5, cartonNumber.length() - 1));
	}

	public void clickOnEnter() {
		elementClick(enterButton);

	}

	@Step("Verify Damaged carton number is displayed")
	public boolean inTransitDamagedCartonDisplayed() {
		return isDisplayed(cartonNumberInTransitScreen);
	}

	public void clickOnAddButton() {
		elementClick(addButton);
	}

	@Step("Verify if Heading is displayed")
	public void isInTransitDamagesHeadingDisplayed() {
		fluentWait(inTransitHeading);
		String heading = getText(inTransitHeading);
		Assert.assertEquals("In Transit Damages", heading);
	}

	@Step("Verify if Default message is displayed")
	public boolean isDefaultMessageDisplayed() {
		return isDisplayedWithoutWait(defaultMessage);
	}

	//@Step("Get Default Message")
//	public String captureDefaultMessage() {
//		return getText(defaultMessage);
//	}

	@Step("Verify if added carton number from json file is not displayed")
	public void isDamagedCartonNotDisplayed(String cartonNumber) {
		assertFalse(isDisplayedWithoutWait(
				By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']")));
		logger.info("Given Damaged carton is not displayed");
	}

	@Step("Verify if added carton number from json file is displayed")
	public boolean isDamagedCartonDisplayed(String cartonNumber) {
		String displayedCartonNumber = getText(
				By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
		logger.info("Damaged carton displayed is " + displayedCartonNumber);
		return isDisplayed(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
	}
	
	@Step("To verify damaged qunatity set in DC shipment")
	public void verifyDamagedQuantity(String cartonNumber,String damagedQty ){
		elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
		
		String cartonNumberInAddSkuPage=getCartonNumberInAddSkuPage();
		softAssert.assertEquals(cartonNumberInAddSkuPage, cartonNumber);
		clickSkuNumber();
		
		String cartonNumberInDetailPage=getCartonNumberFromCartonDetailPage();
		softAssert.assertEquals(cartonNumberInDetailPage, cartonNumber);
		
		String uiDamagedSkuQty = getDamagedSKUQty();
		softAssert.assertEquals(damagedQty, uiDamagedSkuQty);
		logger.info("Damaged Quantity displayed in In-Transit is "+uiDamagedSkuQty);
		
		int uiShippedSkuQty = Integer.parseInt(getSKUQtyCartonDetailPage());
		int damagedSkuQty = Integer.parseInt(uiDamagedSkuQty);
		
		boolean value=true; 
		if(damagedSkuQty>uiShippedSkuQty){
			value=false;
		}
		softAssert.assertTrue(value);
		softAssert.assertAll();
	}

	@Step("Verify error message for not submitted scanned Carton in Intransit Damages screen")
	public void addScannedCartonToInTransitDamage(String cartonNumber) {
		logger.info("Validate Error message for scanned Not submitted Carton ");
		clickOnAddButton();
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		String errorMessageForScannedCarton = getErrorMessageInAddcartonPage();
		Assert.assertEquals(errorMessageForScannedCarton, "Scanned carton has not been received yet");
		logger.info("Messaged displayed for just Scanned Carton is " + errorMessageForScannedCarton);
		elementClick(errorMessageInAddCarton);
		assertFalse(isEnabled(AddButtonOnBottom));
	}

	public String getErrorMessageInAddcartonPage() {
		return getText(errorMessageInAddCarton);

	}

	public void clickOnCloseButtonInSearchBar() {
		elementClick(closeButtonSearchBar);
	}

	public String captureEnter4DigitsMessage() {
		return getText(enter4LastDigitsMessage);
	}

	public String getCartonNumberDoesNotMatchMessage() {
		return getText(cartonNumberDoesNotMatchMsg);
	}

	public void clickCancelPopupButton() {
		elementClick(clickCancelPopUpBox);
	}

	public String getCartonNumberFromInTransitDamageScreen() {
		fluentWait(cartonNumberInTransitScreen);
		return getText(cartonNumberInTransitScreen).substring(8);

	}

	public String getCartonNumberAfterAdding() {
		return getText(cartonNumber);

	}
    
	@Step("Submit Damaged Carton")
	public void clickOnSubmitDamagesButton() {
		logger.info("Clicking on submit Damages Button");
		elementClick(submitDamagesButton);
//		Assert.assertTrue(isDisplayed(androidMessage));
//		logger.info(getText(androidMessage));
//		elementClick(okButton);
//		Assert.assertFalse(isDisplayedWithoutWait(submitDamagesButton));
   }

	@Step("Verify error message for Invalid Carton Number added to InTransitDamages")
	public void addInvalidCartonNumberToInTransitDamages(String cartonNumber) {
		logger.info("Validate Error message for Invalid Carton Number");
		clickOnAddButton();
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		String errorMessageForInvalidCarton = getErrorMessageInAddcartonPage();
		Assert.assertEquals(errorMessageForInvalidCarton, "Carton Number not found");
		logger.info("Messaged displayed for Invalid Carton Number is " + errorMessageForInvalidCarton);
		elementClick(errorMessageInAddCarton);
		assertFalse(isEnabled(AddButtonOnBottom));
	}

	@Step("Verify error message for incorrectly entered last 4 digits of the carton")
	public void validateErrorMessageForEnteringInvalidFourDigitsForValidCarton(String cartonNumber) {
		clickOnCloseButtonInSearchBar();
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		clickAddButtonOnBottom();
		String PopUpDefaultMessage = captureEnter4DigitsMessage();
		Assert.assertEquals(PopUpDefaultMessage, "Re-enter last 4 carton digits");
		logger.info("Popup message Displayed is " + PopUpDefaultMessage);
		reEnter4CartonDigitsIncorrectly(cartonNumber);
		clickOnEnter();
		String cartonNumberMismatchMessage = getCartonNumberDoesNotMatchMessage();
		Assert.assertEquals(cartonNumberMismatchMessage, "Incorrect Entry. Please enter again");
		logger.info("Message Displayed for Mismatch is " + cartonNumberMismatchMessage);
		clickCancelPopupButton();
		clickOnCloseButtonInSearchBar();
	}

	@Step("Method to add a valid carton number to In-Transit Damages")
	public void addValidCartonNumberToInTransitDamages(String cartonNumber) throws ParseException {
		logger.info("Add a Valid carton Number To the InTransit Home Screen");
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		String cartonEntered = getCartonNumberAfterAdding();
		Assert.assertEquals(cartonEntered, cartonNumber);
		clickAddButtonOnBottom();
		reEnter4DigitsCartonNumber(cartonNumber);
		clickOnEnter();
		String scannedCartonNumber = getCartonNumberFromInTransitDamageScreen();
		Assert.assertEquals(scannedCartonNumber, cartonNumber);
		logger.info("Carton Number added to In-Transit Damages Home screen is " + scannedCartonNumber);
	}

	@Step("Verify error message for Duplicate Carton Number added to InTransitDamages")
	public void addDuplicateCartonNumberToInTransitDamages(String cartonNumber) throws ParseException {
		logger.info("Validate Error message for Duplicate Carton Number");
		clickOnAddButton();
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		String errorMessageForDuplicateCarton = getErrorMessageInAddcartonPage();
		Assert.assertEquals(errorMessageForDuplicateCarton, "Duplicate carton number. Please try again");
		logger.info("Messaged displayed for Duplicate Carton Number is " + errorMessageForDuplicateCarton);
		elementClick(errorMessageInAddCarton);
		assertFalse(isEnabled(AddButtonOnBottom));
	}
	
	public void validateGobackInAddCartonPage(){
		elementClick(goBackInAddCartonScreen);
		
	}
	
	@Step("Method to add a  carton number to In-Transit Damages")
	public void addCartonToInTransitDamages(String cartonNumber) throws ParseException {
		logger.info("Add a Valid carton Number To the InTransit Home Screen");
		clickOnAddButton();
		enterDamagedCartonNumber(cartonNumber);
		clickSearchButton();
		String cartonEntered = getCartonNumberAfterAdding();
		Assert.assertEquals(cartonEntered, cartonNumber);
		clickAddButtonOnBottom();
		reEnter4DigitsCartonNumber(cartonNumber);
		clickOnEnter();
		String scannedCartonNumber = getCartonNumberFromInTransitDamageScreen();
		Assert.assertEquals(scannedCartonNumber, cartonNumber);
		logger.info("Carton Number added to In-Transit Damages Home screen is " + scannedCartonNumber);
	}
	
	public void validateDetailsOfDamagedCarton(String inTransitCarton,String storeNumber) throws ParseException{
		
		clickOnCartonNumber();
		
		String cartonNumberInAddSkuPage=getCartonNumberInAddSkuPage();
		softAssert.assertEquals(cartonNumberInAddSkuPage, inTransitCarton);
		clickSkuNumber();
		
		String cartonNumbeInDetailPage=getCartonNumberFromCartonDetailPage();
		softAssert.assertEquals(cartonNumbeInDetailPage, inTransitCarton);
		int uiReceivedSkuQty = Integer.parseInt(getSkuReceivedQtyCartonDetailPage());
		int uiDamagedSkuQty = Integer.parseInt(getDamagedSKUQty());
		
		boolean value=true; 
		if(uiDamagedSkuQty>uiReceivedSkuQty){
			value=false;
			logger.info("Damaged Quantity is greater than Received quantity");
		}
		softAssert.assertTrue(value);
		softAssert.assertEquals(uiDamagedSkuQty, 0);
		
		//Validation in DB
		validateFromMongoDB.validateSkuDetailsForDamagedCarton(inTransitCarton,softAssert, storeNumber);
		
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(softAssert);
		
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
        String inTransitHeadingHomePage = getText(inTransitHeading);
        softAssert.assertEquals(inTransitHeadingHomePage, "In Transit Damages");
		logger.info("Heading displayed in Home Page is "+inTransitHeadingHomePage);
		softAssert.assertAll();
		
	}
	
	private void validateSkuLabel(SoftAssert softassert) {
		boolean isCartonLabelDisplayed = isDisplayed(cartonNumberCartonDetailPage);
		softassert.assertTrue(isCartonLabelDisplayed);
		
		boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
		softassert.assertTrue(isSkuLabelDisplayed);
		
		boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
		softassert.assertTrue(isSkuDescLabelDisplayed);
		
		boolean isSkuQtyLabelDisplayed = isDisplayed(skuQtyLabel);
		softassert.assertTrue(isSkuQtyLabelDisplayed);
		
		boolean isReceivedSkuQtyLabelDisplayed = isDisplayed(receivedSkuQtyLabel);
		softassert.assertTrue(isReceivedSkuQtyLabelDisplayed);
		
		boolean isDamagedSkuQtyLabelDisplayed = isDisplayed(damagedSkuQtyLabel);
		softassert.assertTrue(isDamagedSkuQtyLabelDisplayed);
		
		boolean isSpecialHandlingLabelDisplayed = isDisplayed(specialHandlingLabel);
		softassert.assertTrue(isSpecialHandlingLabelDisplayed);
		logger.info("All the sku labels are displayed in the sku detail page");
		
	}
	

	public void clickOnCartonNumber() {
		fluentWait(cartonNumberInTransitScreen);
		driver.findElements(cartonNumberInTransitScreen).get(0).click();
	}
	
	public void clickSkuNumber(){
		elementClick(skuNumberOnAddSku);
	}
	
	public String getCartonNumberInAddSkuPage(){
		return getText(cartonNumberOnAddskuPage).substring(8);
	}
	
	public String getCartonNumberFromCartonDetailPage() { 
		return getText(cartonNumberCartonDetailPage).substring(8);
		
	}
	
	public String getSKUNumberCartonDetailPage() {
		return getText(skuNummberCartonDetailPage);
	}
	
	public String getSKUDescCartonDetailPage() {
		return getText(skuDescCartonDetailPage);
	}
	
	public String getSKUQtyCartonDetailPage() {
		return getText(skuQtyCartonDetailPage);
	}
	
	public String getSkuReceivedQtyCartonDetailPage(){
		return getText(skuReceivedQty);
	}
	
	public String getSpecialHandlingCartonDetailPage() {
		return getText(specialHandling);
	}
	
	public void clickOnGoBackCartonDetailPage(){
		elementClick(goBackCartonDetailPage);
	}
	
	public void clickOnGoBackInAddSku(){
		elementClick(goBackButtonInAddSkuPage);
	}
	
	public ArrayList<MobileElement> getSkuNumbersInSkuListPage() {
		return (ArrayList<MobileElement>) getListText(skuNumberOnAddSku);
	}
	
	public ArrayList<MobileElement> getSkuNumberListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuNummberCartonDetailPage);
	}
	
	public ArrayList<MobileElement> getSkuDescriptionListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuDescCartonDetailPage);
	}
	
	public ArrayList<MobileElement> getSkuQtyListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuQtyCartonDetailPage);
	}
	
	public ArrayList<MobileElement> getReceivedQtyListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(skuReceivedQty);
	}
	
	
	public ArrayList<MobileElement> getSkuDamagedQtyListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(damagedSKUQtyOnDetailPage);
	}
	
	public ArrayList<MobileElement> getSpecialHandlingListOnCartonDetailPage() {
		return (ArrayList<MobileElement>) getListText(specialHandling);
	}
	
	public void clickOnEditButton() {
		elementClick(editButtonCartonDetailPage);
	}
	public void clickOnSaveButton() {
		elementClick(savebutton);
	}
	public void clickOnCancelButton() {
		elementClick(cancelbutton);
	}
	
	public void setDamagedSkuQty(String damagedQty) {
		fluentWait(editDamagedQty);
		elementClick(editDamagedQty);
		clearTextField(editDamagedQty);
		setText(editDamagedQty, damagedQty);
		pressEnter();
	}
	
	
	
	public void validateDetailsOfDamagedCartonWithMultipleSku(String cartonNumber,String storeNumber) throws ParseException {
		
		clickOnCartonNumber();
		
		String cartonNumberInAddSkuPage=getCartonNumberInAddSkuPage();
		softAssert.assertEquals(cartonNumberInAddSkuPage, cartonNumber);
		
		ArrayList<MobileElement> skuNumberListOnDetailPage = getSkuNumbersInSkuListPage();

		int index = -1;
		for (int i = 0; i < skuNumberListOnDetailPage.size(); i++) {
			skuNumberListOnDetailPage = getSkuNumbersInSkuListPage();
			String skuValuetmp = skuNumberListOnDetailPage.get(i).getText().substring(5);
			logger.info("Sku Number is ------ " + skuValuetmp);
			if (skuValuetmp!= null) {
				index = i;
				logger.info("Index of SKU ------ " + index);
				skuNumberListOnDetailPage.get(index).click();
			}
		
		String cartonNumbeInDetailPage=getCartonNumberFromCartonDetailPage();
		softAssert.assertEquals(cartonNumbeInDetailPage, cartonNumber);
		validateFromMongoDB.getSkuDetailsForDamagedCartonWithMultipleSku(cartonNumber, skuValuetmp, softAssert, storeNumber);
		clickOnGoBackCartonDetailPage();
		softAssert.assertAll();
		}

}
	@Step("To edit damaged Qty to less than Sku Qty")
	public void editAndSaveDamagedSkuQty(String damagedQty) {
		clickOnCartonNumber();
		clickSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Damaged Qty Is "+ damagedQty );
		clickOnSaveButton();
		String EditedDamagedQty = getDamagedSKUQty();
		logger.info("Saved Damaged Qty Is "+ EditedDamagedQty );
		Assert.assertEquals(damagedQty, EditedDamagedQty);
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
	}
	@Step(" To validate click on cancel doesnot save the edited damaged qty")
	public void editAndCancelDamagedSkuQty(String damagedQty){
		clickOnCartonNumber();
		clickSkuNumber();
		String damagedQtyBeforeEdit = getDamagedSKUQty();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Damaged Qty Is "+ damagedQty );
		clickOnCancelButton();
		String EditedDamagedQty = getDamagedSKUQty();
		logger.info("Damaged Qty After Cancel "+ EditedDamagedQty );
		Assert.assertEquals(EditedDamagedQty, damagedQtyBeforeEdit);
		Assert.assertNotEquals(damagedQty, EditedDamagedQty);
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
	}
	
	@Step("To validate associates is not able to edit damaged Qty more than Sku Qty")
	public void editDamagedQtyMoreThanSkuReceivedQty(String damagedQty){
		clickOnCartonNumber();
		clickSkuNumber();
		String damagedQtyBeforeEdit = getDamagedSKUQty();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Damaged Qty Is "+ damagedQty );
		clickOnSaveButton();
		String ErrorMessage=getText(damagedQtyErrorMessage);
		Assert.assertEquals(ErrorMessage, "Please ensure that the damaged qty is never more than the expected SKU quantity for that carton");
		logger.info("ErrorMessage is : "+ErrorMessage);
		clickOnCancelButton();
		String EditedDamagedQty = getDamagedSKUQty();
		logger.info("Damaged Qty After Cancel "+ EditedDamagedQty );
		Assert.assertEquals(EditedDamagedQty, damagedQtyBeforeEdit);
		Assert.assertNotEquals(damagedQty, EditedDamagedQty);
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
	}
	
	@Step("To validate associates is not able to edit the Damaged SKU Qty above 99")
	public void editDamagedQtyAbove99(String damagedQty) {
		clickOnCartonNumber();
		clickSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Damaged Qty Is "+ damagedQty );
		int sizeOfDamagedQty = getText(editDamagedQty).length();
		logger.info("Length of damaged QTY entered------> " + sizeOfDamagedQty);
		assertEquals(2, sizeOfDamagedQty);
		clickOnCancelButton();
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
	}
	
	 public void scrollInCartonDetailPageInTransitDamages(String cartonNumber){
		    
		    elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));

			MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
			
			String isScrollable=element.getAttribute("scrollable");
	        logger.info("Scrollable flag In IN-Transit Carton DetailPage is :"+isScrollable);
	        assertEquals(isScrollable, "true");
	        
	        List<MobileElement>  skuNumberListOnCartonDetailPage = getSkuNumberListOnCartonDetailPage();
	        boolean isScrolled= scrollDownByElement(skuNumberListOnCartonDetailPage);
	        assertTrue(isScrolled);
	        
	        
		}
	
	@Step("To get Css Value")
	public void getCssvalue(String cartonNumber ){
	    //WebDriver driv=driver;
		WebElement googleSearchBtn = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']")); 
	    //System.out.println("Color of a button before mouse hover: " + googleSearchBtn.getCssValue("color"));
	    System.out.println("Color of a button before mouse hover: " + googleSearchBtn.getAttribute("text"));
	    System.out.println("Color of a button before mouse hover: " + googleSearchBtn.getAttribute("noshade"));
	
	}
	public void clickAddButtonInCartonDetailPage() {
		elementClick(AddIconOrphanCarton);
	}
	public void enterSkuNumber(String skuNumber)  {
		elementClick(searchButtonAddSkuPage);
		setText(searchBarAddSkuPage, skuNumber);
		clickSearchButton();

	}
	public String getSkuNumberFromAddSkuPage() { 
		return getText(skuNumberAddSkuPage);
		
	}
	public String getSkuDescriptionCartonDetailPage() { 
		return getText(skuDescCartonDetailPage);
		
	}
	public String getSkuDescriptionFromAddSkuPage() { 
		return getText(skuDescriptionAddSkuPage);
		
	}
	public void clickAddIconInAddSkuPage() {
		elementClick(addButtonAddSkuPage);
	}
	public void clickSkuNumberFromAddSkuPage() {
		elementClick(skuNumberAddSkuPage);
	}
	
	@Step("Method to Validate error message while Adding invalid sku to orphan cartons")
	public void validateErrorMessageWhileAddingInValidSkuToCarton (String skuNumber) {
				clickOnCartonNumber();
				clickAddButtonInCartonDetailPage();
				enterSkuNumber(skuNumber);
				logger.info("Sku Number added " + skuNumber);
				String errorMessageForInvalidSku=getSkuNumberFromAddSkuPage();
				Assert.assertEquals(errorMessageForInvalidSku, "SKU Number not found");
				logger.info(errorMessageForInvalidSku + " message displayed");
			}
	public String getSkuQtyCartonDetailPage() { 
		return getText(skuQtyCartonDetailPage);
		
	}
	public String getReceivedSkuQtyCartonDetailPage() { 
		return getText(receivedQtyCartonDetailPage);
		
	}
	@Step("Method to Validate Adding valid extra sku to Orphan cartons")
			public void validateAddingValidSkuToOrphanCarton(String skuNumber) {
				clickOnCloseButtonInSearchBar();
				setText(searchBarAddSkuPage, skuNumber);
				clickSearchButton();
				logger.info("Sku Number added " + skuNumber);
				String skuNumberInAddSkuPage=getSkuNumberFromAddSkuPage();
				String skuDescriptionInAddSkuPage=getSkuDescriptionFromAddSkuPage();
				clickAddIconInAddSkuPage();
				clickSkuNumber();
				String skuNumberInCartonDetailPage=getSKUNumberCartonDetailPage();
				String skuDescriptionInCartonDetailPage=getSkuDescriptionCartonDetailPage();
				Assert.assertEquals(skuNumberInAddSkuPage, skuNumberInCartonDetailPage);
				Assert.assertEquals(skuDescriptionInAddSkuPage, skuDescriptionInCartonDetailPage);
				String skuQtyInCartonDetailPage=getSkuQtyCartonDetailPage();
				String receivedskuQtyInCartonDetailPage=getReceivedSkuQtyCartonDetailPage();
				Assert.assertEquals(skuQtyInCartonDetailPage, "0");
				Assert.assertEquals(receivedskuQtyInCartonDetailPage, "1");
				clickOnGoBackCartonDetailPage();
				clickOnGoBackInAddSku();

			}
	// Method to Validate error message while Adding invalid sku to scanned cartons
	public void validateErrorMessageWhileAddingDuplicateSkuToCarton (String skuNumber) {
		clickOnCartonNumber();
		clickAddButtonInCartonDetailPage();
		enterSkuNumber(skuNumber);
		logger.info("Sku Number added " + skuNumber);
		String errorMessageForDuplicateSku=getSkuNumberFromAddSkuPage();
		Assert.assertEquals(errorMessageForDuplicateSku, "Duplicate SKU number. Please try again");
		logger.info(errorMessageForDuplicateSku + " message displayed");
	
	}
	
	@Step("Method to edit and save the received qty for orphan carton associated skus")
	public String editAndSaveReceivedSkuQty(String skuQty) {
		clickOnCartonNumber();
		clickSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setReceivedSkuQty(skuQty);
		logger.info("Edited Sku Qty Is "+ skuQty );
		pressEnter();
		clickOnSaveButton();
		String EditedSkuQty = getReceivedSkuQtyCartonDetailPage();
		logger.info("Saved Sku Qty Is "+ EditedSkuQty );
		Assert.assertEquals(skuQty, EditedSkuQty);
		clickOnGoBackCartonDetailPage();
		
		String skuNumberInDetailPage=getSkuNumberInDetailPage().substring(5);
		logger.info("Sku Number Displayed in Carton Detail Page is --> "+skuNumberInDetailPage);
		
		String skuQtyNumberInCartonDetailPage = getQtyInDetailPage().substring(4);
		logger.info("Total Pending qty Displayed in Carton Detail Page is --> "+skuQtyNumberInCartonDetailPage);
		Assert.assertEquals(skuQtyNumberInCartonDetailPage, EditedSkuQty);
		clickOnGoBackInAddSku();
		return EditedSkuQty;
	}
	
	@Step("Method to edit and cancel the received qty for orphan carton associated skus")
	public void editAndCancelReceivedSkuQty(String skuQty) {
		clickOnCartonNumber();
		clickSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setReceivedSkuQty(skuQty);
		logger.info("Edited Sku Qty Is "+ skuQty );
		pressEnter();
		clickOnCancelButton();
		String EditedSkuQty = getReceivedSkuQtyCartonDetailPage();
		logger.info("canceled sku qty edit "+ EditedSkuQty );
		Assert.assertNotEquals(skuQty, EditedSkuQty);
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
		
	}
	
	public void setReceivedSkuQty(String skuqty) {
		fluentWait(editReceivedQty);
		elementClick(editReceivedQty);
		clearTextField(editReceivedQty);
		setText(editReceivedQty, skuqty);
		pressEnter();
	}

	private String getSkuNumberInDetailPage() {
     	return getText(skuNumberInDetailPage);
	}
   private String getQtyInDetailPage() {
		return getText(qtyInDetailPage);
	}

	public void editAndCancelReceivedSkuQtyAbove99(String skuQty) {
		clickOnCartonNumber();
		clickSkuNumber();
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setReceivedSkuQty(skuQty);
		logger.info("Edited Sku Qty Is "+ skuQty );
		pressEnter();
		int sizeOfReceivedQty = getText(editReceivedQty).length();
		logger.info("Length of received SKU QTY entered------> " + sizeOfReceivedQty);
		assertEquals(2, sizeOfReceivedQty);
		clickOnCancelButton();
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
	}
	
	@Step("Get Default Message")
	public String captureDefaultMessage()  {
		try {
			Thread.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getText(defaultMessage);	
	}

	public void validateUpdatedOrphanCartonDetailsFromDB(String orphanCartonNumber, String storeNumber, String updatedDamagedQty, String UpdatedReceivedQty ) {
		clickOnCartonNumber();
		String cartonNumberInAddSkuPage=getCartonNumberInAddSkuPage();
		Assert.assertEquals(cartonNumberInAddSkuPage, orphanCartonNumber);
		
		String QtyLabel = getQtyInDetailPage().substring(0,3);
		Assert.assertEquals(QtyLabel, "QTY");
		
		String skuLabel = getSkuNumberInDetailPage().substring(0,4);
		Assert.assertEquals(skuLabel, "SKU#");
		
		String skuNumberInDetailPage=getSkuNumberInDetailPage().substring(5);
		logger.info("Sku Number Displayed in Carton Detail Page is --> "+skuNumberInDetailPage);
		
		String skuQtyNumber = getQtyInDetailPage().substring(4);
		logger.info("Total Pending qty Displayed in Carton Detail Page is --> "+skuQtyNumber);
		
		clickSkuNumber();
		logger.info("To validate the sku labels displayed in the sku detail page");
		validateSkuLabel(softAssert);
		
		new ValidateFromMongoDB().validateUpdatedOrphanCartonDetailsFromDB(orphanCartonNumber,storeNumber,updatedDamagedQty, UpdatedReceivedQty);
		clickOnGoBackCartonDetailPage();
		clickOnGoBackInAddSku();
		
	}
	


}
