package com.pdt.Pom;
	import org.openqa.selenium.By;

import com.web.template.AndroidBasePage;

	public class SkuDetailTransferPage extends AndroidBasePage {
		
		protected By transferNumberOnSkuDetailPage=By.id("com.si:id/lblSendST_SKUDescDetails_TransferNo");
		protected By SkuNumberOnSkuDetailPage=By.id("com.si:id/liSendST_SKUDetails_SKUNo");
		protected By skuDescriptionLabelOnSkuDetails=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
		protected By skuDescriptionOnSkuDetailPage=By.xpath("com.si:id/liSendST_SKUDetails_SKUDesc");
		protected By skuQtyOnSkuDetailPage=By.id("com.si:id/liSendST_SKUDetails_SKUQty");
		protected By gobackBtnOnSkuDetailPage=By.id("com.si:id/btnViewSendST_SKUDescDetails_back");
		
		
		
		public String getTransferNumberOnSkuDetailPage()
		{
			return getText(transferNumberOnSkuDetailPage);
		}
		
		public String getSkuNumberOnSkuDetailPage()
		{
			return getText(SkuNumberOnSkuDetailPage);
		}
		
		public String getskuDescriptionOnSkuDetails()
		{
			return getText(skuDescriptionOnSkuDetailPage);
		}
		
		public String getskuQtyOnSkuDetailPage()
		{
			return getText(skuQtyOnSkuDetailPage);
		}
		
		public void clickGobackBtnOnSkuDetailPage()
		{
			fluentWait(gobackBtnOnSkuDetailPage);
			elementClick(gobackBtnOnSkuDetailPage);
		}
		
		

}
