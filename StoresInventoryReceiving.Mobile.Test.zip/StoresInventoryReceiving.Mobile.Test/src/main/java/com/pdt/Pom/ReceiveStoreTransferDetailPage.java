package com.pdt.Pom;

import org.openqa.selenium.By;

import com.web.template.AndroidBasePage;

public class ReceiveStoreTransferDetailPage extends AndroidBasePage{
	
	protected By transferNumber = By.id("com.si:id/lblST_SKUDetails_TransferNo");
	protected By totalPendingSkuQty=By.id("com.si:id/lblST_SKUDetails_PndngSKUQty");
	protected By skuNumber=By.id("com.si:id/liST_SKUDetails_SKUNo");
	protected By specificSkuQtyDetail=By.id("com.si:id/liST_SKUDetails_SKUQty");
	protected By goBackButton=By.id("com.si:id/btnST_SKUDetails_Back");
	protected By receiveStoreTransferHeading=By.id("com.si:id/lblST_TransferList_Header");
	protected By specificskuNumberList= By.xpath("//android.widget.TextView[@resource-id='com.si:id/liST_SKUDetails_SKUNo']");
	protected By specificSkuQty=By.xpath("//android.widget.TextView[@resource-id='com.si:id/liST_SKUDetails_SKUQty']");
	
	
	/*//used for SRA149 by ruthra
	public String getTransferNumberOnTransferDetailPage() {
		return getText(transferNumber);
	}
	
	//used for SRA149 by ruthra
	public String getTotalPendingSkuQtyOnTransferDetailPage() {
		return getText(totalPendingSkuQty);
	}
	
	//used for SRA149 by ruthra
	public String getSkuNumberOnTransferDetailPage() {
		return getText(skuNumber);
	}
	
	//used for SRA149 by ruthra
	public  String getSpecificSkuQtyOnTransferDetailPage() {
		return getText(specificSkuQtyDetail);
	}
	
	//used for SRA149 by ruthra
	public void clickGoBackButton()
	{
		elementClick(goBackButton);
	}
	
	//used for SRA149 by ruthra
	public String getTextOnReceiveTransferHomePage(){
		return getText(receiveStoreTransferHeading);
	}
	
	
	//used for SRA149 by ruthra
	public  ArrayList<MobileElement> getSkuNumberListOnTransferDetailPage() {
		return (ArrayList<MobileElement>) getListText(specificskuNumberList);
	}
	
	//used for SRA149 by ruthra
	public  List<MobileElement> getSkuQtyListOnTransferDetailPage() {
		return getListText(specificSkuQty);
	}
	*/
	

}


