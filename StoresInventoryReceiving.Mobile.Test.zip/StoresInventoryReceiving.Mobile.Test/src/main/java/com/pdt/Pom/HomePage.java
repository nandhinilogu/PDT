package com.pdt.Pom;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.web.template.AndroidBasePage;

public class HomePage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(HomePage.class.getName());
	protected By defaultMessagePrinterPage=By.id("com.si:id/SetUpPrinter_IpAddressMessage");
	protected By errorMessagePrinterPage=By.id("com.si:id/PrinterRegisteration_lblErrorMessage");
	protected By addButtonPrinterPage=By.id("com.si:id/PrinterRegisteration_btnAdd");
	protected By  goBackButtonPrinterPage=By.id("com.si:id/PrinterRegisteration_btnGoBack");
	protected By goBackButtonDCShipmentPage=By.id("com.si:id/btnDCShip_Home_Back");
	protected By goBackButtonPurchaseOrderPage=By.id("com.si:id/btnPO_Home_Back");
	protected By goBackButtonItemLookupPage=By.id("com.si:id/Ticketing_SKUDescDetails_btnGoBack");
	
	protected By goBackButton=By.id("com.si:id/PrinterRegisteration_btnGoBack");
	protected By dcShipmentHeading=By.id("com.si:id/txtToolbarTitle");
	protected By shipmentHeader=By.id("com.si:id/lblDCShip_Home_Header");
	protected By purchaseorderHeader=By.id("com.si:id/lblPO_Home_Header");
	protected By setUpPrinterHeader=By.id("com.si:id/PrinterRegisteration_SetUpPrinter_Header");
	protected By storeTransferOnSideMenuBar=By.xpath("//android.widget.TextView[normalize-space(@text)='Store Transfers']");
	protected By receivingHomeHeading=By.id("com.si:id/txtToolbarTitle");
	protected By receivingButton = By.id("com.si:id/btn_Home_Receiving");
	protected By storeReceivingHeader = By.id("com.si:id/navheader_Receiving");
	protected By homeHeader = By.id("com.si:id/txtToolbarTitle");
	
	protected By MainMenu = By.xpath("//android.widget.ImageButton[@content-desc='Open']");
	
	protected By HomeButtonOnSideMenuBar=By.xpath("//android.widget.TextView[@text='Home']");
	protected By ReceivingButtonOnMenuBar=By.xpath("//android.widget.TextView[@text='Receiving']");
	protected By DcShipmentOnSideMenuBar=By.xpath("//android.widget.TextView[normalize-space(@text)='DC Shipments']");
	protected By logoutButton = By.xpath("//android.widget.TextView[@text='Logout']");
	protected By purchaseOrdersOnSideMenuBar=By.xpath("//android.widget.TextView[normalize-space(@text)='Purchase Orders']");
	protected By StoreTransfer=By.xpath("//android.widget.TextView[normalize-space(@text)='Store Transfers']");
	
	protected By storeidOnSideMenu=By.id("com.si:id/navValue_StoreID");
	protected By associateIdOnSideMenu=By.id("com.si:id/navValue_AssociateID");
	
	private By storeLabel = By.id("com.si:id/lblLogin_StoreNo");
	protected By itemLookUp=By.id("com.si:id/btn_Home_PriceLookup");
	protected By auditing=By.id("com.si:id/btn_Home_Audit");
	protected By auditingButtonOnSideMenuBar=By.xpath("//android.widget.TextView[@text='Auditing']");
	protected By itemLookUpAndTicketingOnSideMenuBar =By.xpath("//android.widget.TextView[normalize-space(@text)='Item Lookup & Ticketing']");
	protected By setUpPrinterWifiOnSideMenuBar =By.xpath("//android.widget.TextView[normalize-space(@text)='Set-up Printer Wifi']");
	protected By setUpPrinterBluetoothOnSideMenuBar =By.xpath("//android.widget.TextView[normalize-space(@text)='Set-up Printer Bluetooth']");
	protected By setUpPrinterBluetoothHeading=By.id("com.si:id/lblPrinterRegisteration_Home_Header");
	protected By goBacksetUpPrinterBluetooth=By.id("com.si:id/btnPrinterRegisteration_Home_Back");
	protected By pairDevicesetUpPrinterBluetooth=By.id("com.si:id/btnPrinterRegisteration_PairDevice");
	
	public String captureReceivingHeading() {
		return getText(dcShipmentHeading);
	}
	public String captureShipmentHeading() {
		return getText(shipmentHeader);
	}
	public String capturePurchaseOrderHeading() {
		return getText(purchaseorderHeader);
	}
	public String captureSetUpPrinterHeading() {
		return getText(setUpPrinterHeader);
	}
	
	public String captureHeadingInMenuBar() {
		return getText(storeReceivingHeader);
	}
	public String captureHeadingInHomePage() {
		return getText(homeHeader);
	}
	public String captureHeadingInReceivingHomePage() {
		return getText(receivingHomeHeading);
	}
	
	
	public void clickOnAuditingOnSideMenuBar() {
		logger.info("Clicking on Auditing");
		elementClick(auditingButtonOnSideMenuBar);
	}
	
	public void clickOnHomeOnSideMenuBar() {
		logger.info("Clicking on Home Button");
		elementClick(HomeButtonOnSideMenuBar);
	}
	
	public void clickOnReceivingOnSideMenuBar() {
		logger.info("Clicking on Receiving Button");
		elementClick(ReceivingButtonOnMenuBar);
	}
	
	
	
	
	
	
	public void clickOnDCShipmentsOnSideMenuBar() {
		fluentWait(DcShipmentOnSideMenuBar);
		elementClick(DcShipmentOnSideMenuBar);
	}
	
	public void clickOnReceiving() {
		while(isDisplayedWithoutWait(receivingButton)) {
			logger.info("Clicking on Receiving Button");
			elementClick(receivingButton);
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
			}
		}
		
	}

	public void clickOnMenuBar() {
		logger.info("Clicking on Menu Bar");
		elementClick(MainMenu);
		fluentWait(logoutButton);
	}
	
	public boolean isMenuBarDisplayed(){
		return isDisplayedWithoutWait(MainMenu);
	}

	public void logout() {
		elementClick(logoutButton);
		fluentWait(storeLabel);
	}
	public boolean islogoutDisplayed() {
		return isDisplayed(logoutButton);
	}
	
	public boolean isHomeScreen() {
	  return isDisplayed(receivingButton);
	}
	
	public String storeIDValue() {
		return getText(storeidOnSideMenu);
	}
	
	public String associateIdValue() {
		return getText(associateIdOnSideMenu);
	}
	
	public boolean isItemLookUpDisplayed() {
		return isDisplayed(itemLookUpAndTicketingOnSideMenuBar);
	}
	
	public boolean isSetUpPrinterDisplayed() {
		return isDisplayed(setUpPrinterWifiOnSideMenuBar);
	}
	
	
	public boolean isReceivingInHomeDisplayed() {
		return isDisplayed(receivingButton);
	}
	public boolean isAuditingInHomeDisplayed() {
		return isDisplayed(auditing);
	}
	public boolean isItemLookupInHomeDisplayed() {
		return isDisplayed(itemLookUp);
	}
	public boolean isHomeDisplayed() {
		return isDisplayed(HomeButtonOnSideMenuBar);
	}
	public boolean isReceivingDisplayed() {
		return isDisplayed(ReceivingButtonOnMenuBar);
	}
	
	public boolean isDCShipmentDisplayed() {
		return isDisplayed(DcShipmentOnSideMenuBar);
	}
	public boolean isPurchaseOrderDisplayed() {
		return isDisplayed(purchaseOrdersOnSideMenuBar);
	}
	public boolean isStoreTransfersDisplayed() {
		return isDisplayed(storeTransferOnSideMenuBar);
	}
	
	
	public boolean isAuditingDisplayed() {
		return isDisplayed(auditingButtonOnSideMenuBar);
	}
//	public void clickOnAuditing() {
//		while(isDisplayedWithoutWait(auditing)) {
//			elementClick(auditing);
//			try {
//				Thread.sleep(2);
//			} catch (InterruptedException e) {
//			}
//		}
//	}
	
	public void clickOnAuditing(){
		logger.info("Clicking on Auditing Button");
		elementClick(auditing);
		
	}
	public void clickOnSetUpPrinterOnSideMenuBar(){
		elementClick(setUpPrinterWifiOnSideMenuBar);
	}
	public void clickOnSetUpPrinterBluetoothOnSideMenuBar(){
		elementClick(setUpPrinterBluetoothOnSideMenuBar);
	}
	
	public void clickOnStoreTransferOnSideMenuBar() {
		elementClick(storeTransferOnSideMenuBar);
	}

	public void clickOnPurchaseOrdersOnSideMenuBar() {
		elementClick(purchaseOrdersOnSideMenuBar);
		
	}
	
	public void clickOnItemLookUpAndTicketingOnSideMenuBar() {
		elementClick(itemLookUpAndTicketingOnSideMenuBar);
	}
	public void navigateToDCShipmentsOnSideMenuBar(SoftAssert localassert) {
		logger.info("Navigate to DC shipment home Page from side menu bar");
		HomePage homeScreen=new HomePage();
		homeScreen.clickOnMenuBar();
		clickOnDCShipmentsOnSideMenuBar();
		String displayedToolBarHeading=captureReceivingHeading();
		localassert.assertEquals(displayedToolBarHeading, "DC SHIPMENT");
		logger.info(displayedToolBarHeading +" Heading is Displayed in the Receiving Home Page");
		
		String shipmentHeading=captureShipmentHeading();
		localassert.assertEquals(shipmentHeading, "Shipment");
		logger.info(shipmentHeading +" Heading is Displayed in the Receiving Home Page");
		clickOnGoBackButtonInDCShipmentPage();
		
	}
	public void navigateToPurchaseOrdersOnSideMenuBar(SoftAssert localassert) {
		logger.info("Navigate to purchase Order home Page from side menu bar");
		HomePage homeScreen=new HomePage();
		homeScreen.clickOnMenuBar();
		clickOnPurchaseOrdersOnSideMenuBar();
		String displayedToolBarHeading=captureReceivingHeading();
		localassert.assertEquals(displayedToolBarHeading, "PURCHASE ORDERS");
		logger.info(displayedToolBarHeading +" Heading is Displayed in the DC Shipment Home Page");
		
		String purchaseOrderHeading=capturePurchaseOrderHeading();
		localassert.assertEquals(purchaseOrderHeading, "Purchase Orders");
		logger.info(purchaseOrderHeading +" Heading is Displayed in the Purchase order Home Page");
		clickOnGoBackButtonInPurchaseOrderPage();
		
	}
	public void navigateToStoreTransfersOnSideMenuBar(SoftAssert localassert) {
		logger.info("Navigate to Send Transfers home Page from side menu bar");
		SendAndReceiveTransferPage sendnReceivetransfer = new SendAndReceiveTransferPage();
		HomePage homeScreen=new HomePage();
		homeScreen.clickOnMenuBar();
		clickOnStoreTransferOnSideMenuBar();
		String StoreTransfersHeading=sendnReceivetransfer.captureStoreTransfersHeader();
		localassert.assertEquals(StoreTransfersHeading, "STORE TRANSFER");
		logger.info(StoreTransfersHeading +" Heading is Displayed");
		sendnReceivetransfer.isSendTransfersButtonDisplayed();
		sendnReceivetransfer.isReceiveTransfersButtonDisplayed();
		
	}
	public void navigateToSetupPrinterWifiOnSideMenuBar(SoftAssert localassert) {
		HomePage homeScreen=new HomePage();
		homeScreen.clickOnMenuBar();
		homeScreen.clickOnSetUpPrinterOnSideMenuBar();
		String displayedToolBarHeading=captureReceivingHeading();
		localassert.assertEquals(displayedToolBarHeading, "SET-UP PRINTER");
		logger.info(displayedToolBarHeading +" Heading is Displayed in the SetUp Printer Home Page");
		
		String setUpPrinterHeading=captureSetUpPrinterHeading().substring(0, 14);
		localassert.assertEquals(setUpPrinterHeading, "Set Up Printer");
		logger.info(setUpPrinterHeading +" Heading is Displayed in the Purchase order Home Page");
		
		String defaultMessage=captureDefaultMessageInPrinterPage();
		localassert.assertEquals(defaultMessage, "Please Enter Valid IP Address");
		logger.info(defaultMessage +" Default Message Displayed in SetUp Printer Home Page");
		clickOnAddButtonInPrinterPage();
		String errorMessage=captureErrorMessageInPrinterPage();
		localassert.assertEquals(errorMessage, "Please enter valid IP Address");
		logger.info(errorMessage +" Error Message Displayed in SetUp Printer Home Page");
		clickOnGoBackButtonInPrinterPage();
		String displayedToolBarTitle=homeScreen.captureHeadingInHomePage();
		localassert.assertEquals(displayedToolBarTitle, "HOME");
		logger.info(displayedToolBarTitle +" Heading is Displayed in the Home Page");
	}
	public void navigateToSetupPrinterBluetoothOnSideMenuBar(SoftAssert localassert) {
		HomePage homeScreen=new HomePage();
		homeScreen.clickOnMenuBar();
		homeScreen.clickOnSetUpPrinterBluetoothOnSideMenuBar();
		String displayedToolBarHeading=captureReceivingHeading();
		localassert.assertEquals(displayedToolBarHeading, "REGISTER PRINTER");
		logger.info(displayedToolBarHeading +" Heading is Displayed in the SetUp Printer Home Page");
		
		String setUpPrinterBluetoothHeading=captureSetUpPrinterUsingBluetoothHeading();
		localassert.assertEquals(setUpPrinterBluetoothHeading, "Set-Up Printer using Bluetooth");
		logger.info(setUpPrinterBluetoothHeading +" Heading is Displayed in the Purchase order Home Page");
		localassert.assertTrue(isDisplayed(goBacksetUpPrinterBluetooth));
		localassert.assertTrue(isDisplayed(pairDevicesetUpPrinterBluetooth));
	}
	
	private String captureSetUpPrinterUsingBluetoothHeading() {
		return getText(setUpPrinterBluetoothHeading);
	}
	private void clickOnGoBackButtonInPrinterPage() {
		elementClick(goBackButtonPrinterPage);
		
	}
	private void clickOnGoBackButtonInDCShipmentPage() {
		elementClick(goBackButtonDCShipmentPage);
		
	}
	private void clickOnGoBackButtonInPurchaseOrderPage() {
		elementClick(goBackButtonPurchaseOrderPage);
		
	}
	private void clickOnGoBackButtonInItemLookupPage() {
		elementClick(goBackButtonItemLookupPage);
		
	}
	private String captureErrorMessageInPrinterPage() {
		return getText(errorMessagePrinterPage);
	}
	private void clickOnAddButtonInPrinterPage() {
		elementClick(addButtonPrinterPage);
		
	}
	private String captureDefaultMessageInPrinterPage() {
		return getText(defaultMessagePrinterPage);
	}
	public void validateMenuIconsInSideMenuBar() {
		isHomeDisplayed();
		isReceivingDisplayed();
		isDCShipmentDisplayed();
		isStoreTransfersDisplayed();
		isPurchaseOrderDisplayed();
		isAuditingDisplayed();
		isItemLookUpDisplayed();
		isSetUpPrinterDisplayed();
		islogoutDisplayed();
	}
	public void navigateToHomePageOnSideMenuBar(SoftAssert localassert) {
		   clickOnHomeOnSideMenuBar();
		   String displayedToolBarTitle=captureHeadingInHomePage();
		   localassert.assertEquals(displayedToolBarTitle, "HOME");
		   logger.info(displayedToolBarTitle +" Heading is Displayed in the Home Page");	
			
			logger.info("To validate if all the major icons are displayed in the Home Page");
			isReceivingInHomeDisplayed();
			isAuditingInHomeDisplayed();
			isItemLookupInHomeDisplayed();
	}
	
	public void navigateToReceivingPageOnSideMenuBar(SoftAssert localassert) {
		HomePage homeScreen=new HomePage();
		ReceivingPage receivingPage=new ReceivingPage();
		clickOnMenuBar();
		clickOnReceivingOnSideMenuBar();
		String displayedReceivingTitle=homeScreen.captureHeadingInReceivingHomePage();
		localassert.assertEquals(displayedReceivingTitle, "RECEIVING HOME");
		logger.info(displayedReceivingTitle +" Heading is Displayed in the Receiving Home Page");	
		
		receivingPage.isDcShpmentDisplayed();
		receivingPage.isPurchaseOrdersDisplayed();
		receivingPage.isStoreToStoreTransferDisplayed();
	}
	public void navigateToAuditingPageOnSideMenuBar(SoftAssert localassert) {
		HomePage homeScreen=new HomePage();
		AuditingPage auditingPage = new AuditingPage();
		homeScreen.clickOnMenuBar();
		homeScreen.clickOnAuditingOnSideMenuBar();
		String AuditingHeader= auditingPage.captureAuditingHeader();
		localassert.assertEquals(AuditingHeader, "AUDITING");
		logger.info(AuditingHeader +" Heading is Displayed");	
		
		auditingPage.isInTransitDamagesBtnExist();
		auditingPage.isStoreDamagesDisplayed();
		auditingPage.isMispicksDisplayed();
		
	}
	public void navigateToItemLookUpPageOnSideMenuBar(SoftAssert softassert) {
		HomePage homeScreen=new HomePage();
		MobileTicketingPage mobileTicketing=new MobileTicketingPage();
		homeScreen.clickOnMenuBar();
		homeScreen.clickOnItemLookUpAndTicketingOnSideMenuBar();
		mobileTicketing.IsItemLookUpHeadingDisplayed();
		mobileTicketing.IsTicketingHeadingDisplayed(softassert);
		clickOnGoBackButtonInItemLookupPage();
	}
	public void clickOnItemLookUp() {
		logger.info("Clicking on itemLookup");	
		elementClick(itemLookUp);
		
	}
	
	
	

}
