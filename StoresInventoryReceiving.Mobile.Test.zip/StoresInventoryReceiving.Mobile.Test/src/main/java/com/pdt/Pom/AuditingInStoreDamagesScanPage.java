package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.text.ParseException;
import java.time.Duration;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;
import com.web.template.BaseTest;

import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class AuditingInStoreDamagesScanPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(BaseTest.class.getName());
	SoftAssert softAssert = new SoftAssert();
	
	
	// In-store Damages Home page  ---In Store Damages ---Start Scanning to see damaged SKUs
	protected By instoreDamagesHeading=By.id("com.si:id/lblAuditISD_Home_Header");
	protected By defaultMessageHomePage=By.id("com.si:id/lblAuditISD_Home_ScanMsg");
	protected By addButton=By.id("com.si:id/btnAuditISD_Home_Add");
	protected By damagedSku=By.id("com.si:id/liAuditISD_Home_SKUNo");
	protected By gobackButtonHomePage=By.id("com.si:id/btnAuditISD_Home_Back");
	protected By scaniconHomePage=By.id("com.si:id/imgAuditISD_Home");
	
	// Manually adding sku page ---SKU Number not found---
	protected By addDamagesSkusHeading=By.id("com.si:id/lblAuditISD_AddSKU_Header");
	protected By searchButton=By.id("com.si:id/search_button");
	protected By skuTextBox=By.id("com.si:id/search_src_text");
	protected By closebuttonTextBox=By.id("com.si:id/search_close_btn");
	protected By skuNumberInAddingPage=By.id("com.si:id/lblAuditISD_AddSKU_SKUNumber");
	protected By skuDescriptionInAddingPage=By.id("com.si:id/lblAuditISD_AddSKU_SKUDescription");
	protected By addButtonOnBottom=By.id("com.si:id/btnAuditISD_AddSKU_Add");
	protected By add3SkuDigits=By.id("com.si:id/EdtCartonDigits");
	protected By enterButton=By.id("com.si:id/btnEnter");
	protected By gobackAddingPage=By.id("com.si:id/btnAuditISD_AddSKU_Back");
	protected By inStoreDamagesView=By.id("com.si:id/layout_damage");
	protected By damageSummery=By.id("com.si:id/layout_damage");
	protected By searchBarAddDamagedSku=By.id("com.si:id/search_bar");
	
	// Sku Detail page
	protected By skuNumberHeadingDetailPage=By
			.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescriptionHeadingDetailPage=By
			.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By damagedSkuQtyHeadingDetailPage=By
			.xpath("//android.widget.TextView[normalize-space(@text)='Damaged SKU QTY']");
	protected By skuNumberDetailpage=By.id("com.si:id/liAuditISD_SKUDetails_SKUNo");
	protected By skuDescriptionDetailpage=By.id("com.si:id/liAuditISD_SKUDetails_SKUDesc");
	protected By damagedSkuQtyDetailpage=By.id("com.si:id/liAuditISD_SKUDetails_SKUQty");
	protected By goBackDetailpage=By.id("com.si:id/btnAuditISD_SKUDetails_Back");
	
	// Sku Edit page
	protected By editIcon=By.id("com.si:id/imgAuditISD_SKUDetails_Edit");
	protected By editDamagedQty=By.id("com.si:id/txtAuditISD_EditSKU_SKUQty");
	protected By saveButton=By.id("com.si:id/btnAuditISD_EditSKU_Save");
	protected By cancelButton=By.id("com.si:id/btnAuditISD_EditSKU_Cancel");
	protected By alertPopUpForZeroQty = By.id("android:id/message");
	protected By okButtonAlertPopUp = By.id("android:id/button1");
	
	public void initiateInStoreDamages(String sKuNumber) {
		clickOnAddButton();
		enterSku(sKuNumber);
		clickAddButtonInManualPage();
		add3SkuDigits();	
	}
	
	public void createInStoreDamages(String sKuNumber,SoftAssert localassert) {
		clickOnAddButton();
		isAddSkusHeadingDisplayed();
		enterSku(sKuNumber);
		clickAddButtonInManualPage();
		String displayedSkuNumber=captureSkuNumberInHomePage();
		localassert.assertEquals(displayedSkuNumber, sKuNumber);
		logger.info("Sku Number added to the In-store damages screen is "+displayedSkuNumber);
	}
	public void validateErrorMessageForInvalidSkuNumber(String sKuNumber,SoftAssert localassert) {
		clickOnAddButton();
		enterSku(sKuNumber);
		String ErrorMessageForInvalidSku=captureErrorMessage(sKuNumber);
		localassert.assertEquals(ErrorMessageForInvalidSku, "SKU Number not found");
		logger.info("Error message Displayed for Invalid Sku number is "+ErrorMessageForInvalidSku);
	}
	public void validateErrorMessageForDuplicateSkuNumber(String sKuNumber,SoftAssert localassert) {
		clickOnCloseButtonInTextBox();
		setText(skuTextBox, sKuNumber);
		clickSearchButton();
		String ErrorMessageForDuplicateSku=captureErrorMessage(sKuNumber);	
		localassert.assertEquals(ErrorMessageForDuplicateSku, "Duplicate SKU number. Please try again");
		logger.info("Error message Displayed for Duplicate Sku number is "+ErrorMessageForDuplicateSku);
	}
	
	
	
	public void enterSku(String skuNumber) {
		elementClick(searchButton);
		setText(skuTextBox, skuNumber);
		clickSearchButton();
		
	}
	
	public String captureErrorMessage(String skuNumber) {
		return getText(skuNumberInAddingPage);
	}
//	public void clickSearchButton() {
//		pressEnter();
//	}
	public void clickSearchButton() {
		TouchAction touchAction=new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();
		//pressEnter();
	}
	public void clickOnSkuNumber() {
		elementClick(damagedSku);
	}
	public String captureSkuNumberInHomePage() {
		return getText(damagedSku).substring(5);
	}
	public void clickOnGoBackDetailPage() {
		elementClick(goBackDetailpage);
	}
	
	public void clickOnAddButton() {
		elementClick(addButton);
	}
	public void clickOnCloseButtonInTextBox() {
		elementClick(closebuttonTextBox);
	}
	
	public boolean isPlusSignDisplayed() {
		return isDisplayed(addButton);
	}
	public boolean isAddSkusHeadingDisplayed() {
		return isDisplayed(addDamagesSkusHeading);
	}
	public boolean isInStoreDamagesHeadingDisplayed() {
		return isDisplayed(instoreDamagesHeading);
	}
	
	public void clickAddButtonInManualPage() {
		elementClick(addButtonOnBottom);
	}

	public void add3SkuDigits() {
		setText(add3SkuDigits, "517");
		elementClick(enterButton);
	}
	
	public boolean isSkuNumberHeadingDisplayed() {
		return isDisplayed(skuNumberHeadingDetailPage);
		
	}
	public boolean isSkuDescriptionHeadingDisplayed() {
		return isDisplayed(skuDescriptionHeadingDetailPage);
		
	}
	public boolean isDamagedSkuQtyHeadingDisplayed() {
		return isDisplayed(damagedSkuQtyHeadingDetailPage);
		
	}
	public boolean isDamageSummeryDisplayed() {
		return isDisplayed(damageSummery);
		
	}



	public boolean isSearchBarAddDamagedSkuDisplayed() {
		return isDisplayed(searchBarAddDamagedSku);
		
	}
	
	@Step("Verify if Default message is displayed")
	public boolean isDefaultMessageDisplayed() {
		return isDisplayedWithoutWait(defaultMessageHomePage);
	}
	
	@Step("To capture the default message displayed in the home page")
	public String captureDefaultMessage()  {
		try {
			Thread.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getText(defaultMessageHomePage);	
	}
	public String captureSkuNumberInAddSKuPage() {
		return getText(skuNumberInAddingPage);
	}
	public String captureSkuDescriptionInAddSKuPage() {
		return getText(skuDescriptionInAddingPage);
	}
	public String captureSkuNumberInDetailPage() {
		return getText(skuNumberDetailpage);
	}
	public String captureSkuDescriptionInDetailPage() {
		return getText(skuDescriptionDetailpage);
	}
	public String captureDamagedSkuQtyInDetailPage() {
		return getText(damagedSkuQtyDetailpage);
	}
	
	@Step("Verify if In-store Damaged sku is displayed")
	public boolean isDamagedSkuDisplayed() {
		return isDisplayed(damagedSku);
	}
	@Step("Verify if added sku number from json file is displayed")
	public boolean isDamagedSkuFromJsonIsDisplayed() {
		String displayedSkuNumber = getText(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #1119995']"));
		logger.info("Displayed In-Store Damaged Sku is "+displayedSkuNumber);
		return isDisplayed(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #1119995']"));
	}

	@Step("Verify if added sku number from json file is not displayed")
	public void isDamagedSkuFromJsonIsNotDisplayed(String carton) {
		assertFalse(isDisplayedWithoutWait(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+carton+"']")));
		logger.info("Given In-Store damaged sku is not displayed");
	}

	public void ValidateSkuDetailsOfDamageMarkedSku(String SkuNumber) throws ParseException {
		ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
		clickOnAddButton();
		isAddSkusHeadingDisplayed();
		enterSku(SkuNumber);
		String searchedSkuNumber=captureSkuNumberInAddSKuPage();
		String searchedSkuDescription=captureSkuDescriptionInAddSKuPage();
		clickAddButtonInManualPage();	
	   logger.info("Sku Number added to the In-store damages screen is "+SkuNumber);
	   clickOnSkuNumber();
	   logger.info("To validate the sku labels displayed in the sku detail page");
	   isSkuNumberHeadingDisplayed();
	   isSkuDescriptionHeadingDisplayed();
	   isDamagedSkuQtyHeadingDisplayed();
	   logger.info("All the sku labels are displayed in the sku detail page");
	   
	   String displayedSkunumber=captureSkuNumberInDetailPage();
	   String displayedSkuDescription=captureSkuDescriptionInDetailPage();
	   String displayedDamagedSkuQty=captureDamagedSkuQtyInDetailPage();
	   softAssert.assertEquals(searchedSkuNumber, displayedSkunumber);
	   softAssert.assertEquals(searchedSkuDescription, displayedSkuDescription);
	   softAssert.assertEquals("1", displayedDamagedSkuQty);
	   logger.info("SkuNumber " + displayedSkunumber + " SkuDescription "
				+ displayedSkuDescription + " Damaged Sku Qty " +displayedDamagedSkuQty);
	   validateFromMongoDB.validateSkuDetailsForDamageMarkedSku(SkuNumber,softAssert);
	   
//	     To validate Instore Damages heading displayed in home page while clicking on Go Back in the Sku detail page
	   clickOnGoBackDetailPage();
	   isInStoreDamagesHeadingDisplayed();
	   softAssert.assertAll();
	}

	public void editAndSaveDamagedSkuQty(String skuNumber, String damagedQty, SoftAssert localassert) {
		elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #"+skuNumber+"']"));
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Sku Qty Is "+ damagedQty );
		clickOnSaveButton();
		String DisplayedSkuQty = captureDamagedSkuQtyInDetailPage();
		logger.info("Saved Sku Qty Is "+ DisplayedSkuQty );
		localassert.assertEquals(damagedQty, DisplayedSkuQty);
		clickOnGoBackDetailPage();
	}

	public void clickOnSaveButton() {
		elementClick(saveButton);	
	}
	public void clickOnCancelButton() {
		elementClick(cancelButton);	
	}

	private void setDamagedSkuQty(String damagedQty) {
		fluentWait(editDamagedQty);
		elementClick(editDamagedQty);
		clearTextField(editDamagedQty);
		setText(editDamagedQty, damagedQty);
		pressEnter();
	}

	private void clickOnEditButton() {
		elementClick(editIcon);
		}

	public void editAndCancelDamagedSkuQty(String skuNumber, String damagedQty, SoftAssert localassert) {
		elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #"+skuNumber+"']"));
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Sku Qty Is "+ damagedQty );
		clickOnCancelButton();
		String DisplayedSkuQty = captureDamagedSkuQtyInDetailPage();
		logger.info("canceled sku qty edit "+ DisplayedSkuQty );
		localassert.assertNotEquals(damagedQty, DisplayedSkuQty);
		clickOnGoBackDetailPage();
	}
	public void editAndSaveDamagedSkuQtyAbove99(String skuNumber, String damagedQty, SoftAssert localassert) {
		elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #"+skuNumber+"']"));
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Sku Qty Is "+ damagedQty );
		int sizeOfReceivedQty = getText(editDamagedQty).length();
		logger.info("Length of received SKU QTY entered------> " + sizeOfReceivedQty);
		localassert.assertEquals(2, sizeOfReceivedQty);
		clickOnSaveButton();
		clickOnGoBackDetailPage();
	}

	public String captureAlertMessageForZeroQty() {
		return getText(alertPopUpForZeroQty);
	}
	public void clickOnOkForAlertPopUp() {
		elementClick(okButtonAlertPopUp);
	}

	public void validateErrorMessageForDamagedQty0(String skuNumber, String damagedQty, SoftAssert localassert) {
		elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #"+skuNumber+"']"));
		WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
						.withDuration(Duration.ofMillis(500)))
				.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
				.release().perform();
		clickOnEditButton();
		setDamagedSkuQty(damagedQty);
		logger.info("Edited Sku Qty Is "+ damagedQty );
		clickOnSaveButton();
		String AlertMessage=captureAlertMessageForZeroQty();
		Assert.assertEquals(AlertMessage, "Please enter valid SKU Quantity");
		logger.info("Displayed Alert message is------> " + AlertMessage);
		clickOnOkForAlertPopUp();
		clickOnCancelButton();
		clickOnGoBackDetailPage();
	}
	}
	
	

