package com.pdt.Pom;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.util.DataBase.ValidateFromMongoDB;
import com.web.template.AndroidBasePage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import ru.yandex.qatools.allure.annotations.Step;

public class MispicksScanPage extends AndroidBasePage {
	final static Logger logger = Logger.getLogger(MispicksScanPage.class.getName());
	
	protected By clickOnOkOnNetworkErrorMsg=By.id("android:id/button1");
	protected By mispicksHeader = By.xpath("//android.widget.TextView[normalize-space(@text)='Mispicks']");
	protected By addButton = By.id("com.si:id/btnAuditMad_Home_Add");
	protected By addCartonHeader = By.id("com.si:id/lblAuditMAD_AddCarton_Header");
	protected By searchButton = By.id("com.si:id/search_bar");
	protected By addMispicksTextBox = By.id("com.si:id/search_src_text");
	protected By addButtonOnBottom = By.id("com.si:id/btnAuditMAD_AddCarton_Add");
	protected By cartonNumberInAddCartonPage = By.id("com.si:id/lblAuditMAD_AddCarton_CartonNo");
	protected By cartonNumberDoesNotMatchMsg = By.id("com.si:id/lblPopUpErrorMsg");
	protected By enter4LastDigits = By.id("com.si:id/txtPopUpTemplateNum");
	protected By enter4LastDigitsMessage = By.id("com.si:id/lblPopUpTemplateMsg");
	//..Incorrect Entry. Please enter again
	protected By clickEnterPopUpBox = By.id("com.si:id/btnPopUpEnter");
	protected By clickCancelPopUpBox = By.id("com.si:id/btnPopUpCancel");
	protected By mispickCarton=By.id("com.si:id/listAuditMAD_Home");
	protected By CartonNumberMispicksScanPage=By.id("com.si:id/liAuditMAD_Home_CartonNo");
	protected By arrowImageMispicksScanPage=By.id("com.si:id/liAuditMAD_Home_ArrowImage");
	protected By submitMispicksButton=By.id("com.si:id/btnAuditMad_Home_Submit");
	protected By networkConnectivityErrorMessage=By.id("android:id/message");
	
	
	protected By savebutton = By.id("com.si:id/btnAuditMAD_EditSKU_Save");
	protected By cancelbutton = By.id("com.si:id/btnAuditMAD_EditSKU_Cancel");
	protected By editSkuQty=By.id("com.si:id/txtAuditMAD_EditSKU_SKUQty");
	protected By editButtonCartonDetailPage=By.id("com.si:id/imgAuditMad_CartonDetails_Edit");
	protected By addButtonCartonDetailPage=By.id("com.si:id/btnAuditMAD_CartonDetails_Add");
	protected By goBackCartonDetailPage=By.id("com.si:id/btnAuditMAD_CartonDetails_Back");
	protected By cartonNumberCartonDetailPage=By.id("com.si:id/lblAuditMAD_CartonDetails_Header");
	
	protected By skuNumberCartonDetailPage=By.id("com.si:id/liAuditMAD_CartonDetails_SKUNumber");
	protected By skuDescriptionCartonDetailPage=By.id("com.si:id/liAuditMAD_CartonDetails_SKUDesc");
	protected By skuQtyCartonDetailPage=By.id("com.si:id/liAuditMAD_CartonDetails_SKUQty");
	protected By receivedQtyCartonDetailPage=By.id("com.si:id/liAuditMAD_CartonDetails_RecQty");
	protected By specialHandlingCartonDetailPage=By.id("com.si:id/liAuditMAD_CartonDetails_SplHandling");
	protected By addSkuToCartonHeader=By.id("com.si:id/lblAuditMAD_AddSKU_Header");
	protected By searchBarAddSkuPage=By.id("com.si:id/search_src_text");
	protected By closeButtonSearchBar=By.id("com.si:id/search_close_btn");

	protected By searchButtonAddSkuPage=By.id("com.si:id/search_button");
	
	protected By skuNumberAddSkuPage=By.id("com.si:id/lblAuditMAD_AddSKU_SKUNo");
	protected By  skuDescriptionAddSkuPage=By.id("com.si:id/lblAuditMAD_AddSKU_SKUDesc");
	protected By  skuNumberInDetailPage=By.id("com.si:id/liAuditMAD_SKUDetails_SKUNo");
	
	protected By  qtyInDetailPage=By.id("com.si:id/liMAD_SKUDetails_SKUQty");
	protected By  addButtonAddSkuPage=By.id("com.si:id/btnAuditMAD_AddSKU_Add");
	protected By  goBackButtonAddSkuPage=By.id("com.si:id/btnAuditMAD_AddSKU_Back");
	protected By duplicateerrormessage = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Duplicate SKU number. Please try again']");
	protected By invaliderrormessage = By
			.xpath("//android.widget.TextView[normalize-space(@text)='SKU Number not found']");
	protected By defaultmessageInScanPage = By
			.xpath("//android.widget.TextView[normalize-space(@text)='Start scanning to add cartons for Mispicks and Discrepancies']");
	protected By defaultmessage = By.id("com.si:id/lblAuditMAD_Home_ScanMsg");
	
	//protected By cartonLabel = By.id("com.si:id/lblAuditMAD_Home_ScanMsg");
	protected By skuLabel = By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']");
	protected By skuDescLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU Description']");
	protected By skuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='SKU QTY']");
	protected By receivedSkuQtyLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Received SKU QTY']");
	protected By specialHandlingLabel=By.xpath("//android.widget.TextView[normalize-space(@text)='Special Handling']");
	
	
	SoftAssert softassert = new SoftAssert();

	
	public void initiate_MisPickForUnsavedData(String cartonNumber) throws ParseException {
		//String cartonNumber = getCartonNumber(storeNumber);
		clickAddButton();
		addCartonNumberForMisPick(cartonNumber);
		clickAddButtonOnBottom();
		add4LastCartonDigits(cartonNumber);
		clickEnterButton();
		
	}
	@Step("Verify Mispicked carton number is displayed")
	public boolean isCartonDisplayed() {
		return isDisplayed(mispickCarton);
	}
	
	@Step("Verify if Default message is displayed")
	public boolean isDefaultMessageDisplayed() {
		return isDisplayedWithoutWait(defaultmessage);
	}
	
	@Step("Verify if added carton number from json file is displayed")
	public boolean isMispickedCartonDisplayed(String cartonNumber) {
		String displayedCartonNumber = getText(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
		logger.info("Displayed mispicked carton is "+displayedCartonNumber);
		return isDisplayed(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));
	}
	
	
	@Step("Verify if added carton number from json file is not displayed")
	public void isMispickedCartonNotDisplayed(String cartonNumber) {
		assertFalse(isDisplayedWithoutWait(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']")));
		logger.info("Given mispicked carton is not displayed");
	}
	
	
	
	
	@Step("Verify Mispicked carton number is not displayed")
	public void verifyMispickedCartonIsNotDisplayed() {
		assertFalse(isDisplayedWithoutWait(mispickCarton));
		logger.info("Given mispicked carton is not displayed");
	}

	public void clickEnterButton() {
		elementClick(clickEnterPopUpBox);

	}
	public void clickCancelPopupButton() {
		elementClick(clickCancelPopUpBox);

	}

	public void clickOnSubmitMispicksButton() {
		elementClick(submitMispicksButton);

	}
	public String getNetworkConnectivityMessage() {
		return getText(networkConnectivityErrorMessage);
		
	}
	
	

	public void addCartonNumberForMisPick(String cartonNumber) {
		logger.info("Entering Carton Number");
        elementClick(searchButton);
		setText(addMispicksTextBox, cartonNumber);
		clickSearchButton();
	}

	

	public void clickAddButtonOnBottom() {
		elementClick(addButtonOnBottom);
	}

	public void clickAddButton() {
		elementClick(addButton);
	}
	public void clickOnCartonNumber() {
		logger.info("Clicking on Carton Number");
		driver.findElements(CartonNumberMispicksScanPage).get(0).click();
	}
	public void clickAddButtonInCartonDetailPage() {
		elementClick(addButtonCartonDetailPage);
	}
	public void clickAddIconInAddSkuPage() {
		elementClick(addButtonAddSkuPage);
	}
	public void clickOnGoBackInAddSkuPage() {
		elementClick(goBackButtonAddSkuPage);
	}
	public void clickOnEditButton() {
		elementClick(editButtonCartonDetailPage);
	}
	public void clickOnSaveButton() {
		elementClick(savebutton);
	}
	public void clickOnCancelButton() {
		elementClick(cancelbutton);
	}
	public void clickOnCloseButtonInSearchBar() {
		elementClick(closeButtonSearchBar);
	}
	
	public void clickOnGoBackCartonDetailPage() {
		logger.info("Clicking On Go Back Button");
		elementClick(goBackCartonDetailPage);
	}

	public void clickSearchButton() {
		TouchAction touchAction=new TouchAction(driver);
		touchAction.tap(PointOption.point(700, 1200)).perform();
		//pressEnter();
	}
	public String getCartonNumberDoesNotMatchMessage() {
		return getText(cartonNumberDoesNotMatchMsg);
	}
	public String captureEnter4DigitsMessage() {
		return getText(enter4LastDigitsMessage);
	}

	public void add4LastCartonDigits(String cartonNumber) {
		logger.info("Entering Last 4 Carton Number");
		setText(enter4LastDigits, cartonNumber.substring(cartonNumber.length() - 4, cartonNumber.length()));

	}
	public void reEnter4CartonDigitsIncorrectly(String cartonNumber) {
		logger.info("Entering Last 4 Carton Number");
		setText(enter4LastDigits, cartonNumber.substring(cartonNumber.length() - 3, cartonNumber.length()));
	}
	// Created by Ovi For SRA-801
		public void addMispickedCarton(String cartonNumber) throws ParseException {
			logger.info("Add a Valid carton Number To the Mispicks Home Screen");
			clickAddButton();
			addCartonNumberForMisPick(cartonNumber);
			clickAddButtonOnBottom();
			add4LastCartonDigits(cartonNumber);
			clickEnterButton();
	        String scannedCartonNumber=getCartonNumberFromMispicksScanPage();
			Assert.assertEquals(scannedCartonNumber, cartonNumber);
			logger.info("Valid Carton Number added to Mispicks Home screen is " + scannedCartonNumber);
		}
		
		
		
		public void disableWifiAndValidateErrormessage() {
		WebElement statusBar = driver.findElement(By.id("com.android.systemui:id/status_bar"));
		new TouchAction(driver)
				.longPress(new LongPressOptions().withElement(ElementOption.element(statusBar))
						.withDuration(Duration.ofMillis(50)))
				.moveTo(new PointOption<>().withCoordinates(720, 1280))
						.release().perform();
		}
		
		public String getCartonNumberFromMispicksScanPage() { 
			fluentWait(CartonNumberMispicksScanPage);
			return getText(CartonNumberMispicksScanPage).substring(8);
			
		}
		public String getCartonNumberInAddcartonPage() { 
			return getText(cartonNumberInAddCartonPage);
			
		}
		// Method to Validate Adding valid extra sku to scanned cartons
		public void validateAddingValidSkuToCarton(String skuNumber, SoftAssert softassert) {
			clickOnCloseButtonInSearchBar();
			setText(searchBarAddSkuPage, skuNumber);
			clickSearchButton();
			logger.info("Sku Number added " + skuNumber);
			String skuNumberInAddSkuPage=getSkuNumberFromAddSkuPage();
			String skuDescriptionInAddSkuPage=getSkuDescriptionFromAddSkuPage();
			clickAddIconInAddSkuPage();
			clickOnSkuNumber();
			String skuNumberInCartonDetailPage=getSkuNumberFromCartonDetailPage();
			String skuDescriptionInCartonDetailPage=getSkuDescriptionFromCartonDetailPage();
			softassert.assertEquals(skuNumberInAddSkuPage, skuNumberInCartonDetailPage);
			softassert.assertEquals(skuDescriptionInAddSkuPage, skuDescriptionInCartonDetailPage);
			String skuQtyInCartonDetailPage=getSkuQtyCartonDetailPage();
			String receivedskuQtyInCartonDetailPage=getReceivedSkuQtyCartonDetailPage();
			softassert.assertEquals(skuQtyInCartonDetailPage, "0");
			softassert.assertEquals(receivedskuQtyInCartonDetailPage, "1");
			
		
		}
		// Method to Validate error message while Adding invalid sku to scanned cartons
		public void validateErrorMessageWhileAddingInValidSkuToCarton (String skuNumber) {
			clickOnCartonNumber();
			clickAddButtonInCartonDetailPage();
			enterSkuNumber(skuNumber);
			logger.info("Sku Number added " + skuNumber);
			String errorMessageForInvalidSku=getSkuNumberFromAddSkuPage();
			Assert.assertEquals(errorMessageForInvalidSku, "SKU Number not found");
			logger.info(errorMessageForInvalidSku + " message displayed");
		}
		// Method to Validate error message while Adding invalid sku to scanned cartons
				public void validateErrorMessageWhileAddingDuplicateSkuToCarton (String skuNumber) {
					clickOnCloseButtonInSearchBar();
					setText(searchBarAddSkuPage, skuNumber);
					clickSearchButton();
					logger.info("Sku Number added " + skuNumber);
					String errorMessageForDuplicateSku=getSkuNumberFromAddSkuPage();
					Assert.assertEquals(errorMessageForDuplicateSku, "Duplicate SKU number. Please try again");
					logger.info(errorMessageForDuplicateSku + " message displayed");
				
				}
				public void validateErrorMessageForAddingDuplicateSkuToOrphanCarton (String skuNumber) {
					clickOnGoBackCartonDetailPage();
					clickAddButtonInCartonDetailPage();
					enterSkuNumber(skuNumber);
					logger.info("Sku Number added " + skuNumber);
					String errorMessageForDuplicateSku=getSkuNumberFromAddSkuPage();
					Assert.assertEquals(errorMessageForDuplicateSku, "Duplicate SKU number. Please try again");
					logger.info(errorMessageForDuplicateSku + " message displayed");
					clickOnSkuNumberFromAddSkuPage();
					clickOnGoBackInAddSkuPage();
					clickOnSkuNumber();
					
				
				}
				
				
				// Method to edit the received qty for extra added sku 
				
				public void editReceivedSkuQtyForExtraAddedSku (String receivedSkuQty) throws InterruptedException {
					
					WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
					new TouchAction(driver)
							.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
									.withDuration(Duration.ofMillis(500)))
							.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
							.release().perform();
					clickOnEditButton();
					setReceivedSkuQty(receivedSkuQty);
					logger.info("Edited Sku Qty Is "+ receivedSkuQty );
					clickOnSaveButton();
					clickOnGoBackCartonDetailPage();
					clickOnGoBackCartonDetailPage();
					clickOnSubmitMispicksButton();
					Thread.sleep(5000);
					clickOnCartonNumber();
					clickOnSkuNumber();
				}
				
		
		
		
		public void enterSkuNumber(String skuNumber)  {
			elementClick(searchButtonAddSkuPage);
			setText(searchBarAddSkuPage, skuNumber);
			clickSearchButton();

		}
		
		public String getSkuNumberFromAddSkuPage() { 
			return getText(skuNumberAddSkuPage);
			
		}
		public void clickOnSkuNumberFromAddSkuPage() {
			elementClick(skuNumberAddSkuPage);
		}
		public String getCartonNumberFromCartonDetailPage() { 
			return getText(cartonNumberCartonDetailPage).substring(8);
			
		}
		public String getCartonNumberInDetailPage() { 
			return getText(cartonNumberCartonDetailPage);
			
		}
		
		public String getSkuDescriptionFromAddSkuPage() { 
			return getText(skuDescriptionAddSkuPage);
			
		}
		public String getSkuNumberFromCartonDetailPage() { 
			return getText(skuNumberCartonDetailPage);
			
		}
		public String getSkuDescriptionFromCartonDetailPage() { 
			return getText(skuDescriptionCartonDetailPage);
			
		}
		public String getSkuQtyCartonDetailPage() { 
			return getText(skuQtyCartonDetailPage);
			
		}
		public String getReceivedSkuQtyCartonDetailPage() { 
			return getText(receivedQtyCartonDetailPage);
			
		}
		public String editAndSaveReceivedSkuQty(String skuQty) {
			clickOnCartonNumber();
			clickOnSkuNumber();
			WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
			new TouchAction(driver)
					.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
							.withDuration(Duration.ofMillis(500)))
					.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
					.release().perform();
			clickOnEditButton();
			setReceivedSkuQty(skuQty);
			logger.info("Edited Sku Qty Is "+ skuQty );
			clickOnSaveButton();
			String EditedSkuQty = getReceivedSkuQtyCartonDetailPage();
			logger.info("Saved Sku Qty Is "+ EditedSkuQty );
			Assert.assertEquals(skuQty, EditedSkuQty);
			clickOnGoBackCartonDetailPage();
			
			String skuNumberInDetailPage=getSkuNumberInDetailPage().substring(5);
			logger.info("Sku Number Displayed in Carton Detail Page is --> "+skuNumberInDetailPage);
			
			String skuQtyNumberInCartonDetailPage = getQtyInDetailPage().substring(4);
			logger.info("Total Pending qty Displayed in Carton Detail Page is --> "+skuQtyNumberInCartonDetailPage);
			Assert.assertEquals(skuQtyNumberInCartonDetailPage, EditedSkuQty);
			clickOnGoBackCartonDetailPage();
			return EditedSkuQty;
		}
		public void editAndCancelReceivedSkuQty(String skuQty) {
			clickOnCartonNumber();
			clickOnSkuNumber();
			WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
			new TouchAction(driver)
					.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
							.withDuration(Duration.ofMillis(500)))
					.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
					.release().perform();
			clickOnEditButton();
			setReceivedSkuQty(skuQty);
			logger.info("Edited Sku Qty Is "+ skuQty );
			clickOnCancelButton();
			String EditedSkuQty = getReceivedSkuQtyCartonDetailPage();
			logger.info("canceled sku qty edit "+ EditedSkuQty );
			Assert.assertNotEquals(skuQty, EditedSkuQty);
			clickOnGoBackCartonDetailPage();
			clickOnGoBackCartonDetailPage();
			
		}
		
		public void setReceivedSkuQty(String skuqty) {
			fluentWait(editSkuQty);
			elementClick(editSkuQty);
			clearTextField(editSkuQty);
			setText(editSkuQty, skuqty);
			pressEnter();
		}

		public void editAndCancelReceivedSkuQtyAbove99(String skuQty) {
			clickOnCartonNumber();
			clickOnSkuNumber();
			WebElement skuNo = driver.findElement(By.xpath("//android.widget.TextView[normalize-space(@text)='SKU #']"));
			new TouchAction(driver)
					.longPress(new LongPressOptions().withElement(ElementOption.element(skuNo))
							.withDuration(Duration.ofMillis(500)))
					.moveTo(new PointOption<>().withCoordinates(skuNo.getRect().getX() - 10, skuNo.getRect().getY()))
					.release().perform();
			clickOnEditButton();
			setReceivedSkuQty(skuQty);
			logger.info("Edited Sku Qty Is "+ skuQty );
			int sizeOfReceivedQty = getText(editSkuQty).length();
			logger.info("Length of received SKU QTY entered------> " + sizeOfReceivedQty);
			assertEquals(2, sizeOfReceivedQty);
			clickOnCancelButton();
			clickOnGoBackCartonDetailPage();
			clickOnGoBackCartonDetailPage();
		}
		public String captureDefaultMessage()  {
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return getText(defaultmessage);	
		}
		
		// Method to add a Just scanned carton number but not submitted to discrepancies home screen and Validate error message
		public void addScannedCartonNumberToMispicksHomeScreen(String cartonNumber) throws ParseException {
			logger.info("Validate Error message for just scanned Carton Number");
			clickAddButton();
			addCartonNumberForMisPick(cartonNumber);
	        String errorMessageForScannedCarton=getCartonNumberInAddcartonPage();
			Assert.assertEquals(errorMessageForScannedCarton, "Scanned carton has not been received yet");
			logger.info("Messaged displayed for just Scanned Carton Number is "+ errorMessageForScannedCarton );
			assertFalse(isDisplayedWithoutWait(addButtonOnBottom));
		}
		
		// Method to add a Invalid carton number to discrepancies home screen and Validate error message
		public void addInvalidCartonNumberToMispicksHomeScreen(String cartonNumber) throws ParseException {
			logger.info("Validate Error message for Invalid Carton Number");
			clickAddButton();
			addCartonNumberForMisPick(cartonNumber);
	        String errorMessageForInvalidCarton=getCartonNumberInAddcartonPage();
			Assert.assertEquals(errorMessageForInvalidCarton, "Carton Number not found");
			logger.info("Messaged displayed for Invalid Carton Number is "+ errorMessageForInvalidCarton );
			assertFalse(isDisplayedWithoutWait(addButtonOnBottom));
		}
		// method to add a valid carton number to Mispicks home screen
		public void addValidCartonNumberToMispicksHomeScreen(String cartonNumber) throws ParseException {
			logger.info("Add a Valid carton Number To the Mispicks Home Screen");
			clickOnCloseButtonInSearchBar();
			addCartonNumberForMisPick(cartonNumber);
			clickAddButtonOnBottom();
			add4LastCartonDigits(cartonNumber);
			clickEnterButton();
	        String scannedCartonNumber=getCartonNumberFromMispicksScanPage();
			Assert.assertEquals(scannedCartonNumber, cartonNumber);
			logger.info("Valid Carton Number added to Mispicks Home screen is " + scannedCartonNumber);
		}
		
		// Method to add a duplicate carton number To discrepancies Home screen and validate error message
		public void addDuplicateCartonNumberToMispicksHomeScreen(String cartonNumber) throws ParseException {
			logger.info("Validate Error message for Duplicate Carton Number");
			clickAddButton();
			addCartonNumberForMisPick(cartonNumber);
	        String errorMessageForDuplicateCarton=getCartonNumberInAddcartonPage();
			Assert.assertEquals(errorMessageForDuplicateCarton, "Duplicate carton number. Please try again");
			logger.info("Messaged displayed for Duplicate Carton Number is "+ errorMessageForDuplicateCarton );
			assertFalse(isDisplayedWithoutWait(addButtonOnBottom));
		}	
		// Method to add carton number already marked as mispicked to discrepancies home screen and Validate error message
				public void addAlreadyMispickedMarkedCartonNumberToMispicksHomeScreen(String cartonNumber) throws ParseException {
					logger.info("Validate Error message for Already Mispicked Marked Carton Number");
					clickAddButton();
					addCartonNumberForMisPick(cartonNumber);
			        String errorMessageForAlreadyMarkedMispickedCarton=getCartonNumberInAddcartonPage();
					Assert.assertEquals(errorMessageForAlreadyMarkedMispickedCarton, "Duplicate carton number. Please try again");
					logger.info("Messaged displayed for Mispicked marked Carton Number is "+ errorMessageForAlreadyMarkedMispickedCarton );
					assertFalse(isDisplayedWithoutWait(addButtonOnBottom));
				}
				//  Method to incorrectly enter last 4 digits of the carton and validate error message 
				public void validateErrorMessageForEnteringInvalidFourDigitsForValidCarton(String cartonNumber) throws ParseException {
					clickOnCloseButtonInSearchBar();
					addCartonNumberForMisPick(cartonNumber);
					clickAddButtonOnBottom();
					String PopUpDefaultMessage=captureEnter4DigitsMessage();
					Assert.assertEquals(PopUpDefaultMessage, "Re-enter last 4 carton digits");
					logger.info("Popup message Displayed is "+PopUpDefaultMessage);
					reEnter4CartonDigitsIncorrectly(cartonNumber);
					clickEnterButton();
					String cartonNumberMismatchMessage = getCartonNumberDoesNotMatchMessage();
					Assert.assertEquals(cartonNumberMismatchMessage, "Incorrect Entry. Please enter again");
					logger.info("Message Displayed for Mismatch is "+cartonNumberMismatchMessage);
					clickCancelPopupButton();
				}
				
				public void validateDetailsOfMispickedCartonWithSingleSku(String mispickedCarton, String storeNumber) throws ParseException {
					ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
					clickOnCartonNumber();
					validateCartonDetailsinCartonDetailPage(mispickedCarton,softassert);
					
					String skuNumberInDetailPage=getSkuNumberInDetailPage().substring(5);
					logger.info("Sku Number Displayed in Carton Detail Page is --> "+skuNumberInDetailPage);
					
					String skuQtyNumber = getQtyInDetailPage().substring(4);
					logger.info("Total Pending qty Displayed in Carton Detail Page is --> "+skuQtyNumber);
					
					clickOnSkuNumber();
					String cartonNumbeInDetailPage=getCartonNumberFromCartonDetailPage();
					softassert.assertEquals(cartonNumbeInDetailPage, mispickedCarton);
					String uiShippedSkuQty = getSkuQtyCartonDetailPage();
					String uiReceivedSkuQty = getReceivedSkuQtyCartonDetailPage();
					softassert.assertEquals(uiShippedSkuQty, uiReceivedSkuQty);
					
					logger.info("To validate the sku labels displayed in the sku detail page");
					validateSkuLabel(softassert);
					//Validation in DB
					validateFromMongoDB.getSkuDetailsForMispickedCartonWithSingleSku(mispickedCarton,skuNumberInDetailPage,softassert,storeNumber,skuQtyNumber);
					
					clickOnGoBackCartonDetailPage();
					isDisplayed(qtyInDetailPage);
					clickOnGoBackCartonDetailPage();
				    fluentWait(mispicksHeader);
			        String mispicksHeadingHomePage = getText(mispicksHeader);
					softassert.assertEquals(mispicksHeadingHomePage, "Mispicks");
					logger.info("Heading displayed in Home Page is "+mispicksHeadingHomePage);
					
					softassert.assertAll();
					
					
				}
				public void clickOnSkuNumber() {
					elementClick(skuNumberInDetailPage);
					
				}
				private void validateCartonDetailsinCartonDetailPage(String mispickedCarton, SoftAssert softassert) {
					String cartonNumLabel = getCartonNumberInDetailPage().substring(0, 6);
					softassert.assertEquals(cartonNumLabel, "Carton");
					String cartonNumbeInDetailPage=getCartonNumberInDetailPage().substring(8);
					softassert.assertEquals(cartonNumbeInDetailPage, mispickedCarton);
					logger.info("Carton Number Displayed in Carton Detail Page is --> "+cartonNumbeInDetailPage);
					String QtyLabel = getQtyInDetailPage().substring(0,3);
					softassert.assertEquals(QtyLabel, "QTY");
					
					String skuLabel = getSkuNumberInDetailPage().substring(0,4);
					softassert.assertEquals(skuLabel, "SKU#");
					
					
					
				}
				private String getSkuNumberInDetailPage() {
                 	return getText(skuNumberInDetailPage);
				}
               private String getQtyInDetailPage() {
					return getText(qtyInDetailPage);
				}
				
				public void validateSkuLabel(SoftAssert softassert){
					boolean isCartonLabelDisplayed = isDisplayed(cartonNumberCartonDetailPage);
					softassert.assertTrue(isCartonLabelDisplayed);
					
					boolean isSkuLabelDisplayed = isDisplayed(skuLabel);
					softassert.assertTrue(isSkuLabelDisplayed);
					
					boolean isSkuDescLabelDisplayed = isDisplayed(skuDescLabel);
					softassert.assertTrue(isSkuDescLabelDisplayed);
					
					boolean isSkuQtyLabelDisplayed = isDisplayed(skuQtyLabel);
					softassert.assertTrue(isSkuQtyLabelDisplayed);
					
					boolean isReceivedSkuQtyLabelDisplayed = isDisplayed(receivedSkuQtyLabel);
					softassert.assertTrue(isReceivedSkuQtyLabelDisplayed);
					
					boolean isSpecialHandlingLabelDisplayed = isDisplayed(specialHandlingLabel);
					softassert.assertTrue(isSpecialHandlingLabelDisplayed);
					logger.info("All the sku labels are displayed in the sku detail page");
					
				}

				public void validateDetailsOfMispickedCartonWithMultipleSku(String mispickedCarton, String storeNumber) throws ParseException {
					ValidateFromMongoDB validateFromMongoDB = new ValidateFromMongoDB();
					clickOnCartonNumber();
					String cartonNumbeInDetailPage=getCartonNumberFromCartonDetailPage();
					softassert.assertEquals(cartonNumbeInDetailPage, mispickedCarton);
					ArrayList<MobileElement> skuNumberListOnTransferDetailPage = getSkuNumberListOnCartonDetailPage();

					int index = -1;
					for (int i = 0; i < skuNumberListOnTransferDetailPage.size(); i++) {
						skuNumberListOnTransferDetailPage = getSkuNumberListOnCartonDetailPage();
						String skuValuetmp = skuNumberListOnTransferDetailPage.get(i).getText().substring(5);
						logger.info("Sku Number is ------ " + skuValuetmp);
						if (skuValuetmp!= null) {
							index = i;
							logger.info("Index of SKU ------ " + index);
							skuNumberListOnTransferDetailPage.get(index).click();
						}
						validateFromMongoDB.getSkuDetailsForMispickedCartonWithMultipleSku(mispickedCarton, skuValuetmp,softassert,storeNumber);
						clickOnGoBackCartonDetailPage();
					}
					
					
					

		}
				
				public void clickOkAndConnectAgain() {
					fluentWait(clickOnOkOnNetworkErrorMsg, 20, 3);
					elementClick(clickOnOkOnNetworkErrorMsg);
					
				}

				public ArrayList<MobileElement> getSkuNumberListOnCartonDetailPage() {
					return (ArrayList<MobileElement>) getListText(skuNumberInDetailPage);
				}
				
				public ArrayList<MobileElement> getSkuQtyListOnCartonDetailPage() {
					return (ArrayList<MobileElement>) getListText(qtyInDetailPage);
				}
				public ArrayList<MobileElement> getSkuDescriptionListOnCartonDetailPage() {
					return (ArrayList<MobileElement>) getListText(skuDescriptionCartonDetailPage);
				}
				public String getSpecialHandlingCartonDetailPage() {
					return getText(specialHandlingCartonDetailPage);
				}
				
				 
				public void scrollInCartonDetailPageInMispick(String cartonNumber){
					    
					    elementClick(By.xpath("//android.widget.TextView[normalize-space(@text)='Carton #"+cartonNumber+"']"));

						MobileElement element=driver.findElementByClassName("android.support.v7.widget.RecyclerView");
						
						String isScrollable=element.getAttribute("scrollable");
				        logger.info("Scrollable flag In Mispick Carton DetailPage is :"+isScrollable);
				        assertEquals(isScrollable, "true");
				        
				        List<MobileElement>  skuNumberListOnCartonDetailPage = getSkuNumberListOnCartonDetailPage();
				        boolean isScrolled= scrollDownByElement(skuNumberListOnCartonDetailPage);
				        assertTrue(isScrolled);
				        
				        
					}
}

		
		
		
	

