package com.pdt.Pom;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.web.template.AndroidBasePage;

import ru.yandex.qatools.allure.annotations.Step;

public class SendAndReceiveTransferPage extends AndroidBasePage{
	final static Logger logger = Logger.getLogger(SendAndReceiveTransferPage.class);
	SoftAssert softassert =new SoftAssert();

	
	protected By toolBarHeading = By.id("com.si:id/txtToolbarTitle");
	protected By storeTransfersHeading = By.xpath("//android.widget.TextView[normalize-space(@text)='STORE TRANSFER']");
	protected By sendStoreTransfer = By.id("com.si:id/btnDCShip_STHome_SendST");
	protected By receiveStoreTransfer=By.id("com.si:id/btnDCShip_STHome_RecST");
	protected By sendStoreTransferHeading = By.id("com.si:id/lblSendST_TransferList_Header");
	protected By receiveStoreTransferHeading=By.id("com.si:id/lblST_TransferList_Header");
	protected By goBackSendStoreTransfer = By.id("com.si:id/btnSendST_TransferList_Back");
	protected By goBackReceiveStoreTransfer = By.id("com.si:id/btnST_TransferList_Back");
	protected By transfer = By.id("com.si:id/btnSendST_TransferList_NewTransfer");

	
	public void clickOnSendStoreTransfer() {
		logger.info("Clicking on SendStoreTransfer Button");
		elementClick(sendStoreTransfer);
		fluentWait(transfer);
		
	}
	
	
	public void clickOnReceiveStoreTransfer() {
		elementClick(receiveStoreTransfer);
	}
	public void clickOnGoBackSendStoreTransfer() {
		elementClick(goBackSendStoreTransfer);
	}
	public void clickOnGoBackReceiveStoreTransfer() {
		elementClick(goBackReceiveStoreTransfer);
	}
	public boolean isStoreTransfersHeadingDisplayed() {
		return isDisplayed(sendStoreTransfer);
	}
	public boolean isSendTransfersButtonDisplayed() {
		return isDisplayed(sendStoreTransfer);
	}
	public boolean isReceiveTransfersButtonDisplayed() {
		return isDisplayed(receiveStoreTransfer);
	}
	
	@Step("To capture the Store Transfers Heading ")
	public String captureStoreTransfersHeader() {
		fluentWait(toolBarHeading);
		return getText(toolBarHeading);
	}
	@Step("To capture the Send Store Transfers Heading ")
	public String captureSendStoreTransfersHeader() {
		fluentWait(sendStoreTransferHeading);
		return getText(sendStoreTransferHeading);
	}
	@Step("To capture the Receive Store Transfers Heading ")
	public String captureReceiveStoreTransfersHeader() {
		fluentWait(receiveStoreTransferHeading);
		return getText(receiveStoreTransferHeading);
	}
	


	public void navigateToSendTransfersPage(SoftAssert localassert) {
		isSendTransfersButtonDisplayed();
		clickOnSendStoreTransfer();
		String toolbarHeading=captureStoreTransfersHeader();
		localassert.assertEquals(toolbarHeading, "SENDING");
		logger.info(toolbarHeading +" Heading is Displayed");
		String sendTransfersHeading=captureSendStoreTransfersHeader();
		localassert.assertEquals(sendTransfersHeading, "Send Store Transfers");
		logger.info(sendTransfersHeading +" Heading is Displayed in Send Store Transfer Page");
		clickOnGoBackSendStoreTransfer();
		isStoreTransfersHeadingDisplayed();
	}
	public void navigateToReceiveTransfersPage(SoftAssert localassert) {
		isReceiveTransfersButtonDisplayed();
		clickOnReceiveStoreTransfer();
		String toolbarHeading=captureStoreTransfersHeader();
		localassert.assertEquals(toolbarHeading, "RECEIVING");
		logger.info(toolbarHeading +" Heading is Displayed");
		String receiveTransfersHeading=captureReceiveStoreTransfersHeader();
		localassert.assertEquals(receiveTransfersHeading, "Receive Store Transfers");
		logger.info(receiveTransfersHeading +" Heading is Displayed in Receive Store Transfer Page");
		clickOnGoBackReceiveStoreTransfer();
		isStoreTransfersHeadingDisplayed();
	}
	
	

	

}
