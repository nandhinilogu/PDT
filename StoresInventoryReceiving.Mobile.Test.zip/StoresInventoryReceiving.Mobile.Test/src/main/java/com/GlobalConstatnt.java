package com;

/**
 * @author Yurii Chukhrai on [Dec 2016]
 * @version - [1.0]
 * @file - [BaseListener.java]
 */

public final class GlobalConstatnt {

	public final static int TIME_SLEEP_MULTIPLIER_1 = 1;
	public final static int TIME_SLEEP_MULTIPLIER_2 = 2;
	public final static int TIME_SLEEP_MULTIPLIER_3 = 3;
	public final static int TIME_SLEEP_MULTIPLIER_4 = 4;
	public final static int TIME_SLEEP_MULTIPLIER_5 = 5;
	public final static int TIME_SLEEP_MULTIPLIER_7 = 7;
	public final static int TIME_SLEEP_MULTIPLIER_10 = 10;
	public final static int TIME_SLEEP_MULTIPLIER_15 = 15;
	public final static int TIME_SLEEP_MULTIPLIER_20 = 20;
	public final static int TIME_SLEEP_MULTIPLIER_30 = 30;
	public final static int TIME_SLEEP_MULTIPLIER_40 = 40;

	public final static int TIME_WAIT_MIN_1 = 60;
	public final static int TIME_WAIT_MIN_2 = 120;
	public final static int TIME_WAIT_MIN_3 = 180;
	public final static int TIME_WAIT_MIN_4 = 240;
	public final static int TIME_WAIT_MIN_5 = 300;
	public final static int TIME_WAIT_MIN_6 = 360;

	/* Thread sleep 100, 250, 500, 1000 and 3000 ms */
	public final static long TIME_SLEEP_100 = 100L;
	public final static long TIME_SLEEP_250 = 250L;
	public final static long TIME_SLEEP_500 = 500L;
	public final static long TIME_SLEEP_1000 = 1_000L;
	public final static long TIME_SLEEP_3000 = 3_000L;
	public final static long TIME_SLEEP_5000 = 5_000L;
	public final static long TIME_SLEEP_6000 = 6_000L;
	public final static long TIME_SLEEP_1_MIN = 60_000L;
	public final static long TIME_SLEEP_5_MIN = 300_000L;
	public final static long TIME_SLEEP_10_MIN = 600_000L;

	public final static String RGB_HIGHLIGHT_COLOR = "rgb(255,69,0)";
}
